#include "Arduino.h"
#include <fstream>
#include <sstream>
#include <vector>
#include <cstdlib>
struct Event { unsigned long ms; std::string name; float value; };
std::vector<Event> events;
size_t next_event=0;
unsigned long simulated_ms=0;
void apply_events(){
 while(next_event<events.size()&&events[next_event].ms<=simulated_ms){
  const Event&e=events[next_event++];host_set_attr(e.name.c_str(),e.value);
 }
}
void advance_time(unsigned long ms){
 const unsigned long end=simulated_ms+ms;
 while(simulated_ms<end){++simulated_ms;apply_events();if(simulated_ms%50==0)host_tick();}
}
#include "../referencia/sketch.ino"
int main(int argc,char**argv){
 if(argc!=4)return 2;
 std::ifstream in(argv[1]);std::string line;
 if(!in)return 3;
 while(std::getline(in,line)){
  std::istringstream row(line);Event e;
  if(row>>e.ms>>e.name>>e.value)events.push_back(e);
 }
 host_init();
 // Different Monte Carlo repetitions; the production chip remains byte-identical.
 std::srand((unsigned)std::stoul(argv[2]));
 apply_events();host_tick();setup();
 const unsigned long end=std::stoul(argv[3]);
 while(simulated_ms<end)loop();
 return 0;
}

"""23-column V6 telemetry. Reference is independent of the neural estimator."""
import numpy as np

def parse(text):
    rows=[]
    for line in text.splitlines():
        f=line.split()
        if len(f)==23:
            try: rows.append(list(map(float,f)))
            except ValueError: pass
    a=np.asarray(rows,dtype=float)
    if a.ndim!=2 or not len(a): raise ValueError('No V6 telemetry')
    if not np.isfinite(a).all(): raise ValueError('Nonfinite telemetry')
    if not np.all(np.diff(a[:,0])>0): raise ValueError('Nonincreasing time')
    return a

def environment(profile,t):
    vals={}
    for e in profile['events']:
        if e['t_ms']>t: break
        vals[e['control']]=e['value']
    return vals

def reference(g,t,load):
    voc=np.clip(41.3*(1-.003*(t-25)),0,41.3)
    isc=13.8*g/1000*(1+.0004*(t-25))
    k=np.clip(8*(1-.002*(t-25)),1,8)
    r=(1/(k+1))**(1/k)
    v=voc*(1-load/100)
    p=v*isc*(1-(v/voc)**k)
    return voc*r,voc*r*isc*k/(k+1),p

def analyze(a,profile):
    # Scheduled controls are ground truth; G/T sensors and NN reference are not.
    env=[environment(profile,t) for t in a[:,0]]
    g=np.array([e['irradiance'] for e in env]);t=np.array([e['temperature'] for e in env])
    vm,pm,physical=reference(g,t,a[:,8])
    dt=np.diff(a[:,0])/1000
    # Left rectangles avoid interpolating a power jump across a commanded step.
    def energy(p):return float(np.sum(p[:-1]*dt))
    def efficiency(mask):
        j=np.flatnonzero(mask[:-1]&mask[1:])
        return float(100*np.sum(physical[j]*dt[j])/np.sum(pm[j]*dt[j])) if len(j) else None
    start_times=sorted(set(e['t_ms'] for e in profile['events']))
    # Only plateau events: ramp samples are excluded from settling-time analysis.
    transitions=[]
    for idx,start in enumerate(start_times):
        end=start_times[idx+1] if idx+1<len(start_times) else profile['duration_ms']
        if end-start<15000:continue
        ids=np.flatnonzero((a[:,0]>=start)&(a[:,0]<end))
        settled=None
        for j in range(max(0,len(ids)-4)):
            five=ids[j:j+5]
            if np.all(np.abs(a[five,1]-vm[five])<=.2):
                settled=float((a[five[0],0]-start)/1000);break
        tail=ids[a[ids,0]>=end-10000]
        transitions.append({'start_ms':start,'end_ms':end,'settling_5samples_0p2V_s':settled,
            'V_std_last10s':float(np.std(a[tail,1],ddof=1)) if len(tail)>1 else None,
            'physical_P_std_last10s':float(np.std(physical[tail],ddof=1)) if len(tail)>1 else None})
    return {'samples':len(a),'observed_window_ms':[float(a[0,0]),float(a[-1,0])],
        'energy_physical_model_J':energy(physical),'energy_available_model_J':energy(pm),
        'tracking_efficiency_physical_model_pct':100*energy(physical)/energy(pm),
        'telemetry_energy_J':energy(a[:,3]),'telemetry_ratio_to_model_pct':100*energy(a[:,3])/energy(pm),
        'voltage_MAE_to_independent_MPP_V':float(np.mean(abs(a[:,1]-vm))),
        'preupdate_I_error_RMSE_covered_A':float(np.sqrt(np.mean(a[a[:,12]==1,16]**2))) if np.any(a[:,12]==1) else None,
        'updates':int(a[-1,17]),'parameter_change':float(a[-1,19]),
        'fallback_fraction':float(np.mean(a[:,11]==3)), 'limit_fraction':float(np.mean(a[:,21])),
        'retries_max':int(a[:,22].max()),'max_sample_gap_ms':float(np.diff(a[:,0]).max()),
        'eff_first30s_pct':efficiency(a[:,0]<30000),
        'eff_last30s_pct':efficiency(a[:,0]>=profile['duration_ms']-30000),
        'plateaus':transitions}

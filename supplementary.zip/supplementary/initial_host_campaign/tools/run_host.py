"""Run byte-identical V6 firmware/chip on host mocks; NOT an ESP32 benchmark."""
from pathlib import Path
import subprocess,tempfile,json,hashlib,sys
import numpy as np
from analyze import parse,analyze
R=Path(__file__).resolve().parents[1]
profiles=json.loads((R/'perfiles/profiles.json').read_text())
repetitions=int(sys.argv[1]) if len(sys.argv)>1 else 10
assert repetitions>0
manifest=json.loads((R/'referencia/SHA256.json').read_text())
for name,digest in manifest.items(): assert hashlib.sha256((R/'referencia'/name).read_bytes()).hexdigest()==digest
output=R/'resultados_host';output.mkdir(exist_ok=True)
runs=[]
variants=[('PO',0,0),('INC',1,0),('ADAPT_PO',2,0),('NN_FROZEN',3,0),('NN_ONLINE',3,1)]
with tempfile.TemporaryDirectory() as tmp:
    b=Path(tmp)
    common=['-O2','-Wall','-Wextra','-Werror','-I',str(R/'tests/stubs')]
    for name,source in [('chip',R/'referencia/solar.chip.c'),('host',R/'tests/chip_host.c')]:
        subprocess.run(['gcc','-std=c11','-DM_PI=3.14159265358979323846',*common,'-c',str(source),'-o',str(b/f'{name}.o')],check=True)
    for label,mode,online in variants:
        exe=b/label
        subprocess.run(['g++','-std=c++11',*common,f'-DMPPT_MODE={mode}',f'-DMPPT_ONLINE_LEARNING={online}',str(R/'tests/benchmark.cpp'),str(b/'chip.o'),str(b/'host.o'),'-lm','-o',str(exe)],check=True)
        for profile in profiles:
            for seed in range(1,repetitions+1):
                raw=subprocess.run([str(exe),str(R/f"perfiles/{profile['id']}.events"),str(seed),str(profile['duration_ms'])],capture_output=True,text=True,check=True).stdout
                (output/f"{label}_{profile['id']}_seed{seed:02d}.txt").write_text(raw)
                a=parse(raw)
                assert (a[:,7:10]>=0).all() and (a[:,7:10]<=100).all()
                result=analyze(a,profile)
                result.update(variant=label,profile=profile['id'],seed=seed)
                runs.append(result)
        print(label,'completed',flush=True)
(output/'metrics.json').write_text(json.dumps(runs,indent=2))
summary=[]
for p in profiles:
    pairs=[]
    for seed in range(1,repetitions+1):
        values={x['variant']:x for x in runs if x['profile']==p['id'] and x['seed']==seed}
        assert len({tuple(x['observed_window_ms']) for x in values.values()})==1
        pairs.append(values['NN_ONLINE']['tracking_efficiency_physical_model_pct']-values['NN_FROZEN']['tracking_efficiency_physical_model_pct'])
    rng=np.random.default_rng(20261026)
    boot=np.mean(rng.choice(pairs,size=(10000,len(pairs)),replace=True),axis=1)
    summary.append({'profile':p['id'],'paired_online_minus_frozen_efficiency_pp_mean':float(np.mean(pairs)),
        'bootstrap95_ci_pp':np.quantile(boot,[.025,.975]).tolist(),
        'variants':{label:{'efficiency_pct_mean':float(np.mean([x['tracking_efficiency_physical_model_pct'] for x in runs if x['profile']==p['id'] and x['variant']==label])),
        'updates_mean':float(np.mean([x['updates'] for x in runs if x['profile']==p['id'] and x['variant']==label]))} for label,_,_ in variants}})
(output/'summary.json').write_text(json.dumps(summary,indent=2))
aggregates=[]
for seed in range(1,repetitions+1):
    row={'seed':seed}
    for label,_,_ in variants:
        subset=[x for x in runs if x['seed']==seed and x['variant']==label and x['profile'].startswith('S')]
        row[label]=100*sum(x['energy_physical_model_J'] for x in subset)/sum(x['energy_available_model_J'] for x in subset)
    row['delta_online_frozen_pp']=row['NN_ONLINE']-row['NN_FROZEN']
    aggregates.append(row)
delta=[x['delta_online_frozen_pp'] for x in aggregates]
boot=np.mean(np.random.default_rng(20261026).choice(delta,size=(10000,len(delta)),replace=True),axis=1)
(output/'aggregate_primary.json').write_text(json.dumps({'per_seed':aggregates,'mean_delta_pp':float(np.mean(delta)),
    'bootstrap95_ci_pp':np.quantile(boot,[.025,.975]).tolist()},indent=2))
print(json.dumps(summary,indent=2))

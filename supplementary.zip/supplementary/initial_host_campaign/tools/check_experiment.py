from pathlib import Path
import hashlib,json,numpy as np,yaml
from analyze import parse,reference
R=Path(__file__).resolve().parents[1]
manifest=json.loads((R/'referencia/SHA256.json').read_text())
for name,digest in manifest.items():
 assert hashlib.sha256((R/'referencia'/name).read_bytes()).hexdigest()==digest
 original=R.parent/'mppt_lazo_cerrado_v6/experimental'/name
 if original.exists():assert original.read_bytes()==(R/'referencia'/name).read_bytes()
profiles=json.loads((R/'perfiles/profiles.json').read_text())
for p in profiles:
 y=yaml.safe_load((R/f"escenarios_wokwi/{p['id']}.yaml").read_text())
 now=0;events=[]
 for step in y['steps']:
  if 'delay' in step:now+=int(step['delay'][:-2])
  else:
   c=step['set-control'];events.append({'t_ms':now,'control':c['name'],'value':c['value']})
 assert events==p['events'] and now==p['duration_ms']
# Independent dense numerical maximization checks analytic reference.
for g in [200,400,600,800,900]:
 for t in [15,25,37,50,60]:
  loads=np.linspace(0,100,100001)
  vm,pm,p=reference(g,t,loads)
  assert abs(p.max()-pm)<1e-6
logs=list((R/'resultados_host').glob('*_seed*.txt'))
assert len(logs)==350,len(logs)
for log in logs:
 a=parse(log.read_text());assert np.max(np.diff(a[:,0]))==500
 assert not np.any(a[:,22])
 if log.name.startswith('NN_FROZEN'):assert not np.any(a[:,17])
report={'reference_source_bytes_unchanged':True,'scenario_JSON_YAML_events_match':True,
 'analytical_MPP_dense_grid_checks':25,'finite_logs_with_500ms_cadence':len(logs),
 'no_retries_in_host':True,'frozen_no_updates':True,
 'Wokwi_automated_profiles_executed':False,'physical_ESP32_timing_measured':False}
(R/'resultados_host/quality_checks.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))

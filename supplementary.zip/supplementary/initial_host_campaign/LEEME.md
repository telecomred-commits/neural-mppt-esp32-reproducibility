# Experimento MPPT preparado

Empiece por PROTOCOLO.md y RESULTADOS_PRELIMINARES.md.

Este paquete añade un protocolo y un banco de comparación. No contiene un nuevo proyecto para reemplazar el que usted está utilizando. Las fuentes de referencia son copias exactas de la versión experimental ya probada; no se modifica su circuito, JSON, chip ni pesos.

Contenido:

- PROTOCOLO.md: estado del arte con ocho referencias primarias/documentales, hipótesis, controles, perfiles, métricas, interpretación y límites.
- RESULTADOS_PRELIMINARES.md: resultado del banco host y decisión sobre la hipótesis de aprendizaje.
- perfiles/: definición programable de los siete perfiles.
- escenarios_wokwi/: YAML según la documentación CLI; aún requieren prueba de compatibilidad de los controles personalizados en Wokwi. No basta pegarlos en el editor web para ejecutarlos.
- referencia/: .ino, cabeceras y chip C existentes, sin modificaciones, para que el banco sea reproducible.
- tests/: arnés y mocks, exclusivamente para el ordenador. Nunca instalar sus cabeceras en Wokwi.
- tools/: ejecución y análisis.
- resultados_host/: 350 registros completos, métricas, resúmenes y comprobaciones. Son resultados de simulación host, no medidas de un ESP32 físico.

Reproducir en el ordenador:

```bash
python3 tools/run_host.py 10
python3 tools/check_experiment.py
```

Dependencias: Python3, NumPy y gcc/g++; PyYAML para check_experiment.py. La ejecución genera los registros y sustituye los resultados de esa carpeta. El banco no descarga ni publica nada.

Primera comprobación en su Wokwi actual: G600, T37, Load50, rangos50V/15A, Ns=Np=1 y modo automático. Ejecutar120 s con MPPT_MODE3 y MPPT_ONLINE_LEARNING0; reiniciar y repetir con MPPT_ONLINE_LEARNING1. Guardar ambos seriales completos, identificados. Esta prueba estática permite comparar sin intervención manual durante la corrida. No cambie la adquisición, los pesos o el panel entre variantes.

Los perfiles dinámicos cuantitativos se ejecutan después de confirmar que los eventos automáticos llegan al chip personalizado. El paquete documenta esa comprobación pendiente; no da por validada una automatización que aún no se ha ejecutado en Wokwi.

# Experimento MPPT: fundamento bibliográfico y protocolo reproducible

Versión 1.0. Consulta bibliográfica: 26 de octubre de 2026.

## 1. Decisión y alcance

El experimento principal compara el controlador neuronal actual con su aprendizaje activado y desactivado. P&O, INC y P&O adaptativo completan la comparación. Se conservan los mismos pesos iniciales, adquisición, periodo de muestreo, comunicación, límites y planta. La hipótesis es comprobable y admite un resultado negativo: las actualizaciones en línea pueden mejorar la predicción sin mejorar la energía capturada.

Esta revisión es dirigida, no una revisión sistemática exhaustiva. Se buscaron publicaciones originales de 2024–2026, implementación neuronal en microcontroladores, aprendizaje incremental, MPPT por refuerzo, evaluación reproducible y eficiencia dinámica. Se consultaron páginas de editoriales, los artículos originales y la ficha oficial IEC; algunos accesos al texto completo fueron bloqueados. No se usan cifras publicadas en otro banco como objetivos directamente comparables.

El protocolo está fundamentado en antecedentes; la validación del controlador depende de ejecutar las pruebas y analizar los resultados. Wokwi es una simulación de firmware y planta digital. No constituye por sí mismo HIL con un ESP32 físico ni validación de un convertidor de potencia real.

## 2. Estado del arte que cambia el diseño del experimento

| Antecedente original | Hallazgo relevante para nuestro diseño | Consecuencia |
|---|---|---|
| Abouzeid et al., Scientific Reports, 2024 [1] | ANN contrastada con P&O e INC; implementación en Arduino MEGA-2560. | Una ANN embebida no basta como novedad. Comparar bajo condiciones comunes y describir sensores y adquisición. |
| Giraldo et al., Heliyon, 2024 [2] | DQN evaluado con un convertidor físico, incluyendo sombreado parcial; resultados de simulación y hardware no coinciden completamente. | Separar simulación y hardware. Nuestro panel de un máximo no permite afirmar búsqueda de un máximo global bajo sombreado. |
| Amine et al., Energy Science & Engineering, 2026 [3] | Expansión de datos meteorológicos y actualización incremental de ANN mediante Raspberry Pi. | Aprendizaje incremental ya tiene antecedentes. Distinguir actualización periódica de datos y actualización local de parámetros en cada medición. |
| Ogunfowora y Bhattacharya, Energies, 2026 [4] | Comparación de INC, Q-learning y un modelo inspirado en Transformer bajo escenarios ambientales. | El contexto incluye familias más amplias que P&O. No es obligatorio implementar todas: los controles deben responder a la hipótesis concreta. |
| Jamshed et al., Electronics, septiembre de 2026 [5] | Flujo reproducible de ANN ligera, STM32 y C-HIL; diferencia explícita entre HIL y prototipo físico. | Publicar pesos, código, perfiles, tiempos y límites. La implantación y la reproducibilidad pueden ser parte del aporte, sin afirmar una arquitectura inédita. |
| IEC 62891:2020 [6] | Considera eficiencia MPPT estática y dinámica en inversores conectados a red. | Separar energía estacionaria y transitoria. Nuestros perfiles son propios; no se declara conformidad IEC/EN ni certificación. |

La posible contribución de este trabajo es una evaluación reproducible del ajuste en línea de una red pequeña en el entorno ESP32/panel digital, con separación del efecto de la instrumentación y del respaldo INC. Es una propuesta de posicionamiento, no una afirmación de prioridad frente a toda la literatura.

## 3. Qué tenemos realmente

Se dispone de cuatro barridos calibrados (1012 muestras, cuatro condiciones independientes) para el entrenamiento inicial y un barrido a 600 W/m² y 37 °C utilizado previamente para evaluación. Ese quinto barrido ya se inspeccionó: es una referencia de interpolación conocida, no un conjunto de prueba completamente ciego. Los registros históricos PO/POINC/POINCADAP se conservan como antecedentes, con sus límites de metadatos; no se mezclan como si fueran etiquetas óptimas calibradas.

La red actual tiene estructura 2–16–1, 65 parámetros en total. En línea se ajustan 17 parámetros de salida; las características ocultas permanecen fijas. Aprende a predecir corriente, y después busca el máximo de la potencia predicha. El regulador modifica la carga virtual según el error de tensión. Actualizar parámetros, regular tensión y mejorar energía son tres resultados distintos.

En el código actual:

- Periodo nominal: 500 ms; pines ADC: V34, I35, G33, T32; control de la copia experimental: RX16/TX17.
- Rangos 50 V y 15 A; ganancias V/I = 5/3.3; G/T = 1.515. Ns=Np=1.
- Dominio de la red: G aproximadamente 400–800 W/m² y T 25–50 °C, con pequeñas tolerancias de borde del firmware. Fuera de él actúa INC y se suspenden actualizaciones.
- Paso de carga limitado a ±3 puntos porcentuales; zona muerta de tensión ±0.15 V.
- Aprendizaje NLMS de salida, tasa 0.10, umbral de error de corriente 0.04 A y límites de parámetros ya existentes. No se ajustan después de ver este experimento.
- La barra Load=50 representa perturbación cero en modo automático. 60 añade +10 puntos y 40 resta 10. El ACK informa la carga efectivamente aplicada.

En esta planta la irradiancia multiplica la corriente, pero no cambia la posición del máximo a temperatura fija. Además, la red representa I=(G/1000)·f(V,T): G es un factor positivo que se cancela al buscar argmax(V·I). Por eso una referencia de tensión constante al cambiar solamente G puede ser correcta; no demuestra por sí sola aprendizaje. Esta conclusión se deriva del código y las ecuaciones del proyecto.

## 4. Hipótesis y controles

H1, principal: NN_ONLINE aumenta la eficiencia de seguimiento energético frente a NN_FROZEN en los perfiles primarios, con una diferencia consistente entre repeticiones.

H2, secundaria: NN_ONLINE reduce el error de predicción de corriente medido antes de cada actualización. No se sustituye H1 por H2 si H1 falla.

H3, funcional: recupera el punto de operación tras perturbaciones alcanzables de carga, irradiancia y temperatura, sin valores no finitos ni pérdida persistente de comunicación.

| Variante | MPPT_MODE | MPPT_ONLINE_LEARNING | Diferencia |
|---|---:|---:|---|
| PO | 0 | 0 | P&O fijo del firmware actual |
| INC | 1 | 0 | Conductancia incremental actual |
| ADAPT_PO | 2 | 0 | P&O adaptativo actual |
| NN_FROZEN | 3 | 0 | Red inicial y respaldo INC, sin actualización |
| NN_ONLINE | 3 | 1 | Misma red y respaldo, con actualización |

En Wokwi estas constantes se cambian en el `.ino` de la copia experimental, antes de compilar. No hay que cambiar diagram.json, solar.chip.c, solar.chip.json ni pesos para alternar las variantes. Se reinicia cada ejecución para restaurar parámetros, comando inicial 50 y memoria de los algoritmos.

El ajuste de los algoritmos convencionales se mantiene en su versión existente. Esto es una comparación de implementaciones documentadas, no prueba de superioridad frente a toda configuración posible de P&O/INC. Cualquier ajuste posterior requiere un conjunto de desarrollo separado y repetir todas las condiciones finales. El modelo afín de tensión ya ensayado es un control adicional recomendable antes de atribuir una ventaja específica a la representación neuronal.

## 5. Perfiles fijados antes de observar los resultados

Todos comienzan en t=0; G en W/m², T en °C, L es la barra de carga, no la carga aplicada. Los JSON y archivos `.events` contienen los instantes completos y son la definición autoritativa.

| Perfil | Duración | Secuencia |
|---|---:|---|
| S0_inedito | 120 s | G600, T37, L50 constantes; condición no usada en los cuatro barridos iniciales |
| S1_irradiancia | 160 s | T25/L50; G800 →400 en 30 s →800 en 60 s; rampa 800→400 de 80 a120 s y retorno de120 a160 s, escalones de10 W/m² cada1 s |
| S2_temperatura | 150 s | G800/L50; T25 →37 en30 s →50 en60 s →37 en90 s →25 en120 s |
| S3_carga | 160 s | G800/T25; L50 →60 en40 s →40 en80 s →50 en120 s |
| S4_combinado | 160 s | (G,T,L): (600,37,50) →(450,30,60) en40 s →(750,45,40) en80 s →(600,37,50) en120 s |
| R1_fuera_dominio | 160 s | (800,25) →(200,25) en40 s →(900,60) en80 s →(600,37) en120 s; L50 |
| R2_instrumentacion | 180 s | G600/T37/L50; en60 s ganancia I +2%, ruido V8mV/I4mV; en120 s restaurar ganancia0 y ruido2mV/1mV |

S0–S4 son primarios. R1 prueba el respaldo; R2 prueba incertidumbre instrumental y no representa envejecimiento físico del panel. El salto de temperatura es un ensayo de sensibilidad de la planta digital, no una evolución térmica realista de un módulo. Las rampas ambientales de S1 son discretas y propias de este estudio; no se atribuyen a una tabla normativa.

En S3 el salto L60→40 puede llevar brevemente al circuito abierto por saturación de carga. Se registra, no se oculta ni se elimina; la recuperación vuelve a ser alcanzable con el rango de comando disponible. Las perturbaciones L0/L100 no se usan para exigir recuperación a un máximo fuera de la autoridad del actuador.

## 6. Repetición, separación de datos y sesgos

Banco host: 10 semillas de ruido por perfil y variante, emparejadas entre variantes; 350 ejecuciones en total. Cada proceso reinicia la planta y la red. La semilla se cambia exclusivamente en el arnés host después de inicializar el chip, sin editar la fuente del panel. El mismo ruido se asigna a los mismos instantes de simulación; las mediciones pueden diferir porque las trayectorias de control difieren.

Wokwi actual usa srand(1). Reiniciar diez veces la misma simulación no crea diez muestras independientes de ruido. Se reporta como repetición determinista de implementación. Los intervalos de confianza de las semillas host no se trasladan a Wokwi ni al mundo físico.

No se dividen aleatoriamente filas contiguas de un mismo barrido para aparentar generalización. Si se vuelve a entrenar, se separan condiciones completas y se conservan sin tocar perfiles finales. Los perfiles de este protocolo se definieron antes de ejecutar el banco host de esta entrega; no constituyen una preregistración externa.

## 7. Referencia independiente y métricas

La referencia de MPP proviene de las ecuaciones originales del panel, no de la salida neuronal:

Voc=clip(41.3·[1−0.003·(T−25)],0,41.3)

Isc=13.8·G/1000·[1+0.0004·(T−25)]

k=clip(8·[1−0.002·(T−25)],1,8)

r=(1/(k+1))^(1/k); Vmp*=Voc·r; Pmp*=Voc·r·Isc·k/(k+1).

A partir de la carga efectivamente aplicada u: V*=Voc·(1−u/100), I*=Isc·[1−(V*/Voc)^k]. Se calculan P*=V*I* y la eficiencia de seguimiento =100·∫P*dt/∫Pmp*dt. Es eficiencia respecto al modelo digital, no eficiencia de conversión de un convertidor. Se emplean G/T programados, no G/T medidos con error. Para Ns/Np distintos el analizador de esta entrega no es aplicable.

La potencia de telemetría Vmed·Imed se informa por separado. Con error de sensores su cociente respecto a Pmp* puede superar100%; no se recorta para simular una eficiencia física válida. La referencia física calculada evita ese sesgo en R2.

Métrica primaria: eficiencia energética por corrida y diferencia emparejada NN_ONLINE−NN_FROZEN en puntos porcentuales. Se usan los tiempos reales de telemetría, integración rectangular izquierda y el mismo intervalo observado por pareja. Se reportan ventanas de arranque y último tramo por separado; no se quita el arranque para mejorar un resultado total.

Métricas secundarias: energía en J; error de V respecto al MPP independiente; tiempo hasta cinco muestras consecutivas con |Vmed−Vmp*|≤0.20 V en cada meseta; desviación de V y P de los últimos10 s de cada meseta; RMSE de corriente ANTES de actualizar; número de actualizaciones; distancia paramétrica; tiempo de control; porcentaje de respaldo y saturación; retransmisiones y huecos de muestreo. Las rampas no se evalúan como tiempos de establecimiento. Si no alcanza el criterio se registra “no alcanzado”, no cero.

La referencia neuronal puede cambiar por aprendizaje y no se usa como verdad para medir recuperación. Que error_V de telemetría se anule no basta.

## 8. Análisis y criterio de interpretación

Se calcula para cada perfil la media de las diez diferencias emparejadas y un intervalo bootstrap de95% sobre las diez semillas. Se conservan también los valores individuales; el tamaño de muestra es diez corridas, no miles de filas. Los intervalos por perfil son descriptivos y no justifican seleccionar solo el favorable. Para una afirmación primaria agregada, calcular primero por semilla la diferencia de energía total S0–S4 dividida por la energía disponible total, y después el intervalo sobre las diez diferencias. R1/R2 se mantienen separados. No se declara significación confirmatoria por siete comparaciones sin corrección.

Una diferencia positiva muy pequeña respecto a cuantización e incertidumbre no se presenta como avance práctico. Umbral práctico exploratorio fijado aquí:0.1 punto porcentual de eficiencia energética agregada. Para sostener una mejora: diferencia agregada ≥0.1 pp, límite inferior del intervalo >0 y ausencia de degradaciones relevantes de estabilidad/comunicación; se publican todas las excepciones. Este umbral es de diseño del estudio y no proviene de IEC.

Si solo baja RMSE de corriente: mejora de identificación. Si cambia el contador pero no la energía: actualización sin beneficio energético demostrado. Si el respaldo resuelve las condiciones externas: robustez del sistema híbrido. Si NN_FROZEN funciona igual o mejor, se informa así y se revisa el valor del aprendizaje; no se baja el umbral de actualización para fabricar actividad.

## 9. Ejecución preparada y lo que todavía falta

`python3 tools/run_host.py 10` compila las fuentes C/C++ del banco y ejecuta los siete perfiles con cinco variantes y diez semillas. Requiere Python, NumPy, gcc y g++. Los archivos de referencia son copias exactas de la entrega experimental anterior; SHA256.json permite comprobarlo. Los stubs de tests solo se usan en el ordenador, nunca se suben a Wokwi.

La simulación host valida lógica y comparaciones emparejadas con mocks ADC/UART. La entrega incluye los resultados de esta ejecución. No mide tiempo de ejecución ESP32: micros() del mock devuelve tiempo simulado sin coste de cómputo. La entrega no instala ni reemplaza archivos de su proyecto Wokwi.

Wokwi ofrece escenarios YAML por CLI [7,8]. Se incluyen los siete escenarios en ese formato, dirigidos al componente `panel` y sus identificadores actuales. Son candidatos de automatización: su ejecución sobre los controles del chip personalizado y el firmware compilado debe comprobarse en Wokwi; aquí no se ha ejecutado esa ruta. Se necesita firmware compilado, configuración local de simulación y acceso CLI. No se incluye ni se solicita ninguna credencial.

Primera prueba Wokwi sin mover barras: S0, G600/T37/L50 durante120 s, una vez NN_FROZEN y una vez NN_ONLINE, reiniciando cada vez y guardando todo el serial. Permite contrastar aprendizaje en un punto conocido de interpolación y confirmar adquisición. Los perfiles dinámicos cuantitativos requieren automatización con eventos verificados; desplazar barras a mano sirve como demostración exploratoria, pero no garantiza perfiles idénticos.

Antes de aceptar una ejecución automática: verificar que la telemetría G/T y applied−confirmed reproducen los controles programados, que el modo automático está activo, que no hay NaN y que se cubre la ventana completa. Los controles de perturbación y los eventos se conservan como metadatos junto al log. Si la automatización de controles personalizados falla, hay que resolver el transporte externo; no reescribir silenciosamente las ecuaciones del panel.

La comparación final publicable necesita además: versiones de compilador/ESP32 y Wokwi; mediciones de tiempo y memoria en el destino; perfiles automáticos realmente ejecutados en Wokwi; análisis de incertidumbre; y una delimitación explícita de lo que no representa el modelo (dinámica PWM/convertidor, térmica real y sombreado parcial). El calendario editorial no sustituye estos controles.

## 10. Fuentes primarias

[1] Abouzeid, A. F. et al. Experimental validation of a low-cost maximum power point tracking technique based on artificial neural network for photovoltaic systems. Scientific Reports14,18280(2024). https://doi.org/10.1038/s41598-024-67306-0

[2] Giraldo, L. F. et al. Deep reinforcement learning using deep-Q-network for Global Maximum Power Point tracking: Design and experiments in real photovoltaic systems. Heliyon10,e37974(2024). https://doi.org/10.1016/j.heliyon.2024.e37974

[3] Amine, R. et al. Real-Time Incremental Learning Artificial Neural Networks Maximum Power Point Tracking With Raspberry Pi-Based Meteorological Data Acquisition. Energy Science & Engineering14,3741–3773(2026). https://doi.org/10.1002/ese3.70555

[4] Ogunfowora, A. R.; Bhattacharya, I. Solar Photovoltaic Maximum Power Point Tracking (MPPT): A Comparative Analysis of Incremental Conductance, Q-Learning, and Transformer Deep Learning for Performance Evaluation Under Standard and Dynamic Environmental Scenarios. Energies19,3183(2026). https://doi.org/10.3390/en19133183

[5] Jamshed, J. et al. Hardware-in-the-Loop Assessment of Neural MPPT Control in Photovoltaic Systems with Two-Phase Boost Conversion. Electronics15,4342(2026). https://doi.org/10.3390/electronics15184342

[6] IEC62891:2020. Maximum power point tracking efficiency of grid connected photovoltaic inverters. Ficha oficial, no consulta completa de la norma: https://webstore.iec.ch/en/publication/28105

[7] Wokwi. Automation Scenarios. https://docs.wokwi.com/wokwi-ci/automation-scenarios

[8] Wokwi. CLI Usage. https://docs.wokwi.com/wokwi-ci/cli-usage

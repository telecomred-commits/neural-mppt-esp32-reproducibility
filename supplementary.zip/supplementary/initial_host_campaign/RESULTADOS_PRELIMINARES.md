# Resultados preliminares: banco host, no ESP32 físico

La versión actual regula el panel digital, pero este experimento no respalda una mejora energética causada por el aprendizaje en línea. No se han cambiado los pesos o los algoritmos para favorecer el resultado.

Se ejecutaron 350 corridas: siete perfiles × cinco variantes × diez semillas de ruido. Las fuentes del firmware y del chip son idénticas a la copia experimental anterior. ADC y UART se conectan mediante mocks host; no hay convertidor físico ni medición de coste de cómputo ESP32.

## Resultado primario agregado S0–S4

Cada porcentaje es la media de diez eficiencias calculadas por semilla, integrando todos los perfiles primarios y dividiendo por la energía disponible del modelo original. Se incluyen los transitorios. La integración cubre el intervalo efectivamente registrado, no los extremos sin muestras.

| Variante | Eficiencia de seguimiento respecto a la planta digital |
|---|---:|
| PO | 98.1173% |
| INC | 98.3646% |
| ADAPT_PO | 97.1373% |
| NN_FROZEN | 99.4294% |
| NN_ONLINE | 99.4274% |

NN_ONLINE−NN_FROZEN: **-0.00201 puntos porcentuales**, IC bootstrap95% [-0.00222, -0.00181]. Es una diferencia negativa muy pequeña; no representa una degradación práctica demostrada en hardware, pero no cumple la hipótesis de mejora ni el umbral práctico de0.1pp fijado en el protocolo.

## Resultado por perfil

| Perfil | NN congelada (%) | NN en línea (%) | Diferencia (pp) | Actualizaciones medias NN en línea |
|---|---:|---:|---:|---:|
| S0_inedito | 99.5466 | 99.5453 | -0.00130 | 10.0 |
| S1_irradiancia | 99.5564 | 99.5564 | +0.00000 | 0.4 |
| S2_temperatura | 99.6119 | 99.6104 | -0.00145 | 82.5 |
| S3_carga | 99.2761 | 99.2754 | -0.00068 | 4.8 |
| S4_combinado | 99.1862 | 99.1789 | -0.00730 | 30.7 |
| R1_fuera_dominio | 99.4986 | 99.4978 | -0.00082 | 16.6 |
| R2_instrumentacion | 99.6934 | 99.6785 | -0.01489 | 67.8 |

La red congelada supera a las tres implementaciones convencionales en este banco y con estos parámetros. No se concluye superioridad universal de las redes: se conoce la planta, las condiciones guardan relación con el entrenamiento, la selección de pasos influye y no se ha añadido aquí el control de referencia afín ya ensayado.

Las actualizaciones son reales en la simulación. Su número no mide aprendizaje útil para el control: la identificación local de corriente puede alterar ligeramente la referencia sin aumentar energía. En S1 hay actualizaciones aisladas sin cambiar la trayectoria de control, debido a la cuantización del máximo y la zona muerta.

En R2 se perturba la medición de corriente, no la física de la planta. Ajustarse a esa medición puede absorber sesgo instrumental. Este ensayo no demuestra adaptación a envejecimiento del panel.

## Comprobaciones realizadas

- Las cuatro fuentes de referencia coinciden byte a byte con la entrega experimental anterior.
- Los siete YAML contienen los mismos eventos y duraciones que sus perfiles JSON.
- La referencia analítica del MPP coincide con una búsqueda numérica densa en25 condiciones.
- Los350 logs son finitos, tienen cadencia500ms y no registran retransmisiones en el mock.
- NN_FROZEN no actualiza parámetros.
- Las ventanas observadas son iguales entre variantes de cada perfil y semilla.

Estas comprobaciones son del banco host; no certifican UART real, tiempos de firmware ni la ejecución automática de controles personalizados en Wokwi.

## Siguiente ejecución

Primero contrastar S0 en el Wokwi actual, durante120s con aprendizaje0 y luego1, reiniciando entre corridas. Esto comprueba que la comparación funciona en el entorno del usuario sin manipular barras durante la prueba. Después verificar la ruta YAML/CLI para los perfiles dinámicos y ejecutar ambas variantes con exactamente los mismos eventos.

Para sostener un artículo centrado en aprendizaje que mejora MPPT, aún falta demostrar beneficio energético en datos y condiciones independientes. No se recomienda aumentar artificialmente las actualizaciones ni cambiar la planta para obtener ese resultado. Si se modifica el algoritmo, conservar esta versión y este resultado como línea base; usar perfiles de desarrollo separados y nuevas pruebas finales.

Los JSON y registros completos permiten auditar todos los números. Los intervalos son variabilidad de ruido dentro del mismo modelo, no incertidumbre sobre paneles reales.

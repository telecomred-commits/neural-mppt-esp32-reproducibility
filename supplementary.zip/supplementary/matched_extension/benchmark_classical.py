"""Matched classical baselines for the fixed V8/V9 host comparison.

Reads the existing firmware. Only compile-time MPPT_MODE changes. No plant,
controller, circuit or candidate parameter is modified.
"""
from pathlib import Path
import argparse,subprocess,tempfile,json,sys,hashlib
import numpy as np

def main():
 p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--chip',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 root=args.project.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
 sys.path.insert(0,str(root/'tools'));from bench_v9 import parse_full;from host_metrics import analyze
 profiles=json.loads((root/'perfiles/profiles.json').read_text());chip=args.chip.resolve();frozen={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [chip,*[root/'firmware'/n for n in ['sketch.ino','mppt_neural.h','mppt_weights.h']]]}
 (out/'freeze.json').write_text(json.dumps(dict(inputs=frozen,seeds=list(range(11,21)),profiles=[x['id'] for x in profiles],status='host-only matched classical comparison'),indent=2));metrics=[]
 with tempfile.TemporaryDirectory() as td:
  work=Path(td);common=['-O2','-Wall','-Wextra','-Werror','-I',str(root/'tests/stubs')]
  for name,src in [('chip',chip),('host',root/'tests/chip_host.c')]:subprocess.run(['gcc','-std=c11','-DM_PI=3.14159265358979323846',*common,'-c',str(src),'-o',str(work/f'{name}.o')],check=True)
  cpp=(root/'tests/benchmark_template.cpp').read_text().replace('#include "../referencia/sketch.ino"',f'#include "{root}/firmware/sketch.ino"');(work/'bench.cpp').write_text(cpp)
  for label,mode in [('PO',0),('INC',1),('ADAPT_PO',2)]:
   exe=work/label
   subprocess.run(['g++','-std=c++11',*common,f'-DMPPT_MODE={mode}','-DMPPT_ONLINE_LEARNING=0',str(work/'bench.cpp'),str(work/'chip.o'),str(work/'host.o'),'-lm','-o',str(exe)],check=True)
   for profile in profiles:
    for seed in range(11,21):
     result=subprocess.run([str(exe),str(root/f"perfiles/{profile['id']}.events"),str(seed),str(profile['duration_ms'])],check=True,capture_output=True,text=True)
     raw=f'# MATCHED_CLASSICAL_HOST variant={label} seed={seed} NOT_A_WOKWI_RUN\n'+result.stdout
     (out/f"{label}_{profile['id']}_seed{seed:02d}.txt").write_text(raw);full=parse_full(raw);a=full[:,:23]
     assert np.isfinite(a).all() and np.all(np.diff(a[:,0])==500) and np.max(a[:,22])==0
     assert np.all(a[:,17:20]==0) and np.all(a[:,11]==10+mode)
     m=analyze(a,profile);m.update(variant=label,profile=profile['id'],seed=seed);metrics.append(m)
   print(label,'complete',flush=True)
 assert len(metrics)==330
 for path,digest in frozen.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
 (out/'metrics.json').write_text(json.dumps(metrics,indent=2));print('330 matched classical runs complete')

if __name__=='__main__':main()

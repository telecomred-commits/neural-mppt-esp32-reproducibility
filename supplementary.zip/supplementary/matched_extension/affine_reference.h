#pragma once
#include <cmath>
#include <cstdint>
#include "mppt_weights.h"
// Laboratory comparator only. Same measured calibration anchors as NN-C/V8.
// No analytic plant MPP, current model or neural parameter updates are used.
namespace mppt {
inline float clamp(float x,float lo,float hi){return x<lo?lo:(x>hi?hi:x);}
struct Decision {
 float load,delta,reference,error,predicted_current,model_error,parameter_change;
 uint32_t learning_updates;int source;bool reference_valid,at_limit,learned;
 float nn_reference,power_reference,power_slope,peak_noise_V,loss_before,loss_after,measured_slope;
 uint32_t power_checks,learning_rejections;int probe_phase,gradient_valid,learning_reason,verification_kind;
};
class Controller {
 public:
 explicit Controller(bool learning=true){(void)learning;}
 Decision update(float v,float i,float g,float t,float load,float applied=-1){
  (void)applied;Decision d={};d.load=std::isfinite(load)?clamp(load,0,100):50;d.source=4;
  if(!std::isfinite(v)||!std::isfinite(i)||!std::isfinite(g)||!std::isfinite(t)||!std::isfinite(load)||v<0||i<0)return d;
  float step=0;
  if(g>=399&&g<=801&&t>=24.9f&&t<=50.1f){
   const float tc=clamp(t,25,50),v0=mppt_weights::measured_mpp_anchors[0][0],t0=mppt_weights::measured_mpp_anchors[0][1];
   const float v1=mppt_weights::measured_mpp_anchors[1][0],t1=mppt_weights::measured_mpp_anchors[1][1];
   d.reference=v0+(tc-t0)*(v1-v0)/(t1-t0);d.error=v-d.reference;d.reference_valid=true;d.source=6;
   step=std::fabs(d.error)<=.05f?0:clamp(.5f*d.error,-3,3);
  }else{
   d.source=initialized_?3:0;
   if(initialized_){const float dv=v-prev_v_,di=i-prev_i_;
    if(std::fabs(dv)<.05f){if(std::fabs(di)>=.02f)step=di>0?-1.0f:1.0f;}
    else if(v>1e-6f){const float c=di/dv+i/v;if(std::fabs(c)>=.01f)step=c>0?-1.0f:1.0f;}
   }
  }
  const float before=d.load;d.load=clamp(before+step,0,100);d.delta=d.load-before;d.at_limit=d.load<=0||d.load>=100;
  prev_v_=v;prev_i_=i;initialized_=true;return d;
 }
 private:
 float prev_v_=0,prev_i_=0;bool initialized_=false;
};
}

from pathlib import Path
import argparse,sys,tempfile,subprocess,json,hashlib,shutil
import numpy as np

def main():
 p=argparse.ArgumentParser();p.add_argument('--project',required=True,type=Path);p.add_argument('--chip',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
 root=a.project.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(root/'tools'))
 from bench_v9 import parse_full
 from host_metrics import analyze
 chip=a.chip.resolve();chip_hash=hashlib.sha256(chip.read_bytes()).hexdigest();profiles=json.loads((root/'perfiles/profiles.json').read_text());metrics=[]
 (out/'freeze.json').write_text(json.dumps(dict(chip_sha256=chip_hash,affine_header_sha256=hashlib.sha256(Path(__file__).with_name('affine_reference.h').read_bytes()).hexdigest(),seeds=list(range(11,21)),calibration='same measured sweep-derived anchors as V8; no analytic MPP labels'),indent=2))
 with tempfile.TemporaryDirectory() as td:
  work=Path(td);common=['-O2','-Wall','-Wextra','-Werror','-I',str(root/'tests/stubs')]
  for name,src in [('chip',chip),('host',root/'tests/chip_host.c')]:subprocess.run(['gcc','-std=c11','-DM_PI=3.14159265358979323846',*common,'-c',str(src),'-o',str(work/f'{name}.o')],check=True)
  shutil.copyfile(root/'firmware/sketch.ino',work/'sketch.ino');shutil.copyfile(root/'firmware/mppt_weights.h',work/'mppt_weights.h');shutil.copyfile(Path(__file__).with_name('affine_reference.h'),work/'mppt_neural.h')
  cpp=(root/'tests/benchmark_template.cpp').read_text().replace('#include "../referencia/sketch.ino"',f'#include "{work}/sketch.ino"');(work/'bench.cpp').write_text(cpp);exe=work/'bench'
  subprocess.run(['g++','-std=c++11',*common,'-DMPPT_MODE=3','-DMPPT_ONLINE_LEARNING=0',str(work/'bench.cpp'),str(work/'chip.o'),str(work/'host.o'),'-lm','-o',str(exe)],check=True)
  for profile in profiles:
   for seed in range(11,21):
    result=subprocess.run([str(exe),str(root/f"perfiles/{profile['id']}.events"),str(seed),str(profile['duration_ms'])],check=True,capture_output=True,text=True)
    raw='# AFFINE_LAB_ONLY NOT_A_WOKWI_RUN\n'+result.stdout;(out/f"AFFINE_{profile['id']}_seed{seed:02d}.txt").write_text(raw);full=parse_full(raw);arr=full[:,:23]
    assert np.isfinite(arr).all() and np.all(np.diff(arr[:,0])==500) and np.max(arr[:,22])==0 and np.all(arr[:,17:20]==0)
    m=analyze(arr,profile);m.update(variant='AFFINE',profile=profile['id'],seed=seed,preupdate_I_error_RMSE_covered_A=None);metrics.append(m)
 assert chip_hash==hashlib.sha256(chip.read_bytes()).hexdigest() and len(metrics)==110
 (out/'metrics.json').write_text(json.dumps(metrics,indent=2));print('110 affine comparator runs complete')

if __name__=='__main__':main()

"""Read-only audit and fixed-input C++ replay. No identification of a user's binary.

The two code models are explicit laboratory references, not assertions about
which code generated an uploaded trace. New data are not used for retraining.
"""
from pathlib import Path
import csv,hashlib,json,re,subprocess,tempfile,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
NAMES=['MPPT_MODE _S4_NN_FROZEN.txt','MPPT_MODE_S4_NN_ONLINE.txt',
 'MPPT_ONLINE_LEARNING_S4_NN_ONLINE.txt','MPPT_ONLINE_LEARNING_S4_NN_FROZEN.txt',
 'MPPT_ONLINE_LEARNING_S2_NN_FROZEN.txt','MPPT_ONLINE_LEARNING_S2_NN_ONLINE.txt',
 'MPPTMODE_S2_NN_ONLINE.txt','MPPTMODE_S2_NN_FROZEN.txt']
COLS='t_ms V_V I_A P_W G_Wm2 T_C ACK_seq confirmed_cmd_pct applied_pct next_cmd_pct Delta_cmd_pct source ref_valid Vmp_model_V error_V I_pred_A model_error_A learning_updates learned parameter_change control_us at_limit retries'.split()

def parse(path):
 text=path.read_text(encoding='utf-8-sig').replace('\\r\\n','\n').replace('\\n','\n').replace('\\t','\t').replace('\\r','\r')
 out=[];bad=[]
 for ln,line in enumerate(text.splitlines(),1):
  f=line.split()
  if not f or not re.fullmatch(r'\d+',f[0]):continue
  if len(f)!=23:bad.append([ln,len(f)]);continue
  out.append(list(map(float,f)))
 return np.asarray(out),bad

def truth_v(t):
 voc=np.clip(41.3*(1-.003*(t-25)),0,41.3);k=np.clip(8*(1-.002*(t-25)),1,8)
 return voc*(1/(k+1))**(1/k)

def runs(a):
 slider=a[:,8]-a[:,7]+50
 keys=[(round(g),round(t),round(l)) for g,t,l in zip(a[:,4],a[:,5],slider)]
 start=0
 for stop in range(1,len(a)+1):
  if stop<len(a) and keys[stop]==keys[start]:continue
  ids=np.arange(start,stop)
  if (a[ids[-1],0]-a[ids[0],0])>=15000:yield keys[start],ids
  start=stop

def weights(path):
 text=path.read_text();z=[]
 for name in ['w0','b0','w1','b1']:
  line=next(x for x in text.splitlines() if ' '+name+'[' in x)
  z.extend(map(float,re.findall(r'[-+]?\d+\.\d+e[-+]\d+',line,re.I)))
 return np.asarray(z)

def evaluate(z,v,g,t):
 x=np.c_[(np.asarray(v)-21)/21,np.full(len(v),(t-37.5)/12.5)]
 h=np.tanh(x@z[:32].reshape(2,16)+z[32:48]);return np.clip(h@z[48:64]+z[64],0,1.5)*14*g/1000

def main():
 for d in ['normalizados','resultados','figuras','replay']:(ROOT/d).mkdir(exist_ok=True)
 arrays={};inventory=[];plateaus=[];replay=[];snapshots={}
 for n,fn in enumerate(NAMES):
  a,bad=parse(ROOT/'datos'/fn);arrays[fn]=a
  np.savetxt(ROOT/'normalizados'/f'{n:02d}.csv',a,delimiter=',',header=','.join(COLS),comments='',fmt='%.9g')
  no_step=(abs(a[:,10])<.0001)&(a[:,12]==1);step=(abs(a[:,10])>=.0001)&(a[:,12]==1)
  inventory.append(dict(index=n,file=fn,samples=len(a),sha256=hashlib.sha256((ROOT/'datos'/fn).read_bytes()).hexdigest(),bad_rows=bad,
    updates=int(a[-1,17]),parameter_distance=float(a[-1,19]),zero_step_largest_abs_error_V=float(abs(a[no_step,14]).max()),
    nonzero_step_smallest_abs_error_V=float(abs(a[step,14]).min()),cadence_500ms=bool(np.all(np.diff(a[:,0])==500)),
    finite=bool(np.isfinite(a).all()),ACK_consecutive=bool(np.all(np.diff(a[:,6])==1)),retries_max=int(a[:,22].max()),fallback_samples=int(np.sum(a[:,11]==3))))
  for key,ids in runs(a):
   tail=ids[a[ids,0]>=a[ids[-1],0]-10000];ref=a[tail,13];v=a[tail,1];star=truth_v(a[tail,5]);total=v-star
   r=dict(file=fn,index=n,G=key[0],T=key[1],load=key[2],start_s=float(a[ids[0],0]/1000),end_s=float(a[ids[-1],0]/1000),tail_n=len(tail),
     I_RMSE_A=float(np.sqrt(np.mean(a[tail,16]**2))),reference_V=float(ref.mean()),V_mean_V=float(v.mean()),Vmp_panel_V=float(star.mean()),
     reference_bias_V=float(np.mean(ref-star)),regulation_offset_V=float(np.mean(v-ref)),total_signed_bias_V=float(total.mean()),
     total_MAE_V=float(abs(total).mean()),within_0p2V_pct=float(np.mean(abs(total)<=.2)*100),tail_first_index=int(tail[0]),tail_last_index=int(tail[-1]))
   assert abs(r['reference_bias_V']+r['regulation_offset_V']-r['total_signed_bias_V'])<1e-10
   plateaus.append(r)
 with tempfile.TemporaryDirectory() as td:
  work=Path(td)
  for model in ['A','B']:
   exe=work/model
   subprocess.run(['g++','-std=c++11','-O2','-Wall','-Wextra','-Werror','-I',str(ROOT/f'modelos/{model}'),str(ROOT/'tools/replay.cpp'),'-o',str(exe)],check=True)
   for n,fn in enumerate(NAMES):
    a=arrays[fn]
    for online in [0,1]:
     out=ROOT/'replay'/f'{model}_{n:02d}_online{online}.csv'
     result=subprocess.run([str(exe),str(ROOT/'normalizados'/f'{n:02d}.csv'),str(online)],check=True,capture_output=True,text=True);out.write_text(result.stdout)
     b=np.loadtxt(out,delimiter=',',skiprows=1);snapshots[(model,n,online)]=b
     for p in [x for x in plateaus if x['index']==n]:
      ids=np.arange(p['tail_first_index'],p['tail_last_index']+1)
      replay.append(dict(file=fn,index=n,model=model,online=online,G=p['G'],T=p['T'],load=p['load'],end_s=p['end_s'],
       I_RMSE_same_inputs_A=float(np.sqrt(np.mean((b[ids,1]-a[ids,2])**2))),
       q_at_true_MPP_RMS_A=float(np.sqrt(np.mean(b[ids,5]**2))),
       reference_MAE_same_inputs_V=float(np.mean(abs(b[ids,3]-truth_v(a[ids,5])))),updates_at_end=int(b[ids[-1],6])))
  # A mathematical counterexample: same current at one voltage, different power maximum.
  t=37.;g=800.;vstar=float(truth_v(t));voc=41.3*(1-.003*(t-25));k=8*(1-.002*(t-25));isc=13.8*g/1000*(1+.0004*(t-25));v=np.linspace(0,voc,10001)
  exact=isc*(1-(v/voc)**k);counter=[]
  for slope in [-.05,0,.05]:
   shifted=exact+slope*(v-vstar);m=np.argmax(v*shifted)
   counter.append(dict(slope_error_A_per_V=slope,current_error_at_reference_A=0.,Vmp_modified_V=float(v[m]),Vmp_original_V=vstar,MPP_displacement_V=float(v[m]-vstar),power_slope_at_original_MPP_W_per_V=vstar*slope))
  (ROOT/'resultados/counterexample.json').write_text(json.dumps(counter,indent=2))
  # Independent analytical derivative validation by central differences, lab only.
  derivative_checks=[]
  for model in ['A','B']:
   z=weights(ROOT/f'modelos/{model}/mppt_weights.h');vv=np.array([20.,28.,30.,32.]);tt=37.;gg=600.;h=np.tanh(np.c_[(vv-21)/21,np.full(4,(tt-37.5)/12.5)]@z[:32].reshape(2,16)+z[32:48]);dy=((1-h*h)*(z[:16]/21))@z[48:64]*14*gg/1000
   eps=1e-4;fd=(evaluate(z,vv+eps,gg,tt)-evaluate(z,vv-eps,gg,tt))/(2*eps)
   error=float(np.max(abs(dy-fd)));assert error<1e-7
   derivative_checks.append(dict(model=model,max_central_difference_error_A_per_V=error))
 correspondence=[]
 for item in inventory:
  n=item['index'];a=arrays[item['file']];flag=int(item['file'].endswith('_NN_ONLINE.txt'));b=snapshots[('A',n,flag)]
  correspondence.append(dict(file=item['file'],online=flag,updates_observed=item['updates'],updates_lab=int(b[-1,6]),
   Ipred_MAE_A=float(np.mean(abs(a[:,15]-b[:,1]))),reference_MAE_V=float(np.mean(abs(a[:,13]-b[:,3])))))
  assert item['updates']==int(b[-1,6])
 z=weights(ROOT/'modelos/A/mppt_weights.h')
 point=next(p for p in plateaus if p['index']==6 and p['T']==37 and p['end_s']>80)
 local=arrays[NAMES[6]][point['tail_first_index']:point['tail_last_index']+1]
 h=np.tanh(np.c_[(local[:,1]-21)/21,(local[:,5]-37.5)/12.5]@z[:32].reshape(2,16)+z[32:48])
 singular=np.linalg.svd(np.c_[h,np.ones(len(h))],compute_uv=False)
 excitation=dict(samples=len(local),V_min=float(local[:,1].min()),V_max=float(local[:,1].max()),feature_parameters=17,
  relative_tolerance=1e-6,numerical_rank=int(np.sum(singular>singular[0]*1e-6)),singular_values=singular.tolist(),
  interpretation='Numerical information content of this observed local window, not proof of global structural unidentifiability')
 (ROOT/'resultados/local_excitation.json').write_text(json.dumps(excitation,indent=2))
 for fn,values in [('inventory',inventory),('decomposition',plateaus),('fixed_input_replay',replay),('derivative_checks',derivative_checks),('replay_correspondence',correspondence)]:
  (ROOT/f'resultados/{fn}.json').write_text(json.dumps(values,ensure_ascii=False,indent=2))
  if fn!='inventory' and values:
   with (ROOT/f'resultados/{fn}.csv').open('w',newline='') as f:w=csv.DictWriter(f,values[0].keys());w.writeheader();w.writerows(values)
 # Diagnostic figures use selected equal-condition plateaus, explicitly not causal energy pairs.
 selected=[]
 for n,t in [(7,37),(6,37),(7,50),(6,50),(0,45),(1,45)]:
  selected.append([r for r in plateaus if r['index']==n and r['T']==t][-1])
 plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.2,'savefig.facecolor':'white'})
 fig,axs=plt.subplots(1,2,figsize=(11,4.5),layout='constrained');x=np.arange(len(selected))
 labels=['S2 37°C\nFROZEN','S2 37°C\nONLINE','S2 50°C\nFROZEN','S2 50°C\nONLINE','S4 45°C\nFROZEN','S4 45°C\nONLINE']
 axs[0].bar(x-.18,[r['reference_bias_V'] for r in selected],.35,label='Sesgo de referencia',color='#0072B2');axs[0].bar(x+.18,[r['regulation_offset_V'] for r in selected],.35,label='Desviación respecto a referencia',color='#D55E00');axs[0].plot(x,[r['total_signed_bias_V'] for r in selected],'ko',label='Error total con signo');axs[0].axhline(0,color='black',lw=.7);axs[0].set_ylabel('Tensión (V)');axs[0].set_xticks(x,labels,fontsize=8);axs[0].legend(fontsize=8);axs[0].set_title('Descomposición en los registros')
 axs[1].bar(x,[r['I_RMSE_A'] for r in selected],color=['#777777','#009E73']*3);axs[1].set_xticks(x,labels,fontsize=8);axs[1].set_ylabel('RMSE de corriente (A)');axs[1].set_title('Error local de corriente')
 fig.savefig(ROOT/'figuras/separacion_observada.png',dpi=180);plt.close(fig)
 # Same-input replay, A on the same measured S2 ONLINE trajectory. Last37°C plateau.
 subset=[r for r in replay if r['index']==6 and r['model']=='A' and r['T']==37 and r['end_s']>80]
 fig,axs=plt.subplots(1,3,figsize=(10,3.6),layout='constrained')
 for ax,key,title,ylabel in zip(axs,['I_RMSE_same_inputs_A','q_at_true_MPP_RMS_A','reference_MAE_same_inputs_V'],['Predicción de corriente','Pendiente de potencia en el MPP','Referencia calculada'],['RMSE (A)','RMS de dP/dV (W/V)','Error absoluto medio (V)']):
  ax.bar(['Sin actualizar','Con actualización'],[next(r[key] for r in subset if r['online']==flag) for flag in [0,1]],color=['#777777','#009E73']);ax.set_title(title,fontsize=10);ax.set_ylabel(ylabel)
 fig.suptitle('Reproducción con idénticas entradas · modelo de laboratorio A',fontsize=11);fig.savefig(ROOT/'figuras/replay_entradas_identicas.png',dpi=180);plt.close(fig)
 print(json.dumps({'files':len(NAMES),'samples':sum(i['samples'] for i in inventory),'selected_decomposition':selected,'same_input_replay_S2_37':subset,'counterexample':counter,'derivative_checks':derivative_checks},ensure_ascii=False,indent=2))

if __name__=='__main__':main()

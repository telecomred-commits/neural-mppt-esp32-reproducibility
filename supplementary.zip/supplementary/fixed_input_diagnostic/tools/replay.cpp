#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#define private public
#include "mppt_neural.h"
#undef private

static double truth_v(double t) {
 const double voc=std::fmax(0.,std::fmin(41.3,41.3*(1-.003*(t-25))));
 const double k=std::fmax(1.,std::fmin(8.,8*(1-.002*(t-25))));
 return voc*std::pow(1/(k+1),1/k);
}
static double model_q(const mppt::Controller& c,double v,double g,double t) {
 double y=c.bias_,dy=0;
 for(int j=0;j<16;++j){
  double h=std::tanh(mppt_weights::b0[j]+(v-21)/21*mppt_weights::w0[0][j]+(t-37.5)/12.5*mppt_weights::w0[1][j]);
  y+=c.out_[j]*h;dy+=c.out_[j]*(1-h*h)*mppt_weights::w0[0][j]/21;
 }
 if(y<=0||y>=1.5)dy=0;
 y=std::fmax(0.,std::fmin(1.5,y));
 return (y+v*dy)*14*g/1000;
}
int main(int argc,char**argv){
 if(argc!=3)return 2;
 mppt::Controller c(std::atoi(argv[2])!=0);
 std::ifstream in(argv[1]);std::string line;
 std::puts("t_ms,predicted_pre_A,reference_pre_V,reference_post_V,q_true_mpp_pre_A,q_true_mpp_post_A,updates,parameter_distance,learned,theta0,theta1,theta2,theta3,theta4,theta5,theta6,theta7,theta8,theta9,theta10,theta11,theta12,theta13,theta14,theta15,theta16");
 std::getline(in,line);
 while(std::getline(in,line)){
  for(char&z:line)if(z==',')z=' ';
  std::istringstream row(line);std::vector<double>a;double value;
  while(row>>value)a.push_back(value);
  if(a.size()!=23)return 3;
  const bool covered=a[4]>=399&&a[4]<=801&&a[5]>=24.9&&a[5]<=50.1;
  const float g=mppt::clamp(a[4],400,800),t=mppt::clamp(a[5],25,50);
  const double v=truth_v(a[5]);
  const double pred=covered?c.predict(a[1],g,t):0;
  const double ref=covered?c.target(g,t):0;
  const double q=covered?model_q(c,v,g,t):0;
  auto d=c.update(a[1],a[2],a[4],a[5],a[7]);
  const double post=covered?model_q(c,v,g,t):0;
  std::printf("%.0f,%.9g,%.9g,%.9g,%.9g,%.9g,%u,%.9g,%d",a[0],pred,ref,double(d.reference),q,post,d.learning_updates,double(d.parameter_change),int(d.learned));
  for(int j=0;j<16;++j)std::printf(",%.9g",double(c.out_[j]));
  std::printf(",%.9g\n",double(c.bias_));
 }
 return 0;
}

# MPPT inteligente: matriz comparativa y posición de la propuesta

Consulta: 27 de octubre de 2026 (UTC). Se examinan diez estudios originales y la versión del algoritmo que estamos evaluando. La matriz detallada está en el archivo Excel. Los DOI se contrastaron con Crossref. Se consultaron nueve textos completos. Para Dounis et al. solo se obtuvo el resumen editorial, por lo que sus detalles no comprobados quedan señalados.

## Alcance de la comparación

La selección cubre aprendizaje neuronal en línea, redes previamente entrenadas, modelos híbridos y aprendizaje por refuerzo. Es una revisión dirigida. No permite afirmar exhaustividad ni prioridad de nuestra combinación. Tampoco permite ordenar eficiencias de distintos artículos como si procedieran del mismo experimento. Las celdas «Diferencia» son nuestra interpretación de los métodos consultados frente al firmware inspeccionado.

Se distingue entre actualizar la salida de un controlador y modificar los parámetros que aprendió. Un modelo previamente entrenado puede responder a cambios ambientales sin aprender durante la operación. En los métodos por refuerzo se distingue el entrenamiento del agente de su posterior despliegue.

## Lo que identifica la matriz

La adaptación neuronal y su combinación con MPPT convencional tienen antecedentes anteriores a esta propuesta. La ejecución en ESP32 también aparece en la literatura. No corresponde presentar ninguna de esas características aisladas como una contribución nueva.

Nuestra versión aprende a predecir corriente. Usa una red 2–16–1 con 65 parámetros y actualiza 16 pesos y el sesgo de salida. Son 17 parámetros en total. Las 48 constantes de la capa oculta permanecen fijas. El ajuste normalizado limita el residuo y proyecta cada parámetro respecto a su valor inicial. La corriente medida proporciona el objetivo de aprendizaje.

Después de actualizar, el controlador busca el máximo de V·Iestimada. Evalúa 101 candidatos gruesos y 21 de refinamiento por ciclo. Esa búsqueda produce una referencia de tensión. Un regulador separado convierte el error de tensión en una corrección de carga virtual. Fuera del dominio ambiental admitido interviene INC. Estas operaciones se distinguen de una red que entrega directamente D o de un agente que aprende acciones mediante recompensas.

El firmware adquiere V,I,G,T. La red interna recibe V y T normalizados. G entra como factor multiplicativo, mientras que I se usa para calcular el error de aprendizaje. Por ello, contar cuatro variables adquiridas como cuatro entradas de la red sería incorrecto.

Con pesos fijos y G positivo, el factor G/1000 se cancela al buscar el máximo. Nuestra referencia Vmp no cambia por G solo en esa situación. La planta digital también mantiene la posición del máximo al variar exclusivamente G a temperatura constante. Esto explica parte del seguimiento observado y limita la evidencia que una prueba de irradiancia puede aportar sobre aprendizaje.

## Diferencias que podemos documentar

Podemos describir y evaluar la combinación de un identificador de corriente con actualización acotada de salida, una búsqueda de referencia y respaldo INC dentro del firmware destinado al ESP32. La comparación con el mismo controlador congelado permite comprobar qué cambia por actualizar los parámetros. El protocolo conserva las mismas mediciones, perfiles y límites, y trata por separado los errores de adquisición.

Estos rasgos son una formulación del alcance del trabajo. No demuestran que la combinación sea inédita. La matriz identifica antecedentes próximos que deben citarse antes de formular una afirmación de novedad.

## Lo que aún no podemos afirmar

Los resultados host primarios dan 99.4274% con aprendizaje y 99.4294% con pesos congelados. La diferencia online−congelado es −0.00201 puntos porcentuales. La pareja estática Wokwi reduce el RMSE de corriente de 0.1483 A a 0.0135 A en sus últimos 30 s, pero no muestra una ganancia energética del ajuste. Son resultados del proyecto. No se comparan numéricamente con eficiencias publicadas en otros bancos.

No se ha demostrado seguimiento global bajo sombreado parcial. El panel evaluado tiene un máximo. Wokwi tampoco constituye una prueba con un ESP32 físico y un convertidor de potencia. Los tiempos comunicados por el simulador no deben utilizarse para atribuir ventaja frente a mediciones de hardware de otros autores.

El entrenamiento inicial contiene 1012 muestras procedentes de cuatro condiciones ambientales. Las filas de un mismo barrido no son condiciones independientes. Las trazas históricas P&O, POINC y POINCADA son antecedentes y comparadores. En la versión evaluada no se usaron sus órdenes de carga como etiquetas del entrenamiento inicial.

## Consecuencia para el experimento y el artículo

La pregunta debe seguir siendo si el ajuste local mejora el seguimiento energético bajo condiciones que no resuelve igual el modelo congelado. Conviene conservar el control online/congelado y añadir, en un experimento identificado aparte, el predictor afín de Vmp que ya ensayamos. Ese control permitiría examinar si la representación neuronal aporta algo frente a una referencia térmica sencilla.

Antes de afirmar una ventaja embebida se requieren tiempo del ciclo completo y memoria en el dispositivo físico. La comparación debe incluir la búsqueda de referencia, no solo una inferencia. Una menor complejidad no se deduce únicamente del número de neuronas.

La tabla de literatura puede incorporarse al estado del arte. Materiales y métodos debe mantener el desarrollo del algoritmo y el protocolo que permite contrastar su contribución. Esta entrega no modifica el manuscrito ni el código.

## Referencias comprobadas

**[01]** Yasushi Kohata, Koichiro Yamauchi, Masahito Kurihara. High-Speed Maximum Power Point Tracker for Photovoltaic Systems Using Online Learning Neural Networks. *Journal of Advanced Computational Intelligence and Intelligent Informatics*. 2010;14(6):677-682. [DOI:10.20965/jaciii.2010.p0677](https://doi.org/10.20965/jaciii.2010.p0677).

Fuente consultada: https://www.fujipress.jp/jaciii/jc/jacii001400060677/. Texto completo, PDF editorial. Localización: §3.2–3.4 y §4, pp.678–682.

**[02]** Anastasios I. Dounis, P. Kofinas, G. Papadakis, C. Alafodimos. A direct adaptive neural control for maximum power point tracking of photovoltaic system. *Solar Energy*. 2015;115(—):145-165. [DOI:10.1016/j.solener.2015.02.004](https://doi.org/10.1016/j.solener.2015.02.004).

Fuente consultada: https://www.sciencedirect.com/science/article/abs/pii/S0038092X15000626. Resumen editorial y registro DOI. Localización: Resumen editorial. Texto completo no consultado.

**[03]** Ahmad Dawahdeh, Hussein Sharadga, Sunil Kumar. Novel MPPT Controller Augmented with Neural Network for Use with Photovoltaic Systems Experiencing Rapid Solar Radiation Changes. *Sustainability*. 2024;16(3):1021. [DOI:10.3390/su16031021](https://doi.org/10.3390/su16031021).

Fuente consultada: https://www.mdpi.com/2071-1050/16/3/1021. Texto completo, HTML editorial. Localización: §2.2–2.4 y §3.

**[04]** Ahmed Fathy Abouzeid, Hadeer Eleraky, Ahmed Kalas, Rawya Rizk, Mohamed Mohamed Elsakka, Ahmed Refaat. Experimental validation of a low-cost maximum power point tracking technique based on artificial neural network for photovoltaic systems. *Scientific Reports*. 2024;14(1):18280. [DOI:10.1038/s41598-024-67306-0](https://doi.org/10.1038/s41598-024-67306-0).

Fuente consultada: https://www.nature.com/articles/s41598-024-67306-0. Texto completo, HTML editorial. Localización: Network training and validation. Experimental validation.

**[05]** Luis Felipe Giraldo, Jorge Felipe Gaviria, María Isabella Torres, Corinne Alonso, Michael Bressan. Deep reinforcement learning using deep-Q-network for Global Maximum Power Point tracking: Design and experiments in real photovoltaic systems. *Heliyon*. 2024;10(21):e37974. [DOI:10.1016/j.heliyon.2024.e37974](https://doi.org/10.1016/j.heliyon.2024.e37974).

Fuente consultada: https://pmc.ncbi.nlm.nih.gov/articles/PMC11564077/. Texto completo, publicación en PMC. Localización: §2.2–2.4 y §3.

**[06]** Anushka Bandara, Keshawa Ratnayake, Ramitha Dissanayake, Harith Udawatte, Roshan Godaliyadda, Parakrama Ekanayake, Janaka Ekanayake. LSTM-Based MPPT Algorithm for Efficient Energy Harvesting of a Solar PV System Under Different Operating Conditions. *Electronics*. 2024;13(24):4875. [DOI:10.3390/electronics13244875](https://doi.org/10.3390/electronics13244875).

Fuente consultada: https://www.mdpi.com/2079-9292/13/24/4875. Texto completo, HTML editorial. Localización: §2.1, §3.5 y §4.5. Figuras 8–9.

**[07]** Rida Amine, Noureddine El Barbri, Mourad Yessef, Mohammed M. Alammar, Z.M.S. El‐Barbary, Hatim Ameziane. Real‐Time Incremental Learning Artificial Neural Networks Maximum Power Point Tracking With Raspberry Pi‐Based Meteorological Data Acquisition. *Energy Science & Engineering*. 2026;14(8):3741-3773. [DOI:10.1002/ese3.70555](https://doi.org/10.1002/ese3.70555).

Fuente consultada: https://scijournals.onlinelibrary.wiley.com/doi/full/10.1002/ese3.70555. Texto completo, HTML editorial. Localización: §3.2–3.5. Algoritmos 2–3.

**[08]** Mohamed Eladawy, Ryma Lebied, Mahmoud A. Elsadd. Hybrid ANN-Based MPPT Strategy for Boost Converter PV Systems Under Rapid Irradiance Variations. *Machines*. 2026;14(6):659. [DOI:10.3390/machines14060659](https://doi.org/10.3390/machines14060659).

Fuente consultada: https://www.mdpi.com/2075-1702/14/6/659. Texto completo, HTML editorial. Localización: §2.4 y §3. Figuras 8–9. Tabla 4.

**[09]** Adeleke Rahmon Ogunfowora, Indranil Bhattacharya. Solar Photovoltaic Maximum Power Point Tracking (MPPT): A Comparative Analysis of Incremental Conductance, Q-Learning, and Transformer Deep Learning for Performance Evaluation Under Standard and Dynamic Environmental Scenarios. *Energies*. 2026;19(13):3183. [DOI:10.3390/en19133183](https://doi.org/10.3390/en19133183).

Fuente consultada: https://www.mdpi.com/1996-1073/19/13/3183. Texto completo, HTML editorial. Localización: §3.2–3.3. Tabla 3B–C. §4.

**[10]** Javed Jamshed, Lorenzo Becchi, Marco Bindi, Fabio Corti, Francesco Grasso, Matteo Intravaia, Gabriele Maria Lozito, Rosa Anna Mastromauro. Hardware-in-the-Loop Assessment of Neural MPPT Control in Photovoltaic Systems with Two-Phase Boost Conversion. *Electronics*. 2026;15(18):4342. [DOI:10.3390/electronics15184342](https://doi.org/10.3390/electronics15184342).

Fuente consultada: https://www.mdpi.com/2079-9292/15/18/4342. Texto completo, HTML editorial. Localización: §2.4–2.5. Implementación y validación C-HIL.

## Procedencia de nuestra propuesta

Se inspeccionó mppt_lazo_cerrado_v6/experimental/mppt_neural.h y se contrastó el protocolo y los resultados con el manuscrito versión 4. El modelo digital procede del artículo de Suárez Suárez et al., *A Sensing-Aware Simulation-Based Digital Twin Framework for Firmware-Level Validation of Photovoltaic MPPT Controllers*, Energies 2026;19(17):4131. [DOI:10.3390/en19174131](https://doi.org/10.3390/en19174131).

Ese DOI corresponde al trabajo del modelo digital. El algoritmo inteligente actual no tiene un DOI asignado. No se utiliza el artículo anterior como prueba de validación del aprendizaje en línea.

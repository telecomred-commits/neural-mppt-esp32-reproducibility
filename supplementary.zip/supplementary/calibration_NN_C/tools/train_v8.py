"""Development retraining from measured curves and five principal frozen logs.
No analytic plant MPP, controller command, or R2 sensor perturbation is used as a training label.
"""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import numpy as np,json,re,hashlib,csv
from numpy.polynomial import Polynomial
ROOT=Path(__file__).resolve().parents[1]

def read_weights(path):
 s=path.read_text();arrays=[]
 for name in ['w0','b0','w1','b1']:
  line=next(l for l in s.splitlines() if ' '+name+'[' in l)
  arrays.append(np.array([float(v) for v in re.findall(r'[-+]?\d+\.\d+e[-+]\d+',line,re.I)]))
 return np.r_[*arrays]

def unpack(z):return z[:32].reshape(2,16),z[32:48],z[48:64],z[64]
def evaluate(z,v,g,t):
 w,b,o,c=unpack(z);x=np.c_[(np.asarray(v)-21)/21,(np.asarray(t)-37.5)/12.5]
 return np.clip(np.tanh(x@w+b)@o+c,0,1.5)*14*np.asarray(g)/1000

def main():
 manifest=[];curves=[];samples=[]
 for path in sorted((ROOT/'datos/curvas').glob('barrido*.csv')):
  a=np.loadtxt(path,delimiter=',',skiprows=1);curves.append(a)
  manifest.append(dict(file=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),role='original measured sweep',rows=len(a)))
  for row in a:samples.append([row[1],row[2],row[5],row[6],0,1/len(a)])
 for prof in ['S0','S1','S2','S3','S4']:
  path=ROOT/f'datos/desarrollo/{prof}_NN_FROZEN.csv';a=np.loadtxt(path,delimiter=',',skiprows=1)
  stable=np.r_[False,False,(abs(np.diff(a[:,4]))[1:]<2)&(abs(np.diff(a[:,4]))[:-1]<2)&(abs(np.diff(a[:,5]))[1:]<.1)&(abs(np.diff(a[:,5]))[:-1]<.1)]
  ok=stable&(a[:,4]>=399)&(a[:,4]<=801)&(a[:,5]>=24.9)&(a[:,5]<=50.1)&(a[:,1]>=0)&(a[:,1]<=45)&(a[:,2]>=0)&(a[:,2]<=15)
  q=a[ok];keys=np.c_[np.rint(q[:,1]/.2),np.rint(q[:,5]),np.rint(q[:,4]/25)];vals=[]
  for key in np.unique(keys,axis=0):
   b=q[(keys==key).all(1)];vals.append([np.median(b[:,1]),np.median(b[:,2]),np.median(b[:,4]),np.clip(np.median(b[:,5]),25,50),1])
  for row in vals:samples.append(row+[.3/len(vals)])
  manifest.append(dict(file=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),role='new principal frozen development trace',rows=len(a),accepted_raw_rows=int(ok.sum()),binned_training_points=len(vals)))
 arr=np.asarray(samples);x=np.c_[(arr[:,0]-21)/21,(arr[:,3]-37.5)/12.5];y=arr[:,1]/(arr[:,2]/1000)/14
 sw=np.sqrt(arr[:,5]);sw/=np.sqrt(np.sum(sw**2));initial=read_weights(ROOT/'datos/mppt_weights_v6.h')
 # Pool irradiance-normalized measured power at each observed temperature.
 allcurves=np.vstack(curves);labels=[]
 for temp in sorted(np.unique(allcurves[:,6])):
  a=allcurves[allcurves[:,6]==temp];v=a[:,1];p=a[:,4]/(a[:,5]/1000);u=np.unique(v)
  py=np.array([np.median(p[v==vv]) for vv in u]);center=u[py.argmax()];mask=abs(u-center)<=3
  poly=Polynomial.fit(u[mask],py[mask],3)
  roots=[float(r.real) for r in poly.deriv().roots() if abs(r.imag)<1e-8 and abs(r.real-center)<=3 and poly.deriv(2)(r.real)<0]
  if not roots:raise ValueError('No concave measured local maximum')
  labels.append(dict(T_C=float(temp),Vmp_estimated_from_measured_power_V=max(roots,key=poly),local_window_V=3,voltage_bins=int(mask.sum())))
 pv=np.array([a['Vmp_estimated_from_measured_power_V'] for a in labels]);pt=np.array([a['T_C'] for a in labels]);px=np.c_[(pv-21)/21,(pt-37.5)/12.5]
 # With fixed hidden features both current and power-slope equations are linear
 # in the 17 output parameters. Solve a regularized constrained least squares fit.
 w,b,oldout,oldbias=unpack(initial)
 h=np.tanh(x@w+b);design=np.c_[h,np.ones(len(h))]
 hp=np.tanh(px@w+b)
 constraints=np.c_[hp+(pv/21)[:,None]*(1-hp*hp)*w[0],np.ones(len(hp))]
 basis,_=np.linalg.qr(constraints.T,mode='complete')
 nullspace=basis[:,len(labels):];constraint_basis=basis[:,:len(labels)].T
 reg=.001
 matrix=np.vstack([design*sw[:,None],reg*np.eye(17)])@nullspace
 response=np.r_[y*sw,reg*np.r_[oldout,oldbias]]
 beta,_,rank,singular=np.linalg.lstsq(matrix,response,rcond=None)
 if rank!=nullspace.shape[1]:raise RuntimeError('Rank deficient constrained fit')
 out=nullspace@beta;z=initial.copy();z[48:]=out
 w,b,o,c=unpack(z)
 constraint_error=float(np.max(abs(constraints@out)))
 if constraint_error>1e-8:raise RuntimeError('Power-slope constraint not satisfied')
 # Estimate Voc search bound from measured open-circuit plateaus, as in V6.
 voc=[]
 for a in curves:
  m=a[:,2]<.1;voc.append([a[0,6],np.median(a[m,1][a[m,1]>20])])
 voc=np.asarray(voc);coef=np.linalg.lstsq(np.c_[np.ones(len(voc)),(voc[:,0]-37.5)/12.5],voc[:,1],rcond=None)[0]
 def literal(a):
  a=np.asarray(a)
  return '{'+','.join(literal(v) if a.ndim>1 else f'{float(v):.9e}f' for v in a)+'}'
 lines=['#pragma once','// V8 DEVELOPMENT: measured I fit plus measured-power stationary-point constraints; fixed hidden layer.','// Five principal FROZEN traces are development data, not final validation.','namespace mppt_weights {',f'static constexpr float w0[2][16]={literal(w)};',f'static constexpr float b0[16]={literal(b)};',f'static constexpr float w1[16][1]={literal(o.reshape(16,1))};',f'static constexpr float b1[1]={literal([c])};',f'static constexpr float voc[2]={literal(coef)};',f'static constexpr float constraint_basis[2][17]={literal(constraint_basis)};',f'static constexpr float measured_mpp_anchors[2][2]={literal(np.c_[pv,pt])};','}']
 (ROOT/'firmware/mppt_weights.h').write_text('\n'.join(lines)+'\n');np.save(ROOT/'resultados/weights_v8.npy',z)
 np.savetxt(ROOT/'resultados/training_points.csv',arr,delimiter=',',header='V,I,G,T,is_new_trace,loss_weight',comments='')
 report=dict(status='development candidate; new Wokwi runs required',architecture=[2,16,1],neural_parameters=65,hidden_parameters_fixed=48,output_parameters_refitted=17,output_parameters_learned_online=17,solver='regularized constrained linear least squares in the nullspace of measured MPP power-slope constraints',solver_rank=int(rank),solver_free_dimensions=int(nullspace.shape[1]),solver_condition_number=float(singular[0]/singular[-1]),constraint_error=constraint_error,regularization=reg,original_sweep_rows=sum(len(a) for a in curves),new_raw_accepted_rows=sum(m.get('accepted_raw_rows',0) for m in manifest),new_binned_training_points=int(np.sum(arr[:,4]==1)),measured_MPP_derivative_anchors=labels,synthetic_current_training_points=0,analytic_plant_MPP_labels_used=False,controller_command_labels_used=False,R1_R2_used_in_training=False,ONLINE_or_r01_files_used_in_training=False,source_manifest=manifest,output_displacement_from_V6=float(np.linalg.norm(out-initial[48:])),constraint_basis_orthogonality_error=float(np.max(abs(constraint_basis@constraint_basis.T-np.eye(2)))))
 (ROOT/'resultados/training_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':main()

# Modelo neuronal con aprendizaje durante la ejecución — prototipo V5

## Cambio respecto a V3/V4

El modelo deja de aprender cuatro valores Vmp(G,T). Se preentrena con las 1.012 mediciones V/I/G/T de las curvas completas. Aprende una característica de corriente I(V,G,T). En cada ciclo puede modificar sus parámetros usando la corriente recién medida, buscar el máximo de V·I_predicha y actualizar la orden de carga para acercar V a ese máximo.

Hay aprendizaje en el ESP32: se actualizan los 16 pesos y el sesgo de salida de la red en RAM. Las características ocultas permanecen fijas. No es aprendizaje por refuerzo de una política de acciones. El control es basado en modelo, con una regla proporcional de tensión y límites. No se afirma que toda modificación de parámetros mejore el MPP.

## Archivos y plataforma

Reemplazar juntos SOLO entrega/sketch.ino (220 líneas), entrega/mppt_neural.h y entrega/mppt_weights.h. No cambiar solar.chip.c, solar.chip.json, diagram.json, conexiones o barras para adaptar datos al algoritmo. Pines V34, I35, G33, T32. Adquisición corregida que ya verificamos: rangos 50 V/15 A, G_V=G_I=5/3.3, G_G=G_T=1.515, readSignal con 20 muestras, ADC12 bits, ADC_11db, periodo nominal 500 ms. Mantener Ns=Np=1.

Se mantienen las ramas convencionales P&O, INC y P&O adaptativo. El modo predeterminado es MPPT_ADAPTIVE_MODEL. MPPT_ONLINE_LEARNING=1 permite adaptar la capa de salida; 0 la mantiene congelada para comparación. Una división por tensión cero en la rama INC convencional tiene protección.

Los pesos iniciales son nuevos, de arquitectura 2–16–1 con tanh, 65 parámetros. No son compatibles con cabeceras anteriores. Las dos entradas internas son V y T normalizadas. G interviene mediante la normalización I/(G/1000), que aprovecha la dependencia lineal de irradiancia del chip original. Esto es una hipótesis del modelo, no una relación de irradiancia descubierta de forma independiente por la red.

## Uso de la información recibida

- Cuatro barridos calibrados: entrenamiento de I(V,G,T), 1.012 muestras en cuatro condiciones ambientales, no 1.012 condiciones independientes.
- Quinto barrido 600 W/m² / 37 °C: evaluación del modelo congelado y evaluación secuencial del aprendizaje. No se usó para entrenar los pesos iniciales.
- 27 registros previos, 25.437 muestras: referencia histórica de controladores y escenarios de medición. Se conserva su inventario, rangos y hashes en validacion/registros_previos.json. No se descartan; no se mezclan como si compartieran una escala confirmada con los barridos actuales. No se utilizan sus órdenes Load como etiquetas de máximo ni sus máximos temporales P como máximos de curva.
- Código original del panel: define el sentido de la acción y las ecuaciones del banco de prueba. No se modifica.

No hay puntos sintéticos en el entrenamiento. Los puntos de búsqueda numérica de Vmp y las plantas del banco de pruebas son cálculos de evaluación, no mediciones ni entrenamiento adicional.

## Aprendizaje y decisión

La red predice corriente, inicialmente entrenada fuera del ESP32. En operación se calcula el error entre corriente medida y predicha ANTES de actualizar. Si su magnitud supera 0.04 A, se aplica una actualización NLMS normalizada a la capa de salida con tasa 0.10. El residual normalizado se limita a ±0.10 y cada parámetro adaptable a ±0.25 de su valor inicial. Estos valores son decisiones de ingeniería, no hiperparámetros validados en una campaña experimental. La zona de 0.04 A reduce actualizaciones debidas a diferencias pequeñas; puede ocultar errores menores.

La carga no se usa como etiqueta del aprendizaje. Las salidas de la red se limitan a corriente no negativa y a una cota normalizada de 1.5. Se busca el máximo predicho de V·I(V,G,T) con un recorrido grueso de 101 puntos y un refinamiento local de 21 puntos. El límite superior de tensión se obtiene de una recta Voc(T) ajustada a las mesetas medidas de circuito abierto. No se estima la carga aplicada a partir de Voc.

La orden se actualiza con ΔLoad=clip(0.5·(V−Vmp_modelo),−3,+3), en puntos porcentuales, con banda de ±0.15 V. Si V es baja respecto al objetivo, se reduce la orden de carga. El estado empieza en 50 % y se limita a 0–100 %. La regla proporcional no aprende; aprende la característica utilizada para encontrar el objetivo. Es una decisión calculada y su aplicación no está confirmada por los cuatro pines de medición.

Dominio evaluado de referencias: G=400–800 W/m², T=25–50 °C, Ns=Np=1. Pequeñas tolerancias de borde son para cuantización: 1 W/m² y 0.1 °C. No se presenta como un modelo validado de todo el rango del panel. Fuera de este dominio no aprende ni extrapola una referencia aceptada, usa INC convencional. Entradas inválidas mantienen una orden finita. El aprendizaje se pierde al reiniciar, no se escribe en flash.

## Serial: evidencia de funcionamiento

| Columna | Qué representa |
|---|---|
| V_V, I_A, P_W, G_Wm2, T_C | Mediciones |
| R_ohm | V/I; −1 si I es prácticamente cero |
| Load_cmd_pct, DeltaLoad_cmd_pct | Orden calculada y su incremento después de saturación |
| control_source | 1 modelo neuronal; 3 respaldo INC; 4 entrada inválida; 0 inicialización sin referencia. 10/11/12 son ramas convencionales seleccionadas directamente |
| ref_valid, Vmp_model_V | Validez dentro del dominio y máximo de la potencia predicha; no significa MPP real confirmado |
| error_V | V medida menos Vmp_model_V |
| I_pred_before_A | Predicción ANTES de aprender de esa muestra |
| model_error_A | I medida menos esa predicción |
| learning_updates | Número acumulado de actualizaciones de parámetros |
| learned_this_cycle | 1 si se ejecutó una actualización en ese ciclo |
| parameter_change | Norma de la diferencia de parámetros de salida respecto al arranque |
| control_us | Tiempo de cálculo medido en el dispositivo mediante micros() |
| at_limit | Orden de carga en 0 o 100 % |

Un contador creciente y parameter_change>0 son evidencia de que el firmware modificó el modelo, NO de que mejoró la extracción de potencia. Un contador detenido con error menor de 0.04 A es consistente con la zona muerta y no prueba que el código esté inactivo.

El mensaje load= vuelve a imprimirse. No se añaden UART/ACK/PWM, puertos o conexiones. El mensaje no es una confirmación de aplicación. Si el panel permanece en una carga fija mientras el estado interno cambia, el estado puede saturarse. No presentar esa ejecución como seguimiento automático demostrado.

## Resultados disponibles

Ajuste inicial de corriente en las 1.012 muestras: MAE 0.03094 A, RMSE 0.04245 A. Es error de entrenamiento.

En el quinto barrido reservado (265 muestras), antes de adaptar: MAE de corriente 0.21760 A y RMSE 0.22850 A. Al reproducir ese barrido en orden temporal, prediciendo cada muestra ANTES de aprender de ella, el MAE fue 0.03885 A y hubo 56 actualizaciones. Esto evalúa predicción secuencial local en un barrido; el modelo se adapta a muestras anteriores del propio barrido. No implica generalización global de la curva adaptada ni mejora del MPP.

Prueba aislada simulada con corriente aumentada 8 % en un punto fijo: error 0.7363 A antes y 0.03853 A después, con 28 actualizaciones. Es evidencia de adaptación de parámetros en un banco de pruebas, no una medición del usuario ni aprendizaje probado ante toda perturbación.

En seis ejecuciones dinámicas deterministas (aprendizaje activado/desactivado, tres cargas iniciales, cambios de G/T y una perturbación de carga), el cálculo de potencia extraída NO mejoró con aprendizaje activado. La adaptación cambió parámetros, pero los recorridos de orden y potencia nominales resultaron iguales dentro de la banda de control. No hay evidencia de superioridad energética ni comparación equivalente con los tres MPPT históricos. Los resultados detallados y sus condiciones están en bench.json.

El banco aplica cada orden directamente a las ecuaciones originales del chip. Ese enlace existe SOLO en el banco, no se añade al proyecto del usuario. No es una prueba en Wokwi ni en hardware. Las simulaciones son sin ruido ni retardo añadido. No constituyen eficiencia MPPT experimental.

## Comprobación inicial

No hacer más barridos por ahora. Una vez instalados los tres archivos, conservar la configuración con la que se verificó la adquisición. Observar I_pred_before_A, model_error_A, learning_updates y parameter_change. Las columnas permiten distinguir medición, aprendizaje, objetivo y orden. Para comparar aprendizajes se debe reiniciar entre ejecuciones y usar el mismo perfil, con MPPT_ONLINE_LEARNING=0 y 1 respectivamente. No esperar que el contador crezca por obligación si el error está dentro de la banda.

Se compilaron y ejecutaron cinco configuraciones del sketch con una interfaz Arduino simulada, y se probaron límites, entradas no finitas y divisiones por cero. El valor control_us del mock es artificial, no una medición de rendimiento. Pendientes: compilación SDK ESP32, ejecución de este prototipo en Wokwi, tiempo de cálculo real y validación de la aplicación de órdenes. Los hashes verifican las fuentes originales recibidas, no una sesión remota.

Herramientas: train.py (numpy/scikit-learn; solo datos/barrido*.csv), bench.py (numpy/g++, incluye evaluación reservada), build_sketch.py (usa la base incluida en tools y lee hashes del ZIP original en ../upload), verify_sketch.py (g++/mock; necesita ZIP original). No se reentrena con datos/evaluacion_600_37.md.

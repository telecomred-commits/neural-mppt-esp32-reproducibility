#pragma once
#include <cmath>
#include <cstdint>
#include "mppt_weights.h"
namespace mppt {
inline float clamp(float x,float lo,float hi){return x<lo?lo:(x>hi?hi:x);}
struct Decision {
 float load,delta,reference,error,predicted_current,model_error,parameter_change;
 uint32_t learning_updates;
 int source;
 bool reference_valid,at_limit,learned;
};
class Controller {
 public:
 explicit Controller(bool learning=true):learning_(learning){reset();}
 void reset(){
  for(int j=0;j<16;++j)out_[j]=mppt_weights::w1[j][0];
  bias_=mppt_weights::b1[0];updates_=0;initialized_=false;
 }
 float predict(float v,float g,float t)const {
  float h[16];features(v,t,h);return clamp(normalized(h),0,1.5f)*14.0f*g/1000.0f;
 }
 float target(float g,float t)const {
  const float top=clamp(mppt_weights::voc[0]+mppt_weights::voc[1]*(t-37.5f)/12.5f,1,45);
  float best_v=0,best_p=-1;
  for(int n=0;n<=100;++n){float v=top*n/100.0f,p=v*predict(v,g,t);if(p>best_p){best_p=p;best_v=v;}}
  const float lo=clamp(best_v-top/100,0,top),hi=clamp(best_v+top/100,0,top);
  for(int n=0;n<=20;++n){float v=lo+(hi-lo)*n/20.0f,p=v*predict(v,g,t);if(p>best_p){best_p=p;best_v=v;}}
  return best_v;
 }
 Decision update(float v,float i,float g,float t,float load){
  Decision d={std::isfinite(load)?clamp(load,0,100):50.0f,0,0,0,0,0,0,updates_,4,false,false,false};
  d.parameter_change=distance();
  if(!std::isfinite(v)||!std::isfinite(i)||!std::isfinite(g)||!std::isfinite(t)||!std::isfinite(load)||v<0||i<0)return d;
  const bool covered=g>=399&&g<=801&&t>=24.9f&&t<=50.1f;
  float step=0;
  if(covered){
   const float gc=clamp(g,400,800),tc=clamp(t,25,50);
   d.predicted_current=predict(v,gc,tc);d.model_error=i-d.predicted_current;
   // Last layer NLMS: measured current is the learning target, NOT a load command.
   // A small noise dead zone avoids claiming a model update on every noisy sample.
   if(learning_&&v<=45&&std::fabs(d.model_error)>0.04f){
    float h[16];features(v,tc,h);float norm=1;
    for(int j=0;j<16;++j)norm+=h[j]*h[j];
    float e=clamp((i/(gc/1000.0f)/14.0f)-normalized(h),-0.10f,0.10f);
    const float gain=0.10f*e/norm;
    for(int j=0;j<16;++j)out_[j]=clamp(out_[j]+gain*h[j],mppt_weights::w1[j][0]-.25f,mppt_weights::w1[j][0]+.25f);
    bias_=clamp(bias_+gain,mppt_weights::b1[0]-.25f,mppt_weights::b1[0]+.25f);
    ++updates_;d.learned=true;
   }
   d.parameter_change=distance();d.learning_updates=updates_;
   d.reference=target(gc,tc);d.reference_valid=true;d.source=1;d.error=v-d.reference;
   step=std::fabs(d.error)<=.15f?0.0f:clamp(.5f*d.error,-3,3);
  }else{
   d.source=initialized_?3:0;
   if(initialized_){float dv=v-prev_v_,di=i-prev_i_;
    if(std::fabs(dv)<.05f){if(std::fabs(di)>=.02f)step=di>0?-1.0f:1.0f;}
    else if(v>1e-6f){float c=di/dv+i/v;if(std::fabs(c)>=.01f)step=c>0?-1.0f:1.0f;}
   }
  }
  float before=d.load;d.load=clamp(before+step,0,100);d.delta=d.load-before;
  d.at_limit=d.load<=0||d.load>=100;prev_v_=v;prev_i_=i;initialized_=true;return d;
 }
 private:
 void features(float v,float t,float*h)const{
  const float x[2]={(v-21)/21,(t-37.5f)/12.5f};
  for(int j=0;j<16;++j){float s=mppt_weights::b0[j];for(int k=0;k<2;++k)s+=x[k]*mppt_weights::w0[k][j];h[j]=std::tanh(s);}
 }
 float normalized(const float*h)const{float y=bias_;for(int j=0;j<16;++j)y+=out_[j]*h[j];return y;}
 float distance()const{float s=(bias_-mppt_weights::b1[0])*(bias_-mppt_weights::b1[0]);for(int j=0;j<16;++j){float d=out_[j]-mppt_weights::w1[j][0];s+=d*d;}return std::sqrt(s);}
 float out_[16],bias_,prev_v_=0,prev_i_=0;
 uint32_t updates_=0;
 bool learning_,initialized_=false;
};
}

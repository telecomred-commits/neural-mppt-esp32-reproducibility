from pathlib import Path
import json,zipfile,hashlib
R=Path(__file__).resolve().parents[1]
s=(R/'tools/sketch_control_base.ino').read_text()
s=s.replace('#define MPPT_HYBRID 3','#define MPPT_ADAPTIVE_MODEL 3').replace('MPPT_MODE MPPT_HYBRID','MPPT_MODE MPPT_ADAPTIVE_MODEL').replace('MPPT_MODE == MPPT_HYBRID','MPPT_MODE == MPPT_ADAPTIVE_MODEL').replace('MPPT_MODE != MPPT_HYBRID','MPPT_MODE != MPPT_ADAPTIVE_MODEL')
s=s.replace('// 0=affine, 1=neural with affine agreement guard, 2=neural unguarded.\n#define MPPT_REFERENCE_POLICY 1','// 1 updates output-layer parameters from measured current; 0 freezes them.\n#define MPPT_ONLINE_LEARNING 1')
s=s.replace('mppt::Controller intelligent_controller(MPPT_REFERENCE_POLICY);','mppt::Controller intelligent_controller(MPPT_ONLINE_LEARNING != 0);')
s=s.replace('mppt::Decision decision = {50,0,0,0,0,0,0,false,false};','mppt::Decision decision = {50,0,0,0,0,0,0,0,0,false,false,false};\nunsigned long control_us = 0;')
s=s.replace('  const float load_before = load_mppt;','  const float load_before = load_mppt;\n  const unsigned long control_start = micros();')
s=s.replace('  /* ---------- Orden calculada por serial; no confirma aplicación ---------- */','  control_us = micros()-control_start;\n  /* ---------- Orden calculada por serial; no confirma aplicación ---------- */')
lines=s.splitlines()
for n,l in enumerate(lines):
 if 't_ms\\tV_V' in l:
  lines[n]='  Serial.println("t_ms\\tV_V\\tI_A\\tR_ohm\\tP_W\\tG_Wm2\\tT_C\\tLoad_cmd_pct\\tDeltaLoad_cmd_pct\\tcontrol_source\\tref_valid\\tVmp_model_V\\terror_V\\tI_pred_before_A\\tmodel_error_A\\tlearning_updates\\tlearned_this_cycle\\tparameter_change\\tcontrol_us\\tat_limit");'
s='\n'.join(lines)+'\n'
s=s.replace('  Serial.print("\\t"); Serial.print(decision.neural_reference, 3);\n  Serial.print("\\t"); Serial.print(decision.affine_reference, 3);\n','')
s=s.replace('  Serial.print("\\t"); Serial.print(decision.error, 3);','''  Serial.print("\\t"); Serial.print(decision.error, 3);
  Serial.print("\\t"); Serial.print(decision.predicted_current, 3);
  Serial.print("\\t"); Serial.print(decision.model_error, 3);
  Serial.print("\\t"); Serial.print(decision.learning_updates);
  Serial.print("\\t"); Serial.print(decision.learned ? 1 : 0);
  Serial.print("\\t"); Serial.print(decision.parameter_change, 6);
  Serial.print("\\t"); Serial.print(control_us);''')
assert 'neural_reference' not in s and 'MPPT_REFERENCE_POLICY' not in s
(R/'entrega/sketch.ino').write_text(s)
with zipfile.ZipFile(R.parent/'upload/panelsolarMPPT (P&O _ INC _ Adaptive P&O)(1).zip') as z:
 (R/'validacion/originales_sha256.json').write_text(json.dumps({n:hashlib.sha256(z.read(n)).hexdigest() for n in ['solar.chip.c','solar.chip.json','diagram.json']},indent=2))
print('lines',len(s.splitlines()))

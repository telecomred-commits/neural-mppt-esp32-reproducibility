from pathlib import Path
import ctypes as ct,subprocess,tempfile,json,numpy as np
R=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'api.cpp').write_text('''#include "mppt_neural.h"
extern "C"{void* create(int learn){return new mppt::Controller(learn);}
void destroy(void*p){delete static_cast<mppt::Controller*>(p);}
float predict(void*p,float v,float g,float t){return static_cast<mppt::Controller*>(p)->predict(v,g,t);}
float target(void*p,float g,float t){return static_cast<mppt::Controller*>(p)->target(g,t);}
void update(void*p,float v,float i,float g,float t,float load,float*out){auto a=static_cast<mppt::Controller*>(p)->update(v,i,g,t,load);float b[]={a.load,a.delta,a.reference,a.error,a.predicted_current,a.model_error,a.parameter_change,float(a.learning_updates),float(a.source),float(a.reference_valid),float(a.at_limit),float(a.learned)};for(int k=0;k<12;++k)out[k]=b[k];}}
''');so=p/'a.so';subprocess.run(['g++','-O2','-std=c++11','-Wall','-Wextra','-Werror','-shared','-fPIC','-I',str(R/'entrega'),str(p/'api.cpp'),'-o',str(so)],check=True)
 lib=ct.CDLL(str(so));lib.create.argtypes=[ct.c_int];lib.create.restype=ct.c_void_p;lib.destroy.argtypes=[ct.c_void_p];lib.predict.argtypes=[ct.c_void_p]+[ct.c_float]*3;lib.predict.restype=ct.c_float;lib.target.argtypes=[ct.c_void_p]+[ct.c_float]*2;lib.target.restype=ct.c_float;lib.update.argtypes=[ct.c_void_p]+[ct.c_float]*5+[ct.POINTER(ct.c_float)];o=(ct.c_float*12)()
 def step(c,v,i,g,t,load):
  lib.update(c,v,i,g,t,load,o);a=np.array(o[:]);assert np.isfinite(a).all() and 0<=a[0]<=100 and abs(a[1])<=3.0001;return a
 def plant(load,g,t,gain=1):
  voc=min(41.3,41.3*(1-.003*(t-25)));isc=13.8*g/1000*(1+.0004*(t-25));k=min(8,8*(1-.002*(t-25)));v=voc*(1-load/100);i=gain*isc*(1-(v/voc)**k);r=(1/(k+1))**(1/k);return v,i,voc*r,gain*voc*r*isc*k/(k+1)
 # Isolated online update evidence: same physical operating point with injected gain mismatch.
 online=lib.create(1);frozen=lib.create(0);v,i,vm,pm=plant(24,600,37,1.08);before=abs(i-lib.predict(online,v,600,37));a=None
 for n in range(100):a=step(online,v,i,600,37,24)
 after=abs(i-lib.predict(online,v,600,37));assert after<before and a[7]>0 and a[6]>0
 isolated={'gain_shift':1.08,'before_error_A':before,'after_error_A':after,'updates':a[7],'parameter_change_norm':a[6]};lib.destroy(online);lib.destroy(frozen)
 # Dynamic host benchmark applies each command to equations, not Wokwi.
 cases=[]
 for learning in [0,1]:
  for initial in [10,50,90]:
   c=lib.create(learning);load=float(initial);ratio=[];segment=[]
   for n in range(400):
    g=800 if n<100 else 400 if n<200 else 600
    t=25 if n<200 else 50 if n<300 else 37
    if n==50:load=70 # external load disturbance
    v,i,vm,pm=plant(load,g,t);a=step(c,v,i,g,t,load);load=float(a[0]);ratio.append(v*i/pm)
    if n in [99,199,299,399]:segment.append({'n':n,'V':v,'true_Vmp':vm,'model_Vmp':float(a[2]),'power_fraction':v*i/pm,'updates':float(a[7])})
   cases.append({'online':bool(learning),'initial_load':initial,'mean_power_fraction':float(np.mean(ratio)),'segments':segment,'final_parameter_change':float(a[6])});lib.destroy(c)
 # Held-out curve: evaluate frozen before any adaptation. No fitting / tuning on this curve.
 rows=[]
 for line in (R/'datos/evaluacion_600_37.md').read_text().splitlines():
  f=line.split()
  if len(f)==15:
   try:rows.append(list(map(float,f)))
   except ValueError:pass
 x=np.array(rows);c=lib.create(0);pred=np.array([lib.predict(c,r[1],r[5],r[6]) for r in x]);held={'rows':len(x),'current_MAE_A':float(np.mean(abs(pred-x[:,2]))),'current_RMSE_A':float(np.sqrt(np.mean((pred-x[:,2])**2))),'frozen_Vmp':lib.target(c,600,37)};lib.destroy(c)
 # Prequential measured evaluation: predict first, then learn each sample once.
 online=lib.create(1);errors=[];last=None
 for row in x:
  errors.append(abs(lib.predict(online,row[1],row[5],row[6])-row[2]))
  last=step(online,row[1],row[2],row[5],row[6],50)
 held['online_prequential_MAE_A']=float(np.mean(errors));held['online_prequential_last50_MAE_A']=float(np.mean(errors[-50:]));held['online_updates']=float(last[7]);lib.destroy(online)
 # Nonfinite / out of range / zero current / saturation behavior.
 c=lib.create(1)
 for args in [(0,0,800,25,1),(0,0,800,25,0),(20,5,400,24,50),(float('nan'),5,800,25,50),(20,float('inf'),800,25,50)]:step(c,*args)
 lib.destroy(c)
report={'isolated_online_learning':isolated,'host_dynamic_cases':cases,'heldout_before_learning':held,'warning':'Host feedback is simulated by equations and assumes commands applied. Not Wokwi or hardware measurements. Four training contexts only.'}
(R/'validacion/bench.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

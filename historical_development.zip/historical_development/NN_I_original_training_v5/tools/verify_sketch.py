from pathlib import Path
import tempfile,subprocess,json,zipfile,hashlib
R=Path(__file__).resolve().parents[1]
s=(R/'entrega/sketch.ino').read_text()
with tempfile.TemporaryDirectory() as d:
 p=Path(d)
 (p/'Arduino.h').write_text('''#pragma once
#include <cstdint>
#include <cmath>
#include <iostream>
constexpr int ADC_11db=0;
extern float adc_values[40];
struct SerialMock{void begin(int){} template<class T>void print(T v){std::cout<<v;} void print(float v,int){std::cout<<v;} template<class T>void println(T v){std::cout<<v<<"\\n";} void println(float v,int){std::cout<<v<<"\\n";}};
static SerialMock Serial;
inline void analogReadResolution(int){} inline void analogSetAttenuation(int){}
inline uint32_t analogRead(int p){return static_cast<uint32_t>(adc_values[p]);}
inline unsigned long millis(){static unsigned long t=0;return t+=508;}
inline unsigned long micros(){static unsigned long t=0;return t+=100;}
inline void delay(int){}
''')
 (p/'harness.cpp').write_text('''#include "Arduino.h"
float adc_values[40]={0};
#include "sketch.ino"
int main(){setup();adc_values[34]=20.65f/50*.66f*4095;adc_values[35]=11.0f/15*.66f*4095;adc_values[33]=800.0f/1000*.66f*4095;adc_values[32]=25.0f/100*.66f*4095;for(int j=0;j<40;++j)loop();adc_values[34]=0;adc_values[35]=0;loop();adc_values[33]=100;loop();}
''')
 for mode in ['MPPT_ADAPTIVE_MODEL','MPPT_PO','MPPT_INC','MPPT_ADAPT_PO']:
  for learning in ([0,1] if mode=='MPPT_ADAPTIVE_MODEL' else [1]):
   current=s.replace('#define MPPT_MODE MPPT_ADAPTIVE_MODEL','#define MPPT_MODE '+mode).replace('#define MPPT_ONLINE_LEARNING 1','#define MPPT_ONLINE_LEARNING '+str(learning))
   (p/'sketch.ino').write_text(current);exe=p/'sketch'
   subprocess.run(['g++','-std=c++11','-Wall','-Wextra','-Werror','-I',str(p),'-I',str(R/'entrega'),str(p/'harness.cpp'),'-o',str(exe)],check=True)
   out=subprocess.run([str(exe)],capture_output=True,text=True,check=True).stdout
   assert 'nan' not in out.lower() and 'inf' not in out.lower() and 'load=' in out
   (R/'validacion'/f'host_{mode}_learn{learning}.txt').write_text(out)
with zipfile.ZipFile(R.parent/'upload/panelsolarMPPT (P&O _ INC _ Adaptive P&O)(1).zip') as z:
 for n,h in json.loads((R/'validacion/originales_sha256.json').read_text()).items():assert hashlib.sha256(z.read(n)).hexdigest()==h
 original=z.read('sketch.ino').decode();a=original.index('float readSignal');b=original.index('/* ======================================================',a);assert original[a:b] in s
assert 'Serial2' not in s
(R/'validacion/compilacion.json').write_text(json.dumps({'host_sketch_builds':5,'Arduino_API':'mock','readSignal_unchanged':True,'protected_source_hashes_verified':True,'control_us_in_host_mock':'fixed 100 us placeholder; not performance measurement','ESP32_SDK_compilation':'not run','Wokwi_execution':'pending'},indent=2))
print('Five sketch configurations compile and execute with host Arduino mock. No SDK or Wokwi verification claimed.')

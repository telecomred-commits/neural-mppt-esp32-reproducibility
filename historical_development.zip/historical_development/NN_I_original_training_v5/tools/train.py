from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import numpy as np,json
from sklearn.neural_network import MLPRegressor
R=Path(__file__).resolve().parents[1];D=R/'datos'
arrays=[np.loadtxt(f,delimiter=',',skiprows=1) for f in sorted(D.glob('barrido*.csv'))]
a=np.vstack(arrays);x=np.c_[(a[:,1]-21)/21,(a[:,6]-37.5)/12.5];y=a[:,2]/(a[:,5]/1000)/14
m=MLPRegressor(hidden_layer_sizes=(16,),activation='tanh',solver='lbfgs',alpha=1e-4,random_state=20261026,max_iter=5000,tol=1e-10,max_fun=150000).fit(x,y)
pred=m.predict(x)*14*a[:,5]/1000
voc=[]
for arr in arrays:
 mask=arr[:,2]<.1;voc.append([arr[0,6],np.median(arr[mask,1][arr[mask,1]>20])])
# Measured open-circuit plateaus, a linear fit across the two observed temperatures.
voc=np.asarray(voc);coef=np.linalg.lstsq(np.c_[np.ones(4),(voc[:,0]-37.5)/12.5],voc[:,1],rcond=None)[0]
def c(a):
 a=np.asarray(a)
 return '{'+','.join(c(v) if a.ndim>1 else f'{float(v):.9e}f' for v in a)+'}'
s=['#pragma once','// Pretrained from 1,012 measured curve points, not four MPP labels.','namespace mppt_weights {']
for k,(w,b) in enumerate(zip(m.coefs_,m.intercepts_)):
 s += [f'static constexpr float w{k}[{w.shape[0]}][{w.shape[1]}]={c(w)};',f'static constexpr float b{k}[{len(b)}]={c(b)};']
s+=['static constexpr float voc[2]='+c(coef)+';','}']
(R/'entrega/mppt_weights.h').write_text('\n'.join(s)+'\n')
report={'objective':'I(V,G,T), normalized as I/(G/1000)/14; G scaling follows the supplied chip family. Online last-layer adaptation uses measured I.','source':'four calibrated measured sweeps only','measured_training_rows':len(a),'independent_conditions':4,'architecture':[2,16,1],'training_current_MAE_A':float(np.mean(abs(pred-a[:,2]))),'training_current_RMSE_A':float(np.sqrt(np.mean((pred-a[:,2])**2))),'weights_count':65,'voc_coefficients':coef.tolist(),'synthetic_training_rows':0,'old_27_records_pooled':False,'heldout_600_37_used_for_training':False}
# Report power-max prediction using a dense evaluation grid, not synthetic training data.
report['training_curve_targets']=[]
for arr in arrays:
 g,t=arr[0,[5,6]];v=np.linspace(0,coef@[1,(t-37.5)/12.5],1000)
 yy=np.maximum(0,m.predict(np.c_[(v-21)/21,np.full(len(v),(t-37.5)/12.5)]))*14*g/1000
 k=(v*yy).argmax();report['training_curve_targets'].append({'G':g,'T':t,'Vmp_pred':v[k],'Pmp_pred':v[k]*yy[k]})
(R/'validacion/entrenamiento.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

#include <Arduino.h>
#include "mppt_neural.h"

// Solo cambia este sketch. Conserva el chip y ambos JSON originales.
// Requiere las cabeceras de IA ya entregadas, sin modificarlas.
constexpr int PIN_V = 34;
constexpr int PIN_I = 35;
constexpr int PIN_G = 33;
constexpr int PIN_T = 32;

// Deben coincidir con los valores ACTUALES de los deslizadores del panel.
// 600 V y 30 A coinciden con los valores de attr_init del chip C original.
constexpr float V_SENSE_MAX = 600.0f;
constexpr float I_SENSE_MAX = 30.0f;
constexpr float PANELS_SERIES = 1.0f;
constexpr float STRINGS_PARALLEL = 1.0f;

// Cuentas ADC virtuales de Wokwi: referencia 5 V.
// El chip original escala sus salidas a 3.3 V.
constexpr float ADC_REFERENCE = 5.0f;
constexpr float CHIP_OUTPUT_SCALE = 3.3f;
constexpr float VOC_REF = 41.3f;
constexpr float ALPHA_V = -0.003f;

pvmppt::Controller neural;

float readSignal(int pin, float physical_max) {
  uint32_t sum = 0;
  for (unsigned n = 0; n < 20; ++n) sum += analogRead(pin);
  const float raw = sum / 20.0f;
  return (raw / 4095.0f) * (ADC_REFERENCE / CHIP_OUTPUT_SCALE) * physical_max;
}

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);
  Serial.println("# Inferencia neuronal con los cuatro pines originales. Sin UART adicional.");
  Serial.println("# La carga aplicada se ESTIMA con V y T mediante el modelo original.");
  Serial.println("# target_pct y suggested_pct son recomendaciones; no modifican el deslizador.");
  Serial.printf("# Rangos: V=%.1f V, I=%.1f A, Ns=%.0f, Np=%.0f. Deben coincidir con el panel.\n", V_SENSE_MAX, I_SENSE_MAX, PANELS_SERIES, STRINGS_PARALLEL);
  Serial.println("t_ms,V_V,I_A,P_W,G_Wm2,T_C,estimated_load_pct,target_pct,suggested_pct,valid,inference_us");
}

void loop() {
  const unsigned long time_ms = millis();
  const float v = readSignal(PIN_V, V_SENSE_MAX);
  const float i = readSignal(PIN_I, I_SENSE_MAX);
  const float g = readSignal(PIN_G, 1000.0f);
  const float t = readSignal(PIN_T, 100.0f);
  const float v_single = v / PANELS_SERIES;
  const float i_single = i / STRINGS_PARALLEL;

  // El montaje original no comunica el valor del deslizador al ESP32.
  // Se estima u a partir de V=Voc(T)*(1-u), con los recortes del chip original.
  // Esta estimacion es especifica de este panel digital, no de un panel fisico.
  const float voc = pvmppt::bound(VOC_REF * (1.0f + ALPHA_V * (t - 25.0f)),
                                 0.0f, VOC_REF);
  const float estimated_load = voc > 0.01f ? 1.0f - v_single / voc : -1.0f;
  const unsigned long start_us = micros();
  const auto decision = neural.update(v_single, i_single, estimated_load);
  const unsigned long inference_us = micros() - start_us;

  if (!decision.valid) neural.reset();
  Serial.printf("%lu,%.4f,%.4f,%.4f,%.1f,%.2f,%.4f,%.4f,%.4f,%d,%lu\n",
      time_ms, v, i, v*i, g, t, estimated_load*100.0f,
      decision.valid ? decision.target_load*100.0f : NAN,
      decision.valid ? decision.next_load*100.0f : NAN,
      decision.valid ? 1 : 0, inference_us);
  delay(500);
}

# Copia experimental con control de carga aplicado y confirmado

Esta copia incorpora el enlace de actuación que faltaba. El ESP32 envía una orden a una entrada nueva del chip. El chip la aplica en el modelo, actualiza V/I y devuelve una confirmación con la carga aplicada. El siguiente cálculo de control utiliza mediciones posteriores a esa confirmación.

## Carpetas

- `original/`: copia exacta de los archivos del ZIP recibido. No se modificaron sus bytes. Sirve para conservar el proyecto publicado y comparar cambios, no para mezclar sus archivos con la copia experimental.
- `experimental/`: los SEIS archivos que se instalan juntos en una copia nueva del proyecto Wokwi.
- `tests/`, `tools/`, `validacion/`: comprobaciones reproducibles, trazas, diferencias de archivos y figura del banco de integración. NO se copian a Wokwi.

## Instalación

Duplicar el proyecto Wokwi original o abrir un proyecto experimental separado. En esa copia sustituir juntos:

1. sketch.ino
2. mppt_neural.h
3. mppt_weights.h
4. solar.chip.c
5. solar.chip.json
6. diagram.json

No instalar únicamente el .ino: esta entrega incluye un enlace nuevo entre circuito, firmware y chip. No instalar las cabeceras V3/V4 junto al controlador de aprendizaje.

`wokwi-api.h` pertenece al código del chip (`solar.chip.c`), no al programa Arduino. El .ino incluye Arduino.h y mppt_neural.h. No se suministra ni se debe subir a Wokwi la cabecera de prueba ubicada en tests/stubs/.

## Conexiones

Las cuatro conexiones de medición y las masas originales se conservan. Se añaden:

| ESP32 | Chip experimental | Función |
|---|---|---|
| GPIO17, TX de Serial2 | CTRL_RX | Orden de carga |
| GPIO16, RX de Serial2 | CTRL_TX | Confirmación de carga aplicada |

El monitor serial sigue en Serial a 115200. El enlace de control usa Serial2 a 115200. El JSON ya incluye estas conexiones. No hay que cablearlas manualmente si se carga completo.

## Qué permanece del panel original

Las constantes fotovoltaicas, ecuaciones de Voc, Isc, k, dependencia con G/T, Ns/Np y cálculo I(V), ruido, offsets, ganancias, rizado y salidas analógicas se conservan. El bloque desde la lectura G/T hasta las cuatro salidas DAC se compara literalmente con el original en las comprobaciones. Lo que cambia es la fuente del valor u de carga y la confirmación posterior.

El modo manual reproduce la selección de carga mediante la barra. El modo automático usa la orden del ESP32 y permite introducir una perturbación con esa misma barra. El proyecto original permanece aparte e intacto.

## Controles de la copia

`Control: 0 manual / 1 ESP32` selecciona el modo. La copia arranca con 1.

La barra de carga tiene dos interpretaciones explícitas:

- Modo 0: carga aplicada = valor de la barra, como en el original.
- Modo 1: carga aplicada = clamp(orden ESP32 + barra − 50, 0, 100).

Por tanto, en automático **50 es la posición neutra de la barra**. La barra no tiene que moverse visualmente para que el ESP32 cambie la carga aplicada. La carga aplicada se consulta en `applied_pct` del serial, confirmada por el chip.

Ejemplo: orden=24 %, barra=50 → aplicada=24 %. Si se mueve la barra a 60, la aplicada pasa momentáneamente a 34 %. El controlador puede reducir su orden hacia 14 % para recuperar una aplicada próxima a 24 %.

Las órdenes y la carga física están limitadas a 0–100 %. Una perturbación extrema puede superar la autoridad disponible del actuador: con barra=100, por ejemplo, la aplicada no puede bajar de 50 aunque la orden llegue a 0. Ese caso se informa mediante `at_limit`; no se promete compensación de perturbaciones físicamente inalcanzables. Para la primera prueba utilizar barra=50 y, después, una perturbación moderada a 60.

## Configuración inicial de la copia

El diagram.json experimental fija: G=800 W/m², T=25 °C, Ns=Np=1, rangos 50 V/15 A, barra Load=50 y modo automático=1. Los controles de instrumentación originales conservan sus valores predeterminados.

La adquisición del ESP32 es la corregida ya comprobada: pines 34/35/33/32, 20 muestras, ADC12 bits y ADC_11db; rangos 50 V/15 A y compensación G_V=G_I=5/3.3 para Wokwi. G_G y G_T siguen en 1.515. No se presenta esta compensación como calibración de una placa física.

## Algoritmo de aprendizaje

Se conserva el modelo de V5, sin reentrenar con las nuevas pruebas: red 2–16–1, 65 parámetros iniciales, característica I(V,G,T), adaptación de pesos y sesgo de salida mediante NLMS a partir de corriente medida. G se incorpora mediante la normalización de corriente que corresponde a la familia del chip. La búsqueda del máximo predicho y la regla proporcional de control se mantienen.

Las cuatro curvas medidas calibradas (1.012 muestras) se usaron para preentrenar. El quinto barrido 600/37 quedó como evaluación. Los 27 registros antiguos son referencias históricas y no se mezclaron como datos de una adquisición confirmada. Las comprobaciones de V5 sobre predicción y adaptación no equivalen a superioridad energética. No se añade entrenamiento con puntos sintéticos.

Dentro de G=400–800 W/m² y T=25–50 °C se utiliza la referencia del modelo; fuera se utiliza INC y se suspende la adaptación neuronal. Es una limitación de cobertura del modelo actual, no una limitación del panel. En ambos casos la orden se aplica mediante el enlace nuevo, siempre que exista confirmación y Ns=Np=1. Los valores mínimos de G/T del chip no se recortan para forzarlos a entrar en el modelo.

MPPT_MODE permite comparar con P&O (0), INC (1), P&O adaptativo (2) y modelo con aprendizaje (3, predeterminado), todos con el mismo enlace de actuación y adquisición. MPPT_ONLINE_LEARNING=0 congela los parámetros para evaluar el efecto de la adaptación. Una mayor cantidad de actualizaciones no demuestra una mejor extracción de energía.

## Confirmación y temporización

El protocolo usa órdenes `SET,secuencia,carga` y respuestas `ACK,secuencia,orden,aplicada,modo,Ns,Np`.

- El chip aplica la orden en su siguiente actualización, cada 50 ms.
- La confirmación sale después de escribir las cuatro señales analógicas.
- El ESP32 verifica secuencia, orden, rangos y frescura, y espera al menos 100 ms desde el envío antes de medir.
- El control se programa cada 500 ms, sin añadir un delay fijo de 500 ms al tiempo de inferencia.
- Sin confirmación válida o con enlace vencido, no se ejecutan nuevas decisiones ni aprendizaje. Se reintenta la misma orden cada 600 ms.
- En modo manual del chip o con Ns/Np diferentes de 1, se informa HOLD. El algoritmo no está validado para arreglos distintos de un panel.

El ACK confirma el valor utilizado por el modelo del chip, no una medida independiente de un actuador físico.

## Serial

| Columna | Interpretación |
|---|---|
| V_V, I_A, P_W, G_Wm2, T_C | Mediciones |
| ACK_seq | Secuencia confirmada correspondiente al estado medido |
| confirmed_cmd_pct | Orden que el chip confirmó |
| applied_pct | Carga que el chip aplicó, incluida la perturbación de la barra |
| next_cmd_pct | Orden calculada que se envía para el siguiente ciclo |
| Delta_cmd_pct | Siguiente orden menos orden confirmada |
| source | 1 modelo neuronal; 3 INC por fuera de cobertura; 4 medición inválida; 10/11/12 ramas convencionales |
| ref_valid, Vmp_model_V, error_V | Validez, referencia y error de tensión |
| I_pred_A, model_error_A | Predicción anterior al aprendizaje y error de corriente |
| learning_updates, learned, parameter_change | Contador, actualización del ciclo y cambio de parámetros |
| control_us | Tiempo de cálculo real en el ESP32; no medido en el banco con API simulada |
| at_limit, retries | Saturación de orden y reintentos de comunicación |

Una línea muestra la carga aplicada que produjo sus mediciones y la orden que se enviará después. Es normal que confirmed_cmd_pct y next_cmd_pct difieran durante la recuperación. La carga aplicada ya no se infiere a partir de V/Voc ni se confunde con una variable local del ESP32.

## Primera prueba en Wokwi

No repetir barridos. Arrancar la copia nueva con los valores iniciales durante 20 segundos, sin mover barras.

Resultado esperado, pendiente de comprobar en Wokwi: partir cerca de 20.65 V/227 W y aproximarse a 31.4 V/308 W, mientras applied_pct baja desde 50 hacia 24 %. Las secuencias ACK deben avanzar y la orden no debe quedarse en cero sin que cambien las mediciones.

Después, si la primera prueba responde así, mover únicamente la barra Load de 50 a 60. La columna applied_pct debe cambiar y posteriormente volver cerca de 24 % mientras la orden del ESP32 compensa. No añadir simultáneamente cambios de G/T a esta primera comprobación.

Si aparece HOLD esperando ACK, revisar que se copiaron juntos los SEIS archivos y que se está ejecutando la copia experimental con modo automático=1. No cambiar límites del modelo, calibración o el proyecto original para eliminar el mensaje.

## Verificación realizada

Se compiló el código C real del chip experimental con gcc y el .ino real con g++. Se conectaron mediante interfaces de las API Wokwi/Arduino simuladas, conservando la misma conversión ADC, el ruido del chip y las ecuaciones físicas. Se probaron las cuatro ramas de control con el mismo recorrido de actuación. También se probaron pérdida de comunicación, recuperación, ausencia total de ACK y tramas malformadas.

En la prueba nominal del modelo con aprendizaje, el estado estable entre 10 y 19 s estuvo en promedio en 31.35 V, 307.91 W y carga aplicada 24.07 %. Tras una perturbación de barra 50→60 a los 20 s, entre 30 y 39 s se obtuvieron unos 31.37 V y 307.94 W, con orden 14.04 % y carga aplicada 24.04 %. Estos son resultados del banco, NO mediciones de Wokwi o hardware. El criterio de cinco muestras consecutivas a ±0.20 V de la referencia se alcanzó a los 10.5 s de arranque y unos 7 s después de la perturbación.

A 600 W/m² y 37 °C, en otra ejecución del banco, hubo 11 actualizaciones de aprendizaje y unos 30.22 V/222.13 W en el tramo estable. No se fuerza el contador a crecer cuando el modelo ya predice dentro de su zona muerta de 0.04 A.

La figura respuesta_integracion.png, trazas y resultados detallados están en validacion/. Las diferencias entre fuentes están en los archivos .diff. Los cocientes de potencia calculados en el banco pueden superar ligeramente 1 por redondeo de G/T, ruido y cuantización. No se recortan para aparentar una eficiencia física exacta y no se presentan como eficiencia experimental.

Pendientes: compilación con el SDK ESP32, compilación WASM del chip por Wokwi, temporización real de UART en Wokwi y ejecución de esta copia en Wokwi. El banco usa entrega síncrona de bytes y no sustituye esas comprobaciones. No se afirma superioridad de aprendizaje frente a los tres algoritmos con esta única prueba. El proyecto original permanece intacto.

Para reproducir el banco: `python tools/verify.py` (numpy, gcc y g++). Las cabeceras de tests/stubs son exclusivamente del banco y no se distribuyen como SDK de Wokwi.

Documentación oficial consultada: https://docs.wokwi.com/chips-api/uart y https://docs.wokwi.com/chips-api/attributes.

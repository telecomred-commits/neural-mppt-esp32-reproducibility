#include "wokwi-api.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
void chip_init(void);
static struct {char name[48];float value;} attrs[40];
static uint32_t attr_count=0;
static struct {char name[24];float value;} pins[16];
static int pin_count=0;
static uart_config_t uart;
static timer_config_t timer_config;
static char queue[65536];static unsigned head=0,tail=0;
static bool bridge_enabled=true;
uint32_t attr_init(const char*name,uint32_t value){
 for(uint32_t n=1;n<=attr_count;++n)if(!strcmp(attrs[n].name,name))return n;
 uint32_t n=++attr_count;snprintf(attrs[n].name,sizeof(attrs[n].name),"%s",name);attrs[n].value=value;
 if(!strcmp(name,"V_sense_max"))attrs[n].value=50;
 if(!strcmp(name,"I_sense_max"))attrs[n].value=15;
 return n;
}
uint32_t attr_read(uint32_t id){return (uint32_t)attrs[id].value;}
void host_set_attr(const char*name,float value){for(uint32_t n=1;n<=attr_count;++n)if(!strcmp(attrs[n].name,name)){attrs[n].value=value;return;}assert(0);}
pin_t pin_init(const char*name,uint32_t mode){(void)mode;int n=++pin_count;snprintf(pins[n].name,sizeof(pins[n].name),"%s",name);return n;}
float pin_dac_write(pin_t pin,float value){pins[pin].value=value;return value;}
float host_voltage(const char*name){for(int n=1;n<=pin_count;++n)if(!strcmp(pins[n].name,name))return pins[n].value;return 0;}
uart_dev_t uart_init(const uart_config_t*c){uart=*c;return 1;}
bool uart_write(uart_dev_t id,uint8_t*bytes,uint32_t n){(void)id;if(bridge_enabled)for(uint32_t k=0;k<n;++k){assert(tail+1<sizeof(queue));queue[tail++]=(char)bytes[k];}if(uart.write_done)uart.write_done(uart.user_data);return true;}
timer_t timer_init(const timer_config_t*c){timer_config=*c;return 1;}
void timer_start(timer_t id,uint32_t us,bool repeat){(void)id;assert(us==50000&&repeat);}
void host_tick(void){timer_config.callback(timer_config.user_data);}
void host_receive(const char*text){if(bridge_enabled)for(size_t n=0;text[n];++n)uart.rx_data(uart.user_data,(uint8_t)text[n]);}
int host_available(void){return (int)(tail-head);}
int host_read(void){if(head>=tail){head=tail=0;return -1;}int b=(unsigned char)queue[head++];if(head==tail)head=tail=0;return b;}
void host_bridge(int enabled){bridge_enabled=enabled!=0;}
void host_init(void){chip_init();host_tick();}

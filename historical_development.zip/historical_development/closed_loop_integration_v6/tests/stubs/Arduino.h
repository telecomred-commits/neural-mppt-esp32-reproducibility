#pragma once
#include <cstdint>
#include <cstdio>
#include <cmath>
#include <string>
#include <iostream>
#include <iomanip>
extern "C" {
void host_init(void);void host_tick(void);void host_receive(const char*);
void host_set_attr(const char*,float);float host_voltage(const char*);
int host_available(void);int host_read(void);void host_bridge(int);
}
extern unsigned long simulated_ms;
void advance_time(unsigned long ms);
constexpr int ADC_11db=0,SERIAL_8N1=0;
struct SerialMock {
 void begin(int){}
 template<class T>void print(T v){std::cout<<v;}
 void print(float v,int digits){std::cout<<std::fixed<<std::setprecision(digits)<<v;}
 template<class T>void println(T v){std::cout<<v<<"\n";}
 void println(float v,int digits){print(v,digits);std::cout<<"\n";}
};
struct UARTMock {
 void begin(int baud,int config,int rx,int tx){(void)config;if(baud!=115200||rx!=16||tx!=17)std::abort();}
 void println(const char*s){std::string frame=s;frame+='\n';host_receive(frame.c_str());}
 int available(){return host_available();}int read(){return host_read();}
};
static SerialMock Serial;
static UARTMock Serial2;
inline void analogReadResolution(int bits){if(bits!=12)std::abort();}
inline void analogSetAttenuation(int){}
inline uint32_t analogRead(int pin){const char*n=pin==34?"V_OUT":pin==35?"I_OUT":pin==33?"G_OUT":"T_OUT";return (uint32_t)std::lround(host_voltage(n)/5.0f*4095);}
inline unsigned long millis(){return simulated_ms;}
inline unsigned long micros(){return simulated_ms*1000;}
inline void delay(int ms){advance_time((unsigned long)ms);}

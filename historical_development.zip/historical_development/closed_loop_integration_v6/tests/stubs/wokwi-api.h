#pragma once
#include <stdint.h>
#include <stdbool.h>
typedef int32_t pin_t;
typedef uint32_t uart_dev_t;
typedef uint32_t timer_t;
enum {INPUT=0,OUTPUT=1,INPUT_PULLUP=2,ANALOG=4};
typedef struct {void*user_data;pin_t rx;pin_t tx;uint32_t baud_rate;void(*rx_data)(void*,uint8_t);void(*write_done)(void*);uint32_t reserved[8];} uart_config_t;
typedef struct {void*user_data;void(*callback)(void*);uint32_t reserved[8];} timer_config_t;
pin_t pin_init(const char*,uint32_t);
float pin_dac_write(pin_t,float);
uint32_t attr_init(const char*,uint32_t);
uint32_t attr_read(uint32_t);
uart_dev_t uart_init(const uart_config_t*);
bool uart_write(uart_dev_t,uint8_t*,uint32_t);
timer_t timer_init(const timer_config_t*);
void timer_start(timer_t,uint32_t,bool);

#include "Arduino.h"
#include <cassert>
unsigned long simulated_ms=0;
void advance_time(unsigned long ms){
 unsigned long end=simulated_ms+ms;
 while(simulated_ms<end){++simulated_ms;if(simulated_ms%50==0)host_tick();}
}
#include "../experimental/sketch.ino"
int main(int argc,char**argv){
 const std::string scenario=argc>1?argv[1]:"dynamic";
 host_init();
 if(scenario=="unseen"){host_set_attr("irradiance",600);host_set_attr("temperature",37);host_tick();}
 if(scenario=="missing")host_bridge(0);
 setup();
 if(scenario=="malformed"){
  host_receive("SET,99,nan\nSET,99,101\nSET,99,20junk\n");
  for(int n=0;n<200;++n){host_receive("x");}
  host_receive("\n");
 }
 unsigned long duration=scenario=="dynamic"?120000:scenario=="unseen"?20000:scenario=="protocol"?8000:6000;
 bool load_event=false,g_event=false,t_event=false,g_low=false,t_high=false,disconnect=false,reconnect=false;
 while(simulated_ms<duration){
  if(scenario=="dynamic"){
   if(!load_event&&simulated_ms>=20000){host_set_attr("load",60);load_event=true;}
   if(!g_event&&simulated_ms>=40000){host_set_attr("irradiance",400);g_event=true;}
   if(!t_event&&simulated_ms>=60000){host_set_attr("temperature",50);t_event=true;}
   if(!g_low&&simulated_ms>=80000){host_set_attr("irradiance",352);g_low=true;}
   if(!t_high&&simulated_ms>=100000){host_set_attr("temperature",51);t_high=true;}
  }
  if(scenario=="protocol"){
   if(!disconnect&&simulated_ms>=2000){host_bridge(0);disconnect=true;}
   if(!reconnect&&simulated_ms>=4000){host_bridge(1);reconnect=true;}
  }
  loop();
 }
 if(scenario=="missing")assert(controller.predict(20,800,25)>0 && sequence==1 && !have_ack);
 return 0;
}

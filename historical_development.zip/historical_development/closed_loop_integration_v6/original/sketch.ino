#include <Arduino.h>

/* ================= PINES ================= */
const int PIN_V = 34;
const int PIN_I = 35;
const int PIN_G = 33;   // G_OUT del chip
const int PIN_T = 32;   // T_OUT del chip

/* ============== RANGOS DE INSTRUMENTO ============== */
/* DEBEN COINCIDIR con los sliders del chip */
const float V_SENSE_MAX = 600.0f;   // [V]
const float I_SENSE_MAX = 30.0f;   // [A]

/* ============== ESCALAS FÍSICAS DE SENSORES ============== */
const float G_MAX = 1000.0f;  // [W/m²]
const float T_MAX = 100.0f;   // [°C]

/* ============== GANANCIAS DE CALIBRACIÓN ============== */
const float G_V = 1.0f;
const float G_I = 1.0f;
const float G_G = 1.515f;
const float G_T = 1.515f;

/* ================= UTILIDAD ADC ================= */
float readSignal(int pin, float phys_max) {
  uint32_t acc = 0;
  for (int i = 0; i < 20; i++) acc += analogRead(pin);

  float adc_avg = acc / 20.0f;
  float v_adc   = (adc_avg / 4095.0f) * 3.3f;

  return (v_adc / 3.3f) * phys_max;
}

/* ======================================================
   =============== MPPT CONFIG ==========================
   ====================================================== */
#define MPPT_PO        0
#define MPPT_INC       1
#define MPPT_ADAPT_PO  2

#define MPPT_MODE MPPT_ADAPT_PO   // <<< SELECCIONA AQUÍ

/* ======================================================
   =============== MPPT ESTADOS =========================
   ====================================================== */
float P_prev = 0.0f;
float V_prev = 0.0f;

float V_prev_inc = 0.0f;
float I_prev_inc = 0.0f;

float load_mppt = 50.0f;   // [%]
int   dir = +1;

/* ================= LIMITES ================= */
const float LOAD_MIN = 0.0f;
const float LOAD_MAX = 100.0f;

/* ================= P&O FIJO ================= */
const float DELTA_LOAD = 1.0f;

/* ================= INC ================= */
const float EPS_V = 0.05f;   // [V]
const float EPS_I = 0.02f;   // [A]

/* ================= ADAPTIVE P&O ================= */
const float DELTA_MIN = 0.2f;   // [%]
const float DELTA_MAX = 3.0f;   // [%]
const float K_ADAPT   = 0.08f;

/* ================= SETUP ================= */
void setup() {
  Serial.begin(115200);

  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);

    Serial.println("tiempo[ms]\V_Panel[V]\tI_Panel[A]\tR_Carga[Ohms]\tP_Panel[W]\tG[W/m2]\tT[°C]\tLoad[%]");
  
}

/* ================= LOOP ================= */
void loop() {

  /* ---------- Reconstrucción eléctrica ---------- */
  float V_panel = readSignal(PIN_V, V_SENSE_MAX) * G_V;
  float I_panel = readSignal(PIN_I, I_SENSE_MAX) * G_I;
  float P_panel = V_panel * I_panel;
  float R_carga = V_panel / I_panel;
  unsigned long t_ms = millis();

  /* ---------- Sensores ambientales ---------- */
  float G_irr  = readSignal(PIN_G, G_MAX) * G_G;
  float T_cell = readSignal(PIN_T, T_MAX) * G_T;

  /* ======================================================
     ================= MPPT CORE ==========================
     ====================================================== */

#if MPPT_MODE == MPPT_PO
  /* ---------- P&O CLÁSICO (paso fijo) ---------- */
  float dP = P_panel - P_prev;

  if (dP < 0.0f) {
    dir = -dir;
  }

  load_mppt += dir * DELTA_LOAD;

#elif MPPT_MODE == MPPT_INC
  /* ---------- INCREMENTAL CONDUCTANCE ---------- */
  float dV = V_panel - V_prev_inc;
  float dI = I_panel - I_prev_inc;

  if (fabs(dV) < EPS_V) {
    if (fabs(dI) < EPS_I) {
      /* En MPP */
    } else if (dI > 0.0f) {
      load_mppt -= DELTA_LOAD;
    } else {
      load_mppt += DELTA_LOAD;
    }
  } else {
    float inc_cond  = dI / dV;
    float inst_cond = -I_panel / V_panel;

    if (fabs(inc_cond - inst_cond) < 0.01f) {
      /* En MPP */
    } else if (inc_cond > inst_cond) {
      load_mppt -= DELTA_LOAD;
    } else {
      load_mppt += DELTA_LOAD;
    }
  }

  V_prev_inc = V_panel;
  I_prev_inc = I_panel;

#elif MPPT_MODE == MPPT_ADAPT_PO
  /* ---------- ADAPTIVE P&O ---------- */
  float dP = P_panel - P_prev;
  float dV = V_panel - V_prev;

  float delta_adapt = DELTA_MIN;

  if (fabs(dV) > 0.01f) {
    delta_adapt = K_ADAPT * fabs(dP / dV);
  }

  if (delta_adapt > DELTA_MAX) delta_adapt = DELTA_MAX;
  if (delta_adapt < DELTA_MIN) delta_adapt = DELTA_MIN;

  if (dP < 0.0f) {
    dir = -dir;
  }

  load_mppt += dir * delta_adapt;
#endif

  /* ---------- Saturación ---------- */
  if (load_mppt > LOAD_MAX) load_mppt = LOAD_MAX;
  if (load_mppt < LOAD_MIN) load_mppt = LOAD_MIN;

  /* ---------- Comunicación con el chip ---------- */
  Serial.print("load=");
  Serial.println(load_mppt, 2);

  /* ---------- Memoria ---------- */
  P_prev = P_panel;
  V_prev = V_panel;

  /* ---------- Telemetría ---------- */
  Serial.print(t_ms); Serial.print("\t");
  Serial.print(V_panel, 1); Serial.print("\t\t");
  Serial.print(I_panel, 1); Serial.print("\t\t");
  Serial.print(R_carga, 1); Serial.print("\t\t");
  Serial.print(P_panel, 1); Serial.print("\t\t");
  Serial.print(G_irr, 0);   Serial.print("\t\t");
  Serial.print(T_cell, 1);  Serial.print("\t\t");
  Serial.println(load_mppt, 1);

  delay(500);
}




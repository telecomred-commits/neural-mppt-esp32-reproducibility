#include "wokwi-api.h"
#include <stdlib.h>
#include <math.h>

/* =========================================================
   CHIP FV – MODELO FÍSICAMENTE CONSISTENTE (G + T + NsNp)
   + Instrumentación realista:
     - Error de ganancia
     - Offset
     - Ruido blanco (gaussiano)
     - Ripple sinusoidal opcional (fase acumulada)
   ========================================================= */

/* ================= TIEMPO PARA RIPPLE (sin millis) =================
   El timer del chip corre a 50 ms => 20 Hz:
     timer_start(..., 50000, true);
   Por eso DT=0.05 s.
*/
static const float DT = 0.05f;              // [s] periodo de actualización (50 ms)
static const float RIPPLE_FREQ = 1000.0f;   // [Hz] ripple "switching" (didáctico)
static float ripple_phase = 0.0f;           // [rad] fase acumulada

/* ================= ESTADO DEL CHIP ================= */
typedef struct {
  pin_t v_out;
  pin_t i_out;
  pin_t g_out;
  pin_t t_out;

  uint32_t load_attr;
  uint32_t irr_attr;
  uint32_t temp_attr;

  uint32_t ns_attr;
  uint32_t np_attr;

  uint32_t vsm_attr;
  uint32_t ism_attr;

  /* --- Errores de VOLTAJE --- */
  uint32_t V_gain_attr;
  uint32_t V_off_attr;
  uint32_t V_noise_attr;
  uint32_t V_ripple_attr;

  /* --- Errores de CORRIENTE --- */
  uint32_t I_gain_attr;
  uint32_t I_off_attr;
  uint32_t I_noise_attr;
  uint32_t I_ripple_attr;

} chip_state_t;

/* ================= PARÁMETROS FV ================= */
static const float V_OC_REF = 41.3f;   // [V] @25°C (1 panel)
static const float I_SC_REF = 13.8f;   // [A] @1000 W/m²
static const float G_REF    = 1000.0f;
static const float T_REF    = 25.0f;

/* Coeficientes térmicos */
static const float ALPHA_V = -0.003f;
static const float ALPHA_I = +0.0004f;
static const float BETA_K  = 0.002f;
static const float K_REF   = 8.0f;

/* ADC */
static const float ADC_MAX = 3.3f;
static const float G_MAX   = 1000.0f;
static const float T_MAX   = 100.0f;

/* ================= UTILIDADES ================= */
static float clamp(float x, float a, float b) {
  if (x < a) return a;
  if (x > b) return b;
  return x;
}

static float frand(void) {
  return (float)rand() / (float)RAND_MAX;
}

/* Aproximación gaussiana N(0,1) por CLT */
static float gauss01(void) {
  float s = 0.0f;
  for (int i = 0; i < 12; i++) s += frand();
  return s - 6.0f;
}

/* ================= MODELO FV ================= */
void solar_update(void *user_data) {
  chip_state_t *c = (chip_state_t *)user_data;

  /* ---------- Avance de fase (ripple) ---------- */
  ripple_phase += 2.0f * (float)M_PI * RIPPLE_FREQ * DT;
  /* Mantener fase acotada para estabilidad numérica */
  if (ripple_phase > 2.0f * (float)M_PI) {
    ripple_phase -= 2.0f * (float)M_PI;
  }

  /* ---------- Entradas ---------- */
  float u  = clamp(attr_read(c->load_attr) / 100.0f, 0.0f, 1.0f);
  float G  = clamp(attr_read(c->irr_attr), 0.0f, G_REF);
  float T  = attr_read(c->temp_attr);

  float Ns = clamp(attr_read(c->ns_attr), 1.0f, 12.0f);
  float Np = clamp(attr_read(c->np_attr), 1.0f, 10.0f);

  float V_sense_max = clamp(attr_read(c->vsm_attr), 10.0f, 600.0f);
  float I_sense_max = clamp(attr_read(c->ism_attr), 1.0f, 30.0f);

  /* ---------- Parámetros efectivos (1 panel) ---------- */
  float I_SC_eff_1 =
      I_SC_REF * (G / G_REF) *
      (1.0f + ALPHA_I * (T - T_REF));

  float V_OC_eff_1 =
      V_OC_REF * (1.0f + ALPHA_V * (T - T_REF));
  V_OC_eff_1 = clamp(V_OC_eff_1, 0.0f, V_OC_REF);

  float K_eff =
      K_REF * (1.0f - BETA_K * (T - T_REF));
  K_eff = clamp(K_eff, 1.0f, K_REF);

  /* ---------- Punto de operación (1 panel) ---------- */
  float V_panel_1 = clamp(V_OC_eff_1 * (1.0f - u), 0.0f, V_OC_eff_1);

  float ratio = (V_OC_eff_1 > 0.0f) ? (V_panel_1 / V_OC_eff_1) : 0.0f;

  float I_panel_1 =
      I_SC_eff_1 * (1.0f - powf(ratio, K_eff));
  I_panel_1 = clamp(I_panel_1, 0.0f, I_SC_eff_1);

  /* ---------- Escalamiento a arreglo ---------- */
  float V_array = Ns * V_panel_1;
  float I_array = Np * I_panel_1;

  /* ---------- Conversión ideal a ADC ---------- */
  float V_adc = (V_array / V_sense_max) * ADC_MAX;
  float I_adc = (I_array / I_sense_max) * ADC_MAX;

  /* ---------- Errores de medición ---------- */

  /* VOLTAJE */
  float V_gain = 1.0f + attr_read(c->V_gain_attr) * 0.01f;   // [%] -> escala
  float V_off  = attr_read(c->V_off_attr) * 1e-3f;           // mV -> V (ADC)
  float V_sig  = attr_read(c->V_noise_attr) * 1e-3f;         // mV RMS aprox.
  float V_rip  = attr_read(c->V_ripple_attr) * 1e-3f;        // mV pk

  V_adc = V_adc * V_gain
        + V_off
        + V_sig * gauss01()
        + V_rip * sinf(ripple_phase);

  /* CORRIENTE */
  float I_gain = 1.0f + attr_read(c->I_gain_attr) * 0.01f;
  float I_off  = attr_read(c->I_off_attr) * 1e-3f;
  float I_sig  = attr_read(c->I_noise_attr) * 1e-3f;
  float I_rip  = attr_read(c->I_ripple_attr) * 1e-3f;

  I_adc = I_adc * I_gain
        + I_off
        + I_sig * gauss01()
        + I_rip * sinf(ripple_phase);

  /* ---------- Señales ambientales ---------- */
  float G_adc = (G / G_MAX) * ADC_MAX;
  float T_adc = (T / T_MAX) * ADC_MAX;

  /* ---------- Salidas ---------- */
  pin_dac_write(c->v_out, clamp(V_adc, 0.0f, ADC_MAX));
  pin_dac_write(c->i_out, clamp(I_adc, 0.0f, ADC_MAX));
  pin_dac_write(c->g_out, clamp(G_adc, 0.0f, ADC_MAX));
  pin_dac_write(c->t_out, clamp(T_adc, 0.0f, ADC_MAX));
}

/* ================= INIT ================= */
void chip_init(void) {
  /* Semilla reproducible (misma corrida => mismos resultados)
     Si quieres aleatorio, cambia a srand((unsigned)time(NULL)) pero no hay time() aquí.
  */
  srand(1);

  chip_state_t *c = calloc(1, sizeof(chip_state_t));

  /* Pines */
  c->v_out = pin_init("V_OUT", ANALOG);
  c->i_out = pin_init("I_OUT", ANALOG);
  c->g_out = pin_init("G_OUT", ANALOG);
  c->t_out = pin_init("T_OUT", ANALOG);

  /* Atributos físicos */
  c->load_attr = attr_init("load", 50);
  c->irr_attr  = attr_init("irradiance", 800);
  c->temp_attr = attr_init("temperature", 25);

  c->ns_attr   = attr_init("Ns", 1);
  c->np_attr   = attr_init("Np", 1);

  /* Rangos de instrumentación */
  c->vsm_attr  = attr_init("V_sense_max", 600);
  c->ism_attr  = attr_init("I_sense_max", 30);

  /* Errores VOLTAJE */
  c->V_gain_attr   = attr_init("V_gain_pct", 0);
  c->V_off_attr    = attr_init("V_offset_mV", 0);
  c->V_noise_attr  = attr_init("V_noise_mV", 2);
  c->V_ripple_attr = attr_init("V_ripple_mV", 0);

  /* Errores CORRIENTE */
  c->I_gain_attr   = attr_init("I_gain_pct", 0);
  c->I_off_attr    = attr_init("I_offset_mV", 0);
  c->I_noise_attr  = attr_init("I_noise_mV", 1);
  c->I_ripple_attr = attr_init("I_ripple_mV", 0);

  const timer_config_t cfg = {
    .callback = solar_update,
    .user_data = c
  };

  /* 20 Hz (50 ms) */
  timer_start(timer_init(&cfg), 50000, true);
}


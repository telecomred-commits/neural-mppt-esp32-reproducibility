from pathlib import Path
import subprocess,tempfile,json,hashlib
import numpy as np
R=Path(__file__).resolve().parents[1]
results={}
with tempfile.TemporaryDirectory() as d:
 p=Path(d)
 gcc=['gcc','-O2','-std=c11','-DM_PI=3.14159265358979323846','-Wall','-Wextra','-Werror','-I',str(R/'tests/stubs')]
 subprocess.run(gcc+['-c',str(R/'experimental/solar.chip.c'),'-o',str(p/'chip.o')],check=True)
 subprocess.run(gcc+['-c',str(R/'tests/chip_host.c'),'-o',str(p/'host.o')],check=True)
 for mode in [3,0,1,2]:
  exe=p/f'mode{mode}'
  subprocess.run(['g++','-O2','-std=c++11','-Wall','-Wextra','-Werror',f'-DMPPT_MODE={mode}','-I',str(R/'tests/stubs'),str(R/'tests/integration.cpp'),str(p/'chip.o'),str(p/'host.o'),'-lm','-o',str(exe)],check=True)
  scenarios=['dynamic','missing','protocol','malformed','unseen'] if mode==3 else ['dynamic']
  for scenario in scenarios:
   text=subprocess.run([str(exe),scenario],capture_output=True,text=True,check=True).stdout
   (R/'validacion'/f'mode{mode}_{scenario}.txt').write_text(text)
   rows=[]
   for line in text.splitlines():
    f=line.split()
    if len(f)==23:
     try:rows.append(list(map(float,f)))
     except ValueError:pass
   a=np.asarray(rows)
   if scenario=='missing':assert not len(a) and '# HOLD:' in text;results['missing_ack']='No control/learning samples; same command retried';continue
   assert len(a) and np.isfinite(a).all()
   assert (a[:,7:10]>=0).all() and (a[:,7:10]<=100).all()
   assert np.max(abs(a[:,10]))<=3.001
   # The chip's actual analog V follows the ACK's APPLIED load, not just a local command.
   voc=np.minimum(41.3,41.3*(1-.003*(a[:,5]-25)))
   expected=voc*(1-a[:,8]/100)
   mae=float(np.mean(abs(a[:,1]-expected)));assert mae<.12,(mode,scenario,mae)
   entry={'samples':len(a),'measured_V_vs_applied_load_model_MAE_V':mae,'max_learning_updates':float(a[:,17].max()),'segments':[]}
   for lo,hi in [(10000,19000),(30000,39000),(50000,59000),(70000,79000),(90000,99000),(110000,119000)]:
    b=a[(a[:,0]>=lo)&(a[:,0]<hi)]
    if len(b):
     k=np.minimum(8,8*(1-.002*(b[:,5]-25)));vc=np.minimum(41.3,41.3*(1-.003*(b[:,5]-25)));isc=13.8*b[:,4]/1000*(1+.0004*(b[:,5]-25));rr=(1/(k+1))**(1/k);pmax=vc*rr*isc*k/(k+1)
     entry['segments'].append({'start_ms':lo,'G':float(b[:,4].mean()),'T':float(b[:,5].mean()),'V_mean':float(b[:,1].mean()),'P_mean':float(b[:,3].mean()),'mean_power_fraction_model':float(np.mean(b[:,3]/pmax)),'command':float(b[:,7].mean()),'applied':float(b[:,8].mean()),'source':sorted(set(b[:,11].tolist()))})
   if scenario=='unseen':
    assert entry['max_learning_updates']>0 and entry['segments'][0]['mean_power_fraction_model']>.98
   if scenario=='dynamic' and mode==3:
    # Recovery of maximum after start and achievable disturbance inside learned model domain.
    for segment in entry['segments'][:4]:assert segment['mean_power_fraction_model']>.98,segment
   if scenario=='protocol':
    assert not np.any((a[:,0]>2400)&(a[:,0]<4000)),a[:,0];assert np.any(a[:,0]>4300)
   results[f'mode{mode}_{scenario}']=entry
for n,digest in json.loads((R/'validacion/originales_sha256.json').read_text()).items():assert hashlib.sha256((R/'original'/n).read_bytes()).hexdigest()==digest
# Explicitly verify all original connection pairs survive and the equations after u are unchanged.
orig=json.loads((R/'original/diagram.json').read_text());exp=json.loads((R/'experimental/diagram.json').read_text());assert all(c in exp['connections'] for c in orig['connections'])
a=(R/'original/solar.chip.c').read_text();b=(R/'experimental/solar.chip.c').read_text();start=a.index('  float G  = clamp');end=a.index('  pin_dac_write(c->t_out, clamp(T_adc, 0.0f, ADC_MAX));')+len('  pin_dac_write(c->t_out, clamp(T_adc, 0.0f, ADC_MAX));');assert a[start:end] in b
results['scope']={'actual_sources':'actual experimental chip C + actual .ino compiled and connected through host API mocks','serial_timing':'bytes delivered synchronously by mock; does not validate UART timing in Wokwi','ADC':'5 V virtual mapping, rounded 12-bit; elapsed compute_us is not measured in mock','ESP32_SDK_compile':'not run','Wokwi_run':'pending','original_bytes_unchanged':True,'model_equations_unchanged':True,'measured_efficiency_claim':False}
(R/'validacion/integracion.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))

from pathlib import Path
R=Path(__file__).resolve().parents[1]
s=(R/'original/solar.chip.c').read_text()
s=s.replace('#include <math.h>','#include <math.h>\n#include <stdio.h>\n#include <string.h>\n#include <stdbool.h>')
s=s.replace('  uint32_t load_attr;', '''  uint32_t load_attr;
  /* Experimental control bridge; original model equations remain below. */
  uint32_t control_mode_attr;
  uart_dev_t control_uart;
  float command_pct;
  float applied_pct;
  uint32_t command_seq;
  char rx_line[64];
  uint32_t rx_length;
  bool rx_overflow;
  char tx_line[128];
  bool tx_busy;
  uint32_t heartbeat_ticks;''')
marker='/* ================= MODELO FV ================= */'
bridge=r'''/* Command accepted here, applied only at the next solar_update(). */
static void control_rx(void *user_data, uint8_t byte) {
  chip_state_t *c = (chip_state_t *)user_data;
  if (byte == '\r') return;
  if (byte == '\n') {
    if (!c->rx_overflow && c->rx_length > 0) {
      c->rx_line[c->rx_length] = 0;
      unsigned long seq = 0;
      float load = 0;
      char extra = 0;
      int count = sscanf(c->rx_line, "SET,%lu,%f%c", &seq, &load, &extra);
      if (count == 2 && seq > 0 && seq <= UINT32_MAX && isfinite(load)
          && load >= 0.0f && load <= 100.0f) {
        c->command_pct = load;
        c->command_seq = (uint32_t)seq;
        c->heartbeat_ticks = 2;
      }
    }
    c->rx_length = 0;
    c->rx_overflow = false;
  } else if (!c->rx_overflow) {
    if (c->rx_length + 1 < sizeof(c->rx_line)) c->rx_line[c->rx_length++] = (char)byte;
    else c->rx_overflow = true;
  }
}
static void control_write_done(void *user_data) {
  ((chip_state_t *)user_data)->tx_busy = false;
}
static void control_report(chip_state_t *c, uint32_t mode, float ns, float np) {
  if (++c->heartbeat_ticks < 2 || c->tx_busy) return;
  int n = snprintf(c->tx_line, sizeof(c->tx_line), "ACK,%lu,%.3f,%.3f,%lu,%u,%u\n",
      (unsigned long)c->command_seq, c->command_pct, c->applied_pct,
      (unsigned long)mode, (unsigned)ns, (unsigned)np);
  if (n <= 0 || (size_t)n >= sizeof(c->tx_line)) return;
  c->tx_busy = true;
  if (uart_write(c->control_uart, (uint8_t *)c->tx_line, (uint32_t)n)) c->heartbeat_ticks = 0;
  else c->tx_busy = false;
}

'''
assert marker in s;s=s.replace(marker,bridge+marker)
s=s.replace('  float u  = clamp(attr_read(c->load_attr) / 100.0f, 0.0f, 1.0f);', '''  uint32_t control_mode = attr_read(c->control_mode_attr);
  float slider_load = clamp(attr_read(c->load_attr), 0.0f, 100.0f);
  /* In automatic mode, slider 50 is neutral; moving it adds a load disturbance. */
  c->applied_pct = control_mode == 1
      ? clamp(c->command_pct + slider_load - 50.0f, 0.0f, 100.0f)
      : slider_load;
  float u = c->applied_pct / 100.0f;''')
s=s.replace('  pin_dac_write(c->t_out, clamp(T_adc, 0.0f, ADC_MAX));','''  pin_dac_write(c->t_out, clamp(T_adc, 0.0f, ADC_MAX));
  /* ACK is emitted AFTER applying load and updating every analog output. */
  control_report(c, control_mode, Ns, Np);''')
s=s.replace('  c->load_attr = attr_init("load", 50);', '''  c->load_attr = attr_init("load", 50);
  c->control_mode_attr = attr_init("control_mode", 1);
  c->command_pct = 50.0f;
  c->applied_pct = 50.0f;
  const uart_config_t control_config = {
    .rx = pin_init("CTRL_RX", INPUT),
    .tx = pin_init("CTRL_TX", INPUT_PULLUP),
    .baud_rate = 115200,
    .rx_data = control_rx,
    .write_done = control_write_done,
    .user_data = c,
  };
  c->control_uart = uart_init(&control_config);''')
(R/'experimental/solar.chip.c').write_text(s)
print('chip lines',len(s.splitlines()))

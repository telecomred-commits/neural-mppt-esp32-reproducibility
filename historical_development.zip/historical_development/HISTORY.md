# Historical development and provenance

These source archives were supplied by the researchers in the present conversation. Original ZIP bytes have been preserved under `original_archives/`. Folder order below is a **functional reconstruction based on the named versions and project documentation**, not an independently verified timestamped timeline. Do not pool training data or claim that all intermediate models represent the final published algorithm.

| Stage | Evidence | Role in published study |
|---|---|---|
| 00 | Original digital PV model and P&O/INC/adaptive P&O project | Starting plant and conventional controllers |
| 01 | 27 `Pruebas_panel` text records | Historical conventional trajectories, not optimal-voltage training labels |
| 02 | Neural V1, 3–16–8–1 policy model trained partly on synthetic observations | Historical prototype only; **not** NN-I, NN-C or NN-V |
| 03 | Neural V2, 12–32–16–1 imitation of logged load changes | Historical alternative; historical commands are not independent MPP labels |
| 04 | V3, 2–4–1 learned voltage reference from four curve-level estimates | Preliminary reference model |
| 05 | V4, reference-tracking and conventional feedback | Historical hybrid controller |
| 06 | **V5, 2–16–1 neural current model with 65 weights, trained from 1012 calibrated I–V observations** | **Original training source for the fixed weights used by NN-I/V6** |
| 07 | V6, digital load-command/ACK closed loop and host integration | Basis for the initial NN-I host campaign |
| 08 | Seven-profile, five-variant, ten-seed host experiment | 350 original host simulation records; separate from Wokwi simulation records |
| 09 | Execution kit with validation routines and planned Wokwi scenarios | Prepared Wokwi automated scenarios; documentation explicitly marks some as pending |

**Important:** The latest NN-C/V8 constrained recalibration and NN-V/V9 verification, plus 880-run and 60-run results, remain in `supplementary/` of this repository. V5 and V6 are predecessors, not substitutes for those final sources.

The two independently supplied `sketch(7)` files are byte-identical to one another but have **not been authenticated as the source of a published experiment**. They are stored under `unassigned_early_sketches/`, not silently substituted for published firmware. `ARCHIVE_SHA256.json` maps each historical archive to its original filename and SHA-256.

No physical converter experimentation is claimed. Simulated execution of firmware in Wokwi, source-host execution with mocks, and direct physical hardware evidence are distinct.

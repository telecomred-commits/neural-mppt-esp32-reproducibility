# Proceso para ejecutar los experimentos MPPT

**Guía operativa versión 2 · 27 de octubre de 2026**

El objetivo es comprobar si el controlador mantiene el punto de máxima potencia cuando cambian irradiancia, temperatura o carga y determinar qué aporta la actualización de sus parámetros. Primero ejecutaremos la pareja neuronal con aprendizaje activado y desactivado. Después completaremos los controles P&O, INC y P&O adaptativo.

El ensayo estático anterior ya mostró actualización de parámetros y menor error de corriente. No mostró un beneficio energético del aprendizaje. Las nuevas pruebas deben conservar esa distinción. La copia de ejecución añade identificación y sincronización al serial. La ley de control, los pesos iniciales y las ecuaciones del panel se mantienen.

### 1 Preparar la configuración común

| Elemento | Valor para cada corrida |
| --- | --- |
| Pines analógicos | V 34 · I 35 · G 33 · T 32 |
| Interfaz de la copia experimental actual | RX 16 · TX 17 · 115200 baudios · ACK activo |
| Modo y arreglo del panel | control_mode 1 · Ns 1 · Np 1 |
| Rangos de instrumento | Voltage Sense Range 50 V · Current Sense Range 15 A |
| Ganancias del firmware | V e I 5/3.3 · G y T 1.515 |
| Instrumentación inicial | Ganancia V/I 0% · offset 0 mV · ripple 0 mV |
| Ruido inicial del chip | V 2 mV RMS · I 1 mV RMS |
| Muestreo y arranque | 500 ms · comando inicial 50% · barra Load 50% |

**Qué significan las barras.** Los rangos 50 V y 15 A son escalas de adquisición y quedan fijos. No son la tensión y corriente que se deben imponer al panel. Irradiance y Cell Temperature cambian el ambiente. En modo automático, Load es una perturbación: carga aplicada = clip(comando + Load - 50, 0, 100). Load 50 es neutral, 60 añade 10 puntos y 40 resta 10.

**Archivos.** Usar firmware/sketch.ino y los dos encabezados de este kit en una copia del proyecto experimental actual. El kit no contiene sustitutos de diagram.json ni de solar.chip.c o solar.chip.json. Conservar esos archivos del proyecto. Los stubs del banco host anterior no se suben a Wokwi.

## Primeras pruebas de temperatura y carga

### 2 Ejecutar S2 temperatura

Esta es la primera pareja dinámica que debemos guardar. Arrancar con G 800 W/m², T 25 °C y Load 50. Mantener G y Load durante toda la corrida. El reloj del perfil comienza en la línea **# EXP_START t_ms=...**.

| Tiempo del perfil | Temperatura programada | Vmp independiente aproximado |
| --- | --- | --- |
| 0 a 30 s | 25 °C | 31.381 V |
| 30 a 60 s | 37 °C | 30.131 V |
| 60 a 90 s | 50 °C | 28.783 V |
| 90 a 120 s | 37 °C | 30.131 V |
| 120 a 150 s | 25 °C | 31.381 V |

1. Compilar con MPPT_MODE = 3 y MPPT_ONLINE_LEARNING = 1. Confirmar en # CONFIG que mode=3 y online=1. Reiniciar y ejecutar los 150 s completos.

2. Guardar el serial desde el arranque, con CONFIG, EXP_START, cabecera, muestras y mensajes HOLD. Nombre sugerido: S2_NN_ONLINE_r01.txt.

3. Detener y restaurar la configuración inicial. Cambiar únicamente MPPT_ONLINE_LEARNING a 0, recompilar y reiniciar. Repetir exactamente el perfil. Guardar S2_NN_FROZEN_r01.txt.

El ensayo automático debe usar el escenario S2_temperatura.yaml. Si se hace a mano, anotar los instantes reales y conservarlo como comprobación exploratoria. Mover barras aproximadamente a la misma hora no produce una pareja cuantitativa equivalente.

### 3 Ejecutar S3 carga

| Tiempo del perfil | Barra Load | Perturbación añadida |
| --- | --- | --- |
| 0 a 40 s | 50% | 0 puntos |
| 40 a 80 s | 60% | +10 puntos |
| 80 a 120 s | 40% | -10 puntos |
| 120 a 160 s | 50% | 0 puntos |

Mantener G 800 y T 25. Ejecutar una corrida congelada y otra con aprendizaje, ambas de 160 s y con reinicio entre ellas. El controlador debe compensar el desplazamiento de carga y volver cerca de 31.381 V, dentro de su autoridad de control. El salto de Load 60 a 40 puede producir una saturación transitoria y se conserva en el análisis.

**Qué observar.** V e I deben responder a la perturbación y el comando debe compensarla. En NN_FROZEN los contadores y la distancia de parámetros permanecen en cero. En NN_ONLINE puede haber actualizaciones cuando el error previo de corriente supere 0.04 A. Un contador constante en un tramo estable puede ser correcto.

## Campaña completa y orden de ejecución

### 4 Completar los perfiles fijados

La comparación neuronal primaria incluye S0 a S4. R1 y R2 se analizan aparte. Los eventos exactos están en perfiles/profiles.json y en los archivos .events. Los YAML usan los mismos eventos con una espera inicial al marcador EXP_START.

| Perfil | Duración | Secuencia principal |
| --- | --- | --- |
| S0 estático | 120 s | G600 · T37 · Load50 constantes. Condición de interpolación ya conocida. |
| S1 irradiancia | 160 s | T25/Load50. G800 → 400 en 30 s → 800 en 60 s. Rampas 800 a 400 de 80 a 120 s y retorno hasta 160 s, en pasos de 10 W/m² cada segundo. |
| S2 temperatura | 150 s | G800/Load50. T25 → 37 en 30 s → 50 en 60 s → 37 en 90 s → 25 en 120 s. |
| S3 carga | 160 s | G800/T25. Load50 → 60 en 40 s → 40 en 80 s → 50 en 120 s. |
| S4 combinado | 160 s | (G,T,Load): (600,37,50) → (450,30,60) en 40 s → (750,45,40) en 80 s → (600,37,50) en 120 s. |
| R1 fuera del dominio | 160 s | Load50. (G,T): (800,25) → (200,25) en 40 s → (900,60) en 80 s → (600,37) en 120 s. |
| R2 instrumentación | 180 s | G600/T37/Load50. En 60 s: error de ganancia I +2%, ruido V8/I4 mV. En 120 s: restaurar 0% y ruido V2/I1 mV. |

| Variante | MPPT_MODE | MPPT_ONLINE_LEARNING |
| --- | --- | --- |
| PO | 0 | 0 |
| INC | 1 | 0 |
| ADAPT_PO | 2 | 0 |
| NN_FROZEN | 3 | 0 |
| NN_ONLINE | 3 | 1 |

El registro corridas_planificadas.csv contiene 35 corridas pendientes, una por perfil y variante. Alterna el orden de la pareja neuronal entre perfiles. S0 a S4 con las cinco variantes requieren 62 min 30 s de simulación. R1 y R2 añaden 28 min 20 s. No se cuentan compilación, exportación y revisión.

Los pilotos S2/S3 solo sustituyen sus corridas del registro si cumplen todos los controles y usan la misma versión congelada de firmware, escenarios y pesos. Si se ajusta el algoritmo después, se abre una nueva versión y se repite la campaña comparativa.

**Repeticiones.** El host anterior usa diez semillas emparejadas por perfil. Wokwi conserva srand(1). Repetir el mismo escenario verifica repetibilidad de la implementación, pero no genera nuevas realizaciones independientes de ruido ni un intervalo estadístico de eficiencia.

## Captura automática y comprobación del perfil

### 5 Comprobar primero la ruta automática

La documentación de Wokwi permite escenarios con set-control, delay y wait-serial [1,2]. El soporte efectivo de los controles de este chip personalizado debe probarse en el proyecto actual. Los YAML de este kit no se han ejecutado en Wokwi desde este entorno.

1. Trabajar con una copia del proyecto ya funcional, su circuito y chip actuales, y el .ino instrumentado de este kit. Compilar la variante elegida y conservar la salida de compilación y el ELF.

2. Colocar escenarios_wokwi junto a la configuración local del proyecto. Conservar el identificador panel del componente. No ejecutar una inicialización que reemplace el diagrama existente.

3. Ejecutar S2 como piloto. Comprobar que el serial muestra 25, 37, 50, 37 y 25 °C en los tramos previstos y que el archivo llega al final. Después probar S3 y verificar applied_pct frente a confirmed_cmd_pct.

Ejemplo, desde la raíz del proyecto local ya configurado. Requiere Wokwi CLI y su acceso configurado por el usuario. El timeout debe superar la duración del perfil, porque incluye arranque y sincronización. El mismo timeout se aplica a las dos variantes.

```text
wokwi-cli . \
  --scenario escenarios_wokwi/S2_temperatura.yaml \
  --timeout 155000 \
  --serial-log-file S2_NN_ONLINE_r01.txt
```

La línea EXP_START contiene millis() del firmware. El analizador resta ese origen. El escenario comienza sus demoras al recibir el marcador. La recepción serial y la actualización del chip introducen una pequeña diferencia temporal. La comprobación de entradas permite 250 ms alrededor de los eventos, sin eliminar esas muestras del cálculo de energía.

### 6 Conservar la evidencia de cada corrida

Archivar el serial íntegro, escenario utilizado, .ino compilado, ambos encabezados, ELF, salida de compilación, versión de Wokwi/CLI, versión del núcleo ESP32 y compilador. Completar el registro con esos identificadores y hashes. Registrar éxito, fallo o interrupción. Conservar una corrida fallida junto a su repetición y explicar el motivo.

En R2, conservar además evidencia de los cambios de ganancia y ruido. G/T y la carga permiten contrastar entradas ambientales y mecánica de control, pero no demuestran por sí solas que se aplicó una configuración de ruido.

**Si set-control no actúa sobre el chip.** Detener la campaña automática y resolver esa compatibilidad con el proyecto actual. Se puede continuar con ensayos manuales para observar funcionamiento. No calcular una ventaja causal de energía usando perfiles manuales diferentes.

## Validación de los registros y comparación

### 7 Validar antes de comparar

Desde la raíz del kit, instalar la dependencia y ejecutar el verificador para cada archivo. Cambiar --variant y --log para la corrida congelada.

```text
python3 -m pip install -r tools/requirements.txt

python3 tools/validate_run.py \
  --log S2_NN_ONLINE_r01.txt \
  --profile S2_temperatura --variant NN_ONLINE \
  --execution automated --out S2_online.json
```

El verificador comprueba configuración, 23 columnas, valores finitos, un único arranque, tiempos crecientes, secuencias ACK, continuidad del comando, límites, coherencia de los contadores, duración y coincidencia observable del perfil. Rechaza huecos mayores de 750 ms o una ventana incompleta. Los límites y retransmisiones quedan informados, no se borran.

Las tolerancias operativas para revisar el perfil son ±2 W/m², ±0.15 °C y ±0.03 puntos de carga fuera de la vecindad de los eventos. Son controles de consistencia de este banco, no una calibración metrológica. --execution manual conserva la corrida como exploratoria.

```text
python3 tools/compare_pair.py \
  --online S2_online.json --frozen S2_frozen.json \
  --out S2_pareja.json
```

### 8 Leer los resultados correctos

| Resultado | Cómo interpretarlo |
| --- | --- |
| learning_updates y parameter_change | Demuestran que se modificaron parámetros. No demuestran mayor potencia. |
| RMSE de I antes de actualizar | Mide identificación. Comparar también tramos y soporte de datos equivalentes. |
| Recuperación y oscilación | Cinco muestras seguidas con \|Vmed - Vmp*\| ≤ 0.20 V. Si no se cumple, registrar no alcanzado. |
| Energía y eficiencia de seguimiento | Comparar NN_ONLINE menos NN_FROZEN en una ventana observada común, incluyendo arranque y transitorios. |
| source y ref_valid | Dentro del dominio actúa el predictor. Fuera del dominio se evalúa el respaldo INC por separado. |

La energía es una estimación a partir de muestras de 500 ms. La herramienta usa retención por tramos y separa los eventos ambientales. Informa energía medida V·I y energía reconstruida de la planta usando la carga aplicada. También calcula sensibilidad al método de integración, que no es una cota de incertidumbre. No inventa un intervalo estadístico a partir de una sola pareja Wokwi.

El análisis versión 2 separa los eventos dentro de cada intervalo de integración. Sus cifras no deben mezclarse silenciosamente con el analizador anterior. Para una tabla conjunta, recalcular todos los registros comparados con el mismo analizador. No se extrapola el tramo anterior a la primera muestra ni posterior a la última.

## Criterios para ajustar el algoritmo

### 9 Mantener fija la versión durante la campaña

La tasa de aprendizaje 0.10, el umbral de corriente 0.04 A, la proyección de parámetros ±0.25, la zona muerta de tensión ±0.15 V y el paso máximo ±3 puntos permanecen como están. Las pruebas deben evaluar esta versión antes de introducir un ajuste. No se modifica un umbral solo para conseguir que aumente el contador.

| Observación | Acción concreta |
| --- | --- |
| V e I incoherentes con las barras | Comprobar rangos 50/15, ganancias y Ns/Np antes de tocar la red. Distinguir escala de instrumento y variable del panel. |
| No hay ACK o no se cumple el perfil | Revisar el proyecto experimental y la ruta de automatización. Guardar el fallo. No entrenar ni atribuirlo al predictor. |
| No hay actualizaciones con error pequeño | Es compatible con el umbral de 0.04 A. Conservar la corrida. |
| Hay actualizaciones y baja RMSE, pero no mejora energía | Informar mejora de identificación sin beneficio energético demostrado. Revisar la forma de la curva y la posición del máximo en desarrollo. |
| NN_ONLINE empeora frente a NN_FROZEN | Estudiar deriva del máximo durante desarrollo. Candidatos: memoria de muestras en varios voltajes y regularización frente a las curvas iniciales. Reentrenar y repetir toda la comparación si se adopta un cambio. |
| Ambas redes recuperan el MPP de forma similar | El seguimiento puede depender sobre todo del modelo inicial y del regulador. Conservar la ablación y moderar la contribución atribuida al aprendizaje. |
| Fallo fuera del dominio | Identificar cuánto corresponde al respaldo INC y a saturación. No presentarlo como extrapolación neuronal. |

### 10 Qué conclusión permite cada resultado

Para afirmar mantenimiento del MPP se requiere recuperación frente al máximo independiente y estabilidad tras perturbaciones alcanzables. Para afirmar aprendizaje se requieren cambios de parámetros y evaluación del error previo de predicción. Para afirmar un beneficio energético se necesita la diferencia emparejada frente a la versión congelada.

El criterio exploratorio previo del banco host es una diferencia agregada S0 a S4 de al menos 0.1 puntos porcentuales, límite inferior bootstrap positivo y ausencia de degradaciones relevantes. Se aplica sobre las diez semillas emparejadas del host y no sobre las filas del serial. Los resultados preliminares actuales no cumplen ese criterio. La incertidumbre y resolución también deben permitir distinguir la diferencia.

Un control afín de Vmp sería útil para estudiar si la red aporta más que una aproximación sencilla. No forma parte de estas cinco variantes. Incorporarlo requiere una nueva versión de la campaña. Las curvas a 600/37 ya inspeccionadas no se reclasifican como validación ciega.

## Referencia del máximo y cierre de la campaña

### 11 Usar una referencia independiente de la red

Para Ns=Np=1 y los ambientes de este protocolo, las ecuaciones del panel actual permiten calcular el máximo sin usar la salida neuronal:

```text
Voc = clip(41.3 * (1 - 0.003 * (T - 25)), 0, 41.3)
Isc = 13.8 * G/1000 * (1 + 0.0004 * (T - 25))
k = clip(8 * (1 - 0.002 * (T - 25)), 1, 8)
r = (1/(k + 1)) ** (1/k)
Vmp* = Voc * r
Pmp* = Voc * r * Isc * k/(k + 1)
```

Se emplean G y T programados. La referencia Vmp_model_V de la telemetría es una salida del algoritmo y no la verdad de evaluación. En esta planta G escala la corriente sin desplazar Vmp a T fija. Por eso mantener el voltaje al variar solo irradiancia puede ser correcto. R2 estudia instrumentación, no envejecimiento físico. Este banco no evalúa sombreado parcial ni conversión de potencia real.

### 12 Cerrar cada bloque

1. Guardar las cinco variantes y sus fallos, con archivos de versión y configuración. No sustituir resultados desfavorables por una corrida mejor.

2. Preparar por perfil las gráficas de G/T/Load, V frente a Vmp*, P frente a Pmp*, comando frente a carga aplicada y evolución de aprendizaje. Usar el mismo eje temporal para la pareja.

3. Integrar las tablas de energía, recuperación, oscilación, RMSE, actualizaciones, parámetros, respaldo, saturación y retransmisiones. Separar S0-S4, R1 y R2.

4. Documentar que control_us mide el bloque de cálculo, excluye adquisición, serial y espera del ACK. Los tiempos Wokwi son del simulador. El banco host no mide duración física del ESP32. Medir tiempo y memoria en el destino antes de afirmar prestaciones físicas.

### Fuentes y trazabilidad

[1] Wokwi. Automation Scenarios. docs.wokwi.com/wokwi-ci/automation-scenarios. Consulta 27 octubre 2026. [2] Wokwi. CLI Usage. docs.wokwi.com/wokwi-ci/cli-usage. Misma consulta.

[3] Abouzeid et al. Scientific Reports (2024). DOI 10.1038/s41598-024-67306-0. Comparación ANN, P&O e INC con implementación experimental. [4] Giraldo et al. Heliyon (2024). DOI 10.1016/j.heliyon.2024.e37974. Distinguir simulación y convertidor real.

[5] Amine et al. Energy Science & Engineering (2026). DOI 10.1002/ese3.70555. Antecedente de aprendizaje incremental. [6] Jamshed et al. Electronics (2026). DOI 10.3390/electronics15184342. Implementación y evaluación C-HIL.

[7] Suárez Suárez et al. Energies (2026). DOI 10.3390/en19174131. Modelo digital previo. [8] IEC 62891:2020, ficha oficial. Se toma la distinción estática/dinámica, sin afirmar conformidad normativa. El desarrollo bibliográfico completo se conserva en el protocolo anterior y el manuscrito.

**Verificación del kit.** Se compilaron las cinco variantes con mocks host y se compararon 35 corridas con la versión 6: las 23 columnas numéricas fueron idénticas. Pasaron 11 pruebas de los verificadores. Esto comprueba la preparación del kit, no sustituye la campaña Wokwi pendiente.

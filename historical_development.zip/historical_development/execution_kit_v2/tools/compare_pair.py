"""Compare one validated online/frozen pair on its common observed time window."""
from pathlib import Path
import argparse, hashlib, json
from validate_run import ROOT, parse, energy

def compare(online_path, frozen_path):
    online, frozen = [json.loads(p.read_text()) for p in (online_path, frozen_path)]
    if online['variant'] != 'NN_ONLINE' or frozen['variant'] != 'NN_FROZEN':
        raise ValueError('Se necesita NN_ONLINE y NN_FROZEN en ese orden')
    if online['profile'] != frozen['profile'] or online['platform'] != frozen['platform']:
        raise ValueError('La pareja debe compartir perfil y plataforma')
    arrays = []
    for item in (online, frozen):
        if not item['eligible_for_paired_comparison']:
            raise ValueError('Una corrida no es elegible. Revisar sus errores y ejecución.')
        path = Path(item['raw_log'])
        if hashlib.sha256(path.read_bytes()).hexdigest() != item['raw_sha256']:
            raise ValueError('El log cambió después de validarse')
        arrays.append(parse(path.read_text())[0])
    start = max(a[0, 0] for a in arrays)
    end = min(a[-1, 0] for a in arrays)
    profile = next(x for x in json.loads((ROOT / 'perfiles/profiles.json').read_text())
                   if x['id'] == online['profile'])
    em = [energy(a, profile, start, end) for a in arrays]
    delta = em[0]['tracking_model_pct'] - em[1]['tracking_model_pct']
    trap_delta = em[0]['trapezoid_sensitivity_tracking_pct'] - em[1]['trapezoid_sensitivity_tracking_pct']
    return {'profile': online['profile'], 'platform': online['platform'],
        'common_window_ms': [float(start), float(end)], 'NN_ONLINE': em[0], 'NN_FROZEN': em[1],
        'online_minus_frozen_model_efficiency_pp': delta,
        'online_minus_frozen_measured_energy_J': em[0]['measured_energy_estimate_J'] - em[1]['measured_energy_estimate_J'],
        'paired_delta_quadrature_sensitivity_pp': abs(trap_delta - delta),
        'statistical_CI': None,
        'interpretation': 'Una pareja determinista. No demuestra mejora estadística ni mide energía continua exacta.'}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--online', required=True, type=Path)
    p.add_argument('--frozen', required=True, type=Path)
    p.add_argument('--out', required=True, type=Path)
    args = p.parse_args()
    result = compare(args.online, args.frozen)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2))
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()

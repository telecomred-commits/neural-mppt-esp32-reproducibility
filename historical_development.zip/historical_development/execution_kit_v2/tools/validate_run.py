"""Validate one MPPT_EXEC_V2 log. Never convert incomplete runs into successes."""
from pathlib import Path
import argparse, hashlib, json, re
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
VARIANTS = {'PO': (0, 0), 'INC': (1, 0), 'ADAPT_PO': (2, 0),
            'NN_FROZEN': (3, 0), 'NN_ONLINE': (3, 1)}

def parse(text):
    rows, configs, starts = [], [], []
    for line in text.splitlines():
        line = re.sub(r'\x1b\[[0-9;]*m', '', line).strip()
        if line.startswith('# CONFIG '):
            configs.append(dict(re.findall(r'(\w+)=([^\s]+)', line)))
        if line.startswith('# EXP_START '):
            match = re.search(r't_ms=(\d+)', line)
            if not match:
                raise ValueError('EXP_START sin tiempo válido')
            starts.append(int(match[1]))
        if not re.match(r'^\d+(?:\.\d+)?\s', line):
            continue
        fields = line.split()
        if len(fields) != 23:
            raise ValueError('Fila numérica incompleta o distinta de las 23 columnas')
        try:
            rows.append([float(x) for x in fields])
        except ValueError as exc:
            raise ValueError('Fila de telemetría no numérica') from exc
    a = np.asarray(rows, dtype=float)
    if a.ndim != 2 or len(a) < 2:
        raise ValueError('Menos de dos muestras de telemetría')
    if not np.isfinite(a).all():
        raise ValueError('Telemetría con NaN o infinito')
    if not np.all(np.diff(a[:, 0]) > 0):
        raise ValueError('Tiempo duplicado, reinicio o tiempo decreciente')
    if len(configs) != 1 or len(starts) != 1:
        raise ValueError('Debe existir exactamente un CONFIG y un EXP_START')
    a[:, 0] -= starts[0]
    if a[0, 0] < 0:
        raise ValueError('Muestras anteriores a EXP_START')
    return a, configs[0], starts[0]

def environment(profile, times):
    current, out, j = {}, [], 0
    for instant in times:
        while j < len(profile['events']) and profile['events'][j]['t_ms'] <= instant:
            event = profile['events'][j]
            current[event['control']] = event['value']
            j += 1
        out.append(current.copy())
    return out

def reference(g, t, load):
    voc = np.clip(41.3 * (1 - .003 * (t - 25)), 0, 41.3)
    isc = 13.8 * g / 1000 * (1 + .0004 * (t - 25))
    k = np.clip(8 * (1 - .002 * (t - 25)), 1, 8)
    r = (1 / (k + 1)) ** (1 / k)
    v = voc * (1 - load / 100)
    p = v * isc * (1 - (v / voc) ** k)
    return voc * r, voc * r * isc * k / (k + 1), p

def energy(a, profile, start=None, end=None):
    """Piecewise constant samples, split at programmed environmental events."""
    start = a[0, 0] if start is None else start
    end = a[-1, 0] if end is None else end
    if not (a[0, 0] <= start < end <= a[-1, 0]):
        raise ValueError('Intervalo de integración fuera de los datos')
    grid = np.unique(np.r_[start, end, a[(a[:, 0] > start) & (a[:, 0] < end), 0],
        [x['t_ms'] for x in profile['events'] if start < x['t_ms'] < end]])
    ids = np.searchsorted(a[:, 0], grid[:-1], side='right') - 1
    env = environment(profile, grid[:-1])
    g = np.array([x['irradiance'] for x in env])
    t = np.array([x['temperature'] for x in env])
    _, available, plant = reference(g, t, a[ids, 8])
    dt = np.diff(grid) / 1000
    ep, ea, em = (float(np.sum(x * dt)) for x in (plant, available, a[ids, 3]))
    # Numerical sensitivity only. This is not an uncertainty bound or true energy.
    right_ids = np.minimum(np.searchsorted(a[:, 0], grid[1:], side='left'), len(a) - 1)
    _, _, plant_right = reference(g, t, a[right_ids, 8])
    trap = float(np.sum((plant + plant_right) * .5 * dt))
    return {'window_ms': [float(start), float(end)], 'plant_energy_estimate_J': ep,
        'available_model_energy_J': ea, 'measured_energy_estimate_J': em,
        'tracking_model_pct': 100 * ep / ea, 'measured_ratio_to_model_pct': 100 * em / ea,
        'trapezoid_sensitivity_tracking_pct': 100 * trap / ea}

def metrics(a, profile):
    env = environment(profile, a[:, 0])
    vm, _, pp = reference(np.array([x['irradiance'] for x in env]),
                         np.array([x['temperature'] for x in env]), a[:, 8])
    plateaus = []
    times = sorted({x['t_ms'] for x in profile['events']})
    for start, end in zip(times, times[1:] + [profile['duration_ms']]):
        if end - start < 15000:
            continue
        ids = np.flatnonzero((a[:, 0] >= start) & (a[:, 0] < end))
        settling = None
        for j in range(max(0, len(ids) - 4)):
            five = ids[j:j+5]
            if np.all(abs(a[five, 1] - vm[five]) <= .2):
                settling = float((a[five[0], 0] - start) / 1000)
                break
        tail = ids[a[ids, 0] >= end - 10000]
        plateaus.append({'start_ms': start, 'end_ms': end,
            'recovery_5_samples_0p20V_s': settling,
            'V_std_last10s': float(np.std(a[tail, 1], ddof=1)) if len(tail) > 1 else None,
            'plant_P_std_last10s': float(np.std(pp[tail], ddof=1)) if len(tail) > 1 else None})
    nn = a[:, 12] == 1
    return {'energy': energy(a, profile), 'samples': len(a),
        'startup_unobserved_ms': float(a[0, 0]),
        'tail_unobserved_ms': float(profile['duration_ms'] - a[-1, 0]),
        'I_RMSE_preupdate_covered_A': float(np.sqrt(np.mean(a[nn, 16] ** 2))) if nn.any() else None,
        'learning_updates_final': int(a[-1, 17]), 'parameter_change_final': float(a[-1, 19]),
        'fallback_fraction': float(np.mean(a[:, 11] == 3)),
        'at_limit_fraction': float(np.mean(a[:, 21])), 'retries_max': int(a[:, 22].max()),
        'sample_gap_max_ms': float(np.diff(a[:, 0]).max()),
        'controller_us_median': float(np.median(a[:, 20])),
        'controller_us_p95': float(np.quantile(a[:, 20], .95)),
        'controller_us_max': float(a[:, 20].max()), 'plateaus': plateaus}

def validate(a, config, profile, variant):
    errors, warnings = [], []
    mode, online = VARIANTS[variant]
    expected = dict(protocol='MPPT_EXEC_V2', mode=str(mode), online=str(online),
                    sample_ms='500', v_max='50', i_max='15')
    for key, value in expected.items():
        if config.get(key) != value:
            errors.append(f'CONFIG {key}: esperado {value}, recibido {config.get(key)}')
    if a[0, 0] > 1500 or a[-1, 0] < profile['duration_ms'] - 750:
        errors.append('Ventana incompleta respecto a la duración prevista')
    if a[-1, 0] > profile['duration_ms'] + 750:
        errors.append('Ventana excede el perfil más de 750 ms')
    if np.diff(a[:, 0]).max() > 750:
        errors.append('Hueco de muestreo mayor de 750 ms')
    if np.any((a[:, 7:10] < 0) | (a[:, 7:10] > 100)):
        errors.append('Comando o carga aplicada fuera de 0 a 100')
    if np.any(abs(a[:, 10] - (a[:, 9] - a[:, 7])) > .003):
        errors.append('Delta_cmd_pct no coincide con next menos confirmed')
    if not np.all(np.diff(a[:, 6]) == 1):
        errors.append('Secuencias ACK no consecutivas')
    if np.any(abs(a[1:, 7] - a[:-1, 9]) > .003):
        errors.append('El comando siguiente no fue confirmado en la muestra siguiente')
    if np.any(np.diff(a[:, 17]) < 0) or np.any(np.diff(a[:, 22]) < 0):
        errors.append('Contadores decrecientes o reinicio')
    if np.any(np.diff(a[:, 17]) != a[1:, 18]):
        errors.append('Inconsistencia entre learned y learning_updates')
    if variant != 'NN_ONLINE' and (np.any(a[:, 17:20] != 0)):
        errors.append('Cambios de aprendizaje en variante congelada o convencional')
    if variant == 'NN_ONLINE' and a[-1, 17] == 0:
        warnings.append('No se activó ninguna actualización. Conservar el resultado sin cambiar el umbral.')
    expected_sources = [0, 1, 3] if mode == 3 else [10 + mode]
    if np.any(~np.isin(a[:, 11], expected_sources)):
        errors.append('Rama de control inesperada o medición inválida')
    event_times = np.array(sorted({x['t_ms'] for x in profile['events']}))
    stable = np.min(abs(a[:, 0, None] - event_times), axis=1) > 250
    env = environment(profile, a[:, 0])
    g = np.array([x['irradiance'] for x in env])
    t = np.array([x['temperature'] for x in env])
    slider = np.array([x['load'] for x in env])
    for name, observed, target, tolerance in [
            ('irradiancia', a[:, 4], g, 2), ('temperatura', a[:, 5], t, .15),
            ('carga aplicada', a[:, 8], np.clip(a[:, 7] + slider - 50, 0, 100), .03)]:
        if np.any(stable & (abs(observed - target) > tolerance)):
            errors.append(f'Perfil de {name} no coincide con el programa')
    if np.any(a[:, 22] > 0):
        warnings.append('Hay retransmisiones. Registrar y explicar, sin borrar las corridas fallidas.')
    if np.any(a[:, 21] > 0):
        warnings.append('Se alcanzó un límite del actuador. Revisar los transitorios y la autoridad de control.')
    if profile['id'].startswith('R2'):
        warnings.append('Ganancias y ruido no se comprueban directamente con G/T. Archivar escenario y evidencia de los controles.')
    return errors, warnings

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--log', required=True, type=Path)
    p.add_argument('--profile', required=True)
    p.add_argument('--variant', required=True, choices=VARIANTS)
    p.add_argument('--execution', required=True, choices=['automated', 'manual'])
    p.add_argument('--platform', default='wokwi', choices=['wokwi', 'host'])
    p.add_argument('--out', required=True, type=Path)
    args = p.parse_args()
    profiles = json.loads((ROOT / 'perfiles/profiles.json').read_text())
    profile = next(x for x in profiles if x['id'] == args.profile)
    report = {'protocol': 'MPPT_EXEC_V2', 'profile': args.profile, 'variant': args.variant,
        'platform': args.platform, 'execution': args.execution,
        'raw_log': str(args.log.resolve()), 'raw_sha256': hashlib.sha256(args.log.read_bytes()).hexdigest(),
        'scope': 'Planta digital. Energía estimada a partir de muestras. Sin intervalo estadístico de Wokwi.'}
    try:
        a, config, start = parse(args.log.read_text())
        errors, warnings = validate(a, config, profile, args.variant)
        report.update(config=config, experiment_start_firmware_ms=start, errors=errors, warnings=warnings)
        report['technical_checks_passed'] = not errors
        report['eligible_for_paired_comparison'] = not errors and args.execution == 'automated'
        if args.execution == 'manual':
            report['warnings'].append('Corrida manual: demostración exploratoria, sin comparación causal de energía.')
        report['metrics'] = metrics(a, profile) if not errors else None
    except (ValueError, KeyError) as exc:
        report.update(errors=[str(exc)], warnings=[], technical_checks_passed=False,
                      eligible_for_paired_comparison=False, metrics=None)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps({k: report[k] for k in ['technical_checks_passed',
        'eligible_for_paired_comparison', 'errors', 'warnings']}, ensure_ascii=False, indent=2))
    return 0 if report['technical_checks_passed'] else 2

if __name__ == '__main__':
    raise SystemExit(main())

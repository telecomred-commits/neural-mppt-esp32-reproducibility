"""Regression tests for corrupted logs, wrong variants and independent energy."""
from pathlib import Path
import copy, csv, json, tempfile, unittest
import numpy as np
from validate_run import ROOT, parse, validate, reference, energy, metrics
from compare_pair import compare

def fixture(variant='NN_FROZEN'):
    online = int(variant == 'NN_ONLINE')
    a = np.zeros((240, 23))
    a[:, 0] = np.arange(500, 120001, 500)
    a[:, 4], a[:, 5] = 600, 37
    vm, pm, _ = reference(600, 37, 50)
    load = 100 * (1 - vm / (41.3 * (1 - .003 * 12)))
    a[:, 1], a[:, 2], a[:, 3] = vm, pm / vm, pm
    a[:, 6] = np.arange(1, 241)
    a[:, 7:10] = load
    a[:, 11:13] = 1
    a[:, 13] = vm
    config = dict(protocol='MPPT_EXEC_V2', mode='3', online=str(online),
                  sample_ms='500', v_max='50', i_max='15')
    text = '# CONFIG ' + ' '.join(f'{k}={v}' for k, v in config.items()) + '\n'
    text += '# EXP_START t_ms=0\n'
    text += '\n'.join('\t'.join(str(x) for x in row) for row in a)
    return a, config, text

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.profile = next(x for x in json.loads((ROOT / 'perfiles/profiles.json').read_text())
                           if x['id'] == 'S0_inedito')

    def test_valid_log(self):
        _, _, text = fixture()
        a, c, _ = parse(text)
        self.assertEqual(validate(a, c, self.profile, 'NN_FROZEN')[0], [])

    def test_nan_and_truncated_rows_rejected(self):
        _, _, text = fixture()
        bad = text.rsplit('\t', 1)[0]
        with self.assertRaises(ValueError):
            parse(bad)
        fields = text.splitlines()
        fields[2] = fields[2].replace('600.0', 'nan')
        with self.assertRaises(ValueError):
            parse('\n'.join(fields))

    def test_reset_rejected(self):
        _, _, text = fixture()
        with self.assertRaises(ValueError):
            parse(text + '\n' + text)

    def test_wrong_learning_mode_rejected(self):
        a, c, _ = fixture('NN_ONLINE')
        self.assertTrue(validate(a, c, self.profile, 'NN_FROZEN')[0])

    def test_frozen_changes_rejected(self):
        a, c, _ = fixture()
        a[-1, 17] = 1
        a[-1, 18] = 1
        self.assertTrue(validate(a, c, self.profile, 'NN_FROZEN')[0])

    def test_wrong_environment_rejected(self):
        a, c, _ = fixture()
        a[100, 4] = 800
        self.assertTrue(validate(a, c, self.profile, 'NN_FROZEN')[0])

    def test_incomplete_run_rejected(self):
        a, c, _ = fixture()
        self.assertTrue(validate(a[:100], c, self.profile, 'NN_FROZEN')[0])

    def test_exact_mpp_returns_100(self):
        a, _, _ = fixture()
        self.assertAlmostEqual(energy(a, self.profile)['tracking_model_pct'], 100, places=10)
        self.assertEqual(metrics(a, self.profile)['plateaus'][0]['recovery_5_samples_0p20V_s'], .5)

    def test_unachieved_recovery_is_null(self):
        a, _, _ = fixture()
        a[:, 1] = 20
        self.assertIsNone(metrics(a, self.profile)['plateaus'][0]['recovery_5_samples_0p20V_s'])

    def test_pair_common_window_and_tamper_detection(self):
        import hashlib
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            reports = []
            for variant in ['NN_ONLINE', 'NN_FROZEN']:
                _, _, text = fixture(variant)
                raw = td / f'{variant}.txt'
                raw.write_text(text)
                report = dict(variant=variant, profile='S0_inedito', platform='host',
                    eligible_for_paired_comparison=True, raw_log=str(raw),
                    raw_sha256=hashlib.sha256(raw.read_bytes()).hexdigest())
                rp = td / f'{variant}.json'
                rp.write_text(json.dumps(report))
                reports.append(rp)
            result = compare(*reports)
            self.assertEqual(result['online_minus_frozen_model_efficiency_pp'], 0)
            self.assertIsNone(result['statistical_CI'])
            raw.write_text(text + '\n# altered')
            with self.assertRaises(ValueError):
                compare(*reports)

    def test_manifest_contains_35_unique_pending_runs(self):
        with (ROOT / 'registro/corridas_planificadas.csv').open() as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), 35)
        self.assertEqual(len({x['run_id'] for x in rows}), 35)
        self.assertTrue(all(x['status'] == 'pendiente' for x in rows))

if __name__ == '__main__':
    unittest.main()

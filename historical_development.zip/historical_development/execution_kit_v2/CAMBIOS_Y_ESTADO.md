# Cambios y estado de la preparación experimental

Fecha 27 de octubre de 2026. Base experimental versión 6.

| Necesidad | Cambio o decisión | Comprobación | Estado |
| --- | --- | --- | --- |
| Identificar aprendizaje activado o desactivado | CONFIG imprime modo, aprendizaje, periodo y escalas | Compilación de cinco variantes y lectura del serial host | Verificado en host |
| Evitar configuraciones de compilación imposibles | Guardas de MPPT_MODE y MPPT_ONLINE_LEARNING | Dos compilaciones inválidas rechazadas | Verificado en host |
| Dar un origen temporal al perfil | EXP_START con millis y espera inicial de los escenarios | Siete YAML conservan eventos y duraciones | Preparado y coherente en archivos, pendiente de ejecución Wokwi |
| Conservar el algoritmo actual | Misma adquisición, controlador, pesos y 23 columnas | 35 corridas seed 1 idénticas en sus datos numéricos a la versión 6 en mocks host | Verificado en host |
| Conservar panel y circuito | Sin edición de archivos protegidos | Hashes de diagram.json, solar.chip.c, solar.chip.json y encabezados | Verificado |
| Detectar registros incompletos y variantes mezcladas | validate_run.py | 11 pruebas de regresión, además de 35 registros host | Verificado en host |
| Comparar ventanas temporales iguales | compare_pair.py con ventana común y comprobación de hashes | Ejecución de una pareja host y pruebas de integridad | Verificado en host |
| Separar eventos en la integración | Análisis versión 2, energía medida y reconstruida por separado | Caso en el MPP entrega 100%, prueba de pareja y análisis host | Verificado en host, aproximación temporal declarada |
| No producir falsa incertidumbre estadística | Pareja Wokwi sin intervalo bootstrap | Campo statistical_CI nulo por diseño | Verificado |
| Ejecutar campaña dinámica en ESP32 simulado | Plan de 35 corridas | Sin CLI ni firmware ESP32 compilado disponibles en este entorno | Pendiente de ejecución Wokwi |

No se ajustaron tasa, umbral ni pesos para forzar actividad de aprendizaje. Cualquier cambio posterior del controlador o entrenamiento requiere versión nueva y repetición de las comparaciones. Los resultados host usados para comprobar este kit no se presentan como nuevas mediciones Wokwi o de un ESP32 físico.

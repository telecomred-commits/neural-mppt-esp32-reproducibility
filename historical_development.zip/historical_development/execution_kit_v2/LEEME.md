# Kit de ejecución de experimentos MPPT versión 2

Empezar por `GUIA_EJECUCION.md` o el PDF de siete páginas. La primera pareja dinámica es **S2 temperatura**, 150 s con aprendizaje y 150 s sin aprendizaje. Después se ejecuta **S3 carga**, 160 s por variante.

## Qué colocar en el proyecto Wokwi

Trabajar en una copia del proyecto experimental actual ya funcional. Reemplazar únicamente `sketch.ino` por `firmware/sketch.ino`. Los encabezados `mppt_neural.h` y `mppt_weights.h` incluidos son idénticos a la versión 6. Se entregan para fijar la versión, sin un nuevo entrenamiento. Conservar el chip y el circuito actuales.

El cambio al `.ino` añade validación de las constantes de compilación y tres mensajes de identificación y origen temporal. El archivo `verificacion/sketch_changes.diff` muestra el cambio completo. No cambia las 23 columnas de telemetría ni el control.

En `sketch.ino`, seleccionar:

```cpp
#ifndef MPPT_MODE
#define MPPT_MODE MPPT_LEARNING
#endif
#ifndef MPPT_ONLINE_LEARNING
#define MPPT_ONLINE_LEARNING 1
#endif
```

Para la pareja congelada, cambiar el `1` de la última definición por `0`, recompilar y reiniciar. Para P&O, INC y P&O adaptativo usar `MPPT_MODE` 0, 1 y 2, respectivamente, con aprendizaje 0. El mensaje `# CONFIG` debe coincidir con la variante elegida.

## Primera comprobación en la interfaz web

1. Mantener rangos 50 V y 15 A, Ns=Np=1, modo automático y Load=50. Para S2 fijar G=800 y T=25.
2. Iniciar la simulación y observar `# CONFIG` y `# EXP_START`. Mantener todo el serial desde el arranque.
3. Cambiar T a 37, 50, 37 y 25 °C en los segundos 30, 60, 90 y 120 del perfil. Terminar a los 150 s. No mover G ni Load.
4. Guardar el registro, restaurar la condición inicial, cambiar únicamente aprendizaje a 0 y repetir con reinicio.

Esta ejecución manual comprueba funcionamiento. Para comparar energía con perfiles iguales se debe verificar la ruta automática. No es necesario instalar nada para realizar la primera comprobación funcional en la interfaz habitual.

## Ruta automática pendiente de comprobar

Los siete YAML están preparados para el componente `panel`. Primero aplican condiciones iniciales, esperan el texto `# EXP_START t_ms=` y después ejecutan el perfil. Debe probarse que `set-control` puede modificar los controles del chip personalizado actual. No se ha ejecutado esta ruta en Wokwi en esta entrega.

Los YAML nuevos requieren este `.ino` con el marcador. No se combinan con el `.ino` anterior sin marcador. El CLI necesita un proyecto local ya configurado con su firmware y chip compilados. Este kit no sustituye esa configuración ni incluye un ELF de ESP32.

## Herramientas de análisis

Python 3.9 o posterior y NumPy. Desde la raíz del kit:

```bash
python3 -m pip install -r tools/requirements.txt
python3 tools/test_tools.py
python3 tools/validate_run.py --log S2_NN_ONLINE_r01.txt --profile S2_temperatura --variant NN_ONLINE --execution automated --out S2_online.json
python3 tools/validate_run.py --log S2_NN_FROZEN_r01.txt --profile S2_temperatura --variant NN_FROZEN --execution automated --out S2_frozen.json
python3 tools/compare_pair.py --online S2_online.json --frozen S2_frozen.json --out S2_pareja.json
```

Usar `--execution manual` para registros tomados moviendo barras a mano. No renombrar una corrida manual como automática para obtener elegibilidad. `--platform host` se reserva para el arnés host, que no mide tiempos reales del ESP32.

El verificador detecta inconsistencias observables. No acredita por sí solo la configuración de ruido, la exactitud de los sensores o la procedencia del ELF. Conservar esos metadatos y la evidencia de ejecución. La comparación de una pareja Wokwi no produce intervalos estadísticos.

## Contenido

- `firmware/`: .ino identificado y los dos encabezados actuales.
- `perfiles/`: definición de eventos y duraciones.
- `escenarios_wokwi/`: siete escenarios candidatos con sincronización.
- `registro/corridas_planificadas.csv`: 35 corridas, todas pendientes.
- `tools/`: verificación, comparación emparejada y 11 pruebas de regresión.
- `verificacion/`: hashes de referencia, diferencia del .ino y comprobaciones realizadas.

Los datos host anteriores y el manuscrito se conservan en sus entregas previas. Este kit es una preparación operativa y no contiene nuevos resultados experimentales Wokwi. La integración de energía versión 2 divide intervalos en los eventos ambientales y no se mezcla con cifras del analizador anterior sin recalcular todos los registros comparados.
